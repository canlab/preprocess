function [hout,dat,xdat] = barplot_columns(dat,varargin)
% [axishandle,adjusted data,x-data] = barplot_columns(dat,[title],[covs],[extra string args])
%
% This function makes a barplot of columns of data, with standard error
% bars.  Optional arguments include removing continuous covariates before plotting,
% robust (IRLS) estimation of means and correlations with covariates, and
% within-subject error bars based on the subject x condition interaction
% (overall), which is not quite the standard error contrasts of interest,
% but is the standard error for a 1-way repeated measures ANOVA.
%
% plots circles around points at z >= 1.96
% plots individual points, unless you enter 4th argument
%
% Examples:  Just plot means and SE
% h = barplot_columns(tmp,'Cluster 1',[],1);
%
% Optional arguments
% 1 - Title for figure
% 2 - covariates
% 3 - String Arguments
%       'nofig' : do not make figure
%       'noind' : do not plot individual scores
%       'plotout': circle potential outliers at z>1.96 in red
%       'dorob' : do robust IRLS means and correlations
% Examples:
% barplot_columns(ctmp,'RT effects by Switch Type',overall_sw,'nofig','dorob')
%
% Standard Errors ARE NOT Adjusted for covariate, right now.

% ----------------------------------------------------
% > Set up input arguments
% ----------------------------------------------------

dofig = 1; doind = 1; plotout = 0; dorob = 0; xdat = []; dolines =0;

if length(varargin) > 2,
    for i = 3:length(varargin)
        if strcmp(varargin{i},'nofig'), dofig = 0;  end
        if strcmp(varargin{i},'noind'), doind = 0;  end
        if strcmp(varargin{i},'plotout'), plotout = 1;  end
        if strcmp(varargin{i},'dorob'), dorob = 1;  end
        if strcmp(varargin{i},'dolines'), dolines = 1;  end
    end
end


if length(varargin) > 1,
    covs = varargin{2};  if ~isempty(covs), covs = scale(covs,1); end
else covs = [];
end

% delete nans casewise
%wh = find(any(isnan(dat),2));
%dat(wh,:) = [];
%if ~isempty(covs), covs(wh,:) = []; end

% replace nans with mean
for i = 1:size(dat,2),
    if any(isnan(dat(:,i)))
        warning('Some NaNs!')
        %dat(find(isnan(dat(:,i))),i) = nanmean(dat(:,i));
    end
end

% find NaN columns
wh = find(all(isnan(dat),1));
dat(:,wh) = 0;

%dat1 = dat;     % save original data for ind subj plot

% get final design matrix, intercept is last column
[nn,ny] = size(dat);
k = size(covs,2);

% add intercept if not already in model
if ~isempty(covs)
    wh_oldintercept = find(all(diff(covs) < eps));
    covs(:,wh_oldintercept) = [];
end

X = [covs ones(nn,1)];
wh_intercept = k+1;

% ----------------------------------------------------
% > Get means and standard error of means
% With robust option, if specified, and removing
% covariates, if there are any.
% ----------------------------------------------------


% if dorob
%     % ROBUST FIT
stderr = [];

%[b,t,p,sig,f,fp,fsig,stat] = robust_reg_matrix(X,dat,1);

%for i = 1:k
%    [x,y,r,p,mycor(1,i),prob,serob] = partialcor(X,y,i)

% key vars are :
% mymeans, stderr, mycor

wh_reg = 1; % regressor of interest

for i = 1:ny

    fprintf(1,'\nColumn %3.0f:\n',i);
    
    % remove nans from this column
    tmpy = dat(:,i);
    tmpx = X;
    wh = find(any(isnan(X),2) | any(isnan(tmpy),2));
    tmpx(wh,:) = []; tmpy(wh) = [];
    n(i) = size(tmpy,1);

    % get mean and standard error of intercept (robust or OLS)
    % y is adjusted for all non-intercept covs
    % stats has weights, stats.w, which are all 1 for OLS 
    [x,y(:,i),r,p,stderr(i),mymeans(i),stats] = partialcor(tmpx,tmpy,wh_intercept,1,dorob);
    
    %%%not needed y(:,i) = y(:,i) + mymeans(i);   % add mean
    myweights(:,i) = stats.w;
    
    if ~isempty(covs)
        % cov of interest here is fixed at 1 (see above)
        
        % if we have covs, leave in cov. of interest (cov1)
        % y is adjusted for all non-intercept covs
        [x,y(:,i),mycor(i),mycorrp(i)] = partialcor(tmpx,tmpy,wh_reg,1,dorob);
        
        %not needed %%% y(:,i) = y(:,i) + mymeans(i);   % add mean
        
    end
    
    fprintf(1,'\n');
end

dat = y;  % adjusted data, for plot


% ----------------------------------------------------
% > Make figure
% ----------------------------------------------------

if dofig
    f = figure('Color','w'); hout = gca; set(gca,'FontSize',18); %hold on; grid on;
else
    f = get(gcf); hout = gca; set(gca,'FontSize',18); hold on;
end


% ----------------------------------------------------
% > BARPLOT
% ----------------------------------------------------

h = bar(mymeans); set(h,'FaceColor',[.8 .8 .8]); %,'LineWidth',2)
tor_bar_steplot(mymeans,stderr,{'k'});

set(gca,'XLim',[0 ny+1],'XTick',1:ny,'XTickLabel',1:ny)
xlabel('Task Condition'), ylabel('BOLD contrast')

if length(varargin) > 0, title(varargin{1},'FontSize',24),end
%set(gcf,'Position',[464   283   930   827]), drawnow

% sort individual scores by covariate, if covs
if ~isempty(covs)
    
    [sortedcov,indx] = sort(covs(:,wh_reg));
    dat = dat(indx,:);
    sortedw = myweights(indx,:);
    
    x = (0:(nn-1)) ./ (nn+5) - (.5 - 1/(nn-5));
else
    x = zeros(1,nn) - .1;
    sortedw = myweights;
end

%s = std(dat1);

if ~doind
    % do nothing

else
    % ----------------------------------------------------
    % > Plot individuals
    % ----------------------------------------------------

    x = [x; x]; 
    
    hold on
    for i = 1:size(dat,2)
        % marker
        if mod(i,2)==0, mym='^'; myc=[.2 .2 .2]; else,mym='o'; myc=[0 0 0]; end

        for j = 1:size(dat,1)
            % color by weight
            myc = [1 1 1] - ([1 1 1] .* sortedw(j,i));
            
            if i == 1
                xdat(j,:) = x(1,j) + (1:size(dat,2)); % save x values for output (for line plotting)

                % plot lines (if requested)
                if dolines
                    plot(xdat(j,:),dat(j,:),'k','LineWidth',.5,'Color',[.7 .7 .7]);
                end
            end
            
            % plot marker
            plot(x(:,j) + i,[dat(j,i) dat(j,i)]',mym,'Color',[0 0 0],'LineWidth',1,'MarkerFaceColor',myc)
            
            
        end
        
        z = (dat(:,i) - mean(dat(:,i))) ./ std(dat(:,i)); wh = find(abs(z) >= 1.96);

        % print z-scores of potential outliers to text
        %if ~isempty(wh), fprintf(1,'\nCond %3.0f\t',i),for j = 1:length(wh), fprintf(1,'%3.2f\t',z(wh(j))); end,end

        if plotout
            if ~isempty(wh),plot(x(:,wh) + i,[dat(wh,i) dat(wh,i)]','ro','MarkerSize',14,'LineWidth',2),end
        end

    end

%     if dolines
%         for i = 1:size(dat,1)
%             plot(xdat(i,:),dat(i,:),'k','LineWidth',.5,'Color',[.7 .7 .7]);
%         end
%     end
        
end % plot individuals
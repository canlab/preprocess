% slicesh = cluster_orthviews_showcenters(cl, myview, overlay, [xhairs], [order slices flag])
%
% cluster_orthviews_showcenters(cl, 'coronal', overlay);
% cluster_orthviews_showcenters(cl, 'saggital', overlay);
% cluster_orthviews_showcenters(cl, 'axial', overlay);
%
% tor wager, aug 2006
% used in cluster_orthviews_classes

function slicesh = cluster_orthviews_showcenters(cl, myview, overlay, xhairs, sliceorder)
    if nargin < 4, xhairs = 1; end
    if nargin < 5, sliceorder = 0; end

    % set up orthviews to be OK
    scn_export_spm_window('setup', overlay);
    if xhairs, spm_orthviews('Xhairs', 'on'); end

    myviews = {'axial' 'coronal' 'saggital'};   % for selecting SPM window
    whview = find(strcmp(myviews, myview));
    if isempty(whview), error('myview must be axial, coronal, or saggital.'); end

    if sliceorder
        % order slices from negative to positive along this dimension
        myviews2 = {'saggital' 'coronal' 'axial' };  % for selecting coord
        whcoord = strmatch(myview, myviews2) ;
        cen = cat(1, cl.mm_center);
        [cen, wh] = unique(cen(:, whcoord));
        % remove duplicates and sort
        cl = cl(wh);

        % get text string base
        mystr = {'x = ' 'y = ' 'z = '};
        textbase = mystr{whcoord};
    end


    % get optimal number of axes
    naxes = length(cl);
    rc = ceil(sqrt(naxes));

    axh = get_orth_axishandles;
    axh = axh(whview);

    slicesh = figure('Color', 'k');
    for i = 1:naxes, newax(i) = subplot(rc, rc, i); axis off; end


    for i = 1:naxes
        %cluster_orthviews(cl{i}, colors2(classes(i)), 'overlay', overlay);
        spm_orthviews('Reposition', cl(i).mm_center);

        obj1 = get(axh, 'Children');
        copyobj(obj1, newax(i));
        axes(newax(i));
        axis image

        h = findobj(newax(i), 'Type', 'text');

        if sliceorder
            % try to set a reasonable font size
            pos = get(newax(i), 'Position');
            height = pos(3);
            fs = round(height * 70);
            set(h, 'FontSize', fs)
            % set position of text (move down and right)
            pos = get(h, 'Position');
            pos(2) = 0; %pos(2) - fs./2;
            pos(1) = 0;
            set(h, 'Position', pos)
            % set text string based on cen
            set(h, 'String', [textbase num2str(cen(i))]);

        elseif ishandle(h), delete(h);
        end
    end

    % try to set a reasonable enlargement factor
    n = 1 + .15 * log(naxes ./ 2);
    n = max(n, 1); n = min(n, 3);
    enlarge_axes(gcf, n)

end




function axish = get_orth_axishandles

    % Get figure and axis handles
    fh = findobj('Tag', 'Graphics');
    ch = get(fh, 'Children');
    for i= 1:length(ch), mytype = get(ch(i), 'Type'); wh(i)=strcmp(mytype, 'axes'); end
    axish = ch(find(wh));

    if isempty(axish), error('SPM figure orthviews do not exist'); end

    % get which axis is which
    for i = 1:length(axish)
        poss(i, :) = get(axish(i), 'Position');
    end

    % get rid of extra axes we may have created in the 4th quadrant
    other_axes = find(any(poss(:, 1) > .45 & poss(:, 2) < .2, 2));
    axish(other_axes) = [];
    poss(other_axes, :) = [];

    % sort into order:  axial, coronal, saggital
    ssum = sum(poss(:, 1:2), 2);
    [ssum, ind] = sort(ssum);
    axish = axish(ind);

end

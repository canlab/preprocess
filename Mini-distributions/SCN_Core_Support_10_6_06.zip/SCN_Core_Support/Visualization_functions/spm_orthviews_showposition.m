function h = spm_orthviews_showposition
% handles = spm_orthviews_showposition;
%
% plots x, y, and z coordinates on SPM orthviews figure
%
% tor wager, august 2006

% Get figure and axis handles
fh = findobj('Tag','Graphics');
ch = get(fh,'Children');
for i= 1:length(ch),mytype = get(ch(i),'Type'); wh(i)=strcmp(mytype,'axes'); end
axish = ch(find(wh));


% get which axis is which
for i = 1:length(axish)
poss(i,:) = get(axish(i),'Position');
end

% get rid of extra axes we may have created in the 4th quadrant
other_axes = find(any(poss(:,1) > .45 & poss(:,2) < .2,2));
axish(other_axes) = [];
poss(other_axes,:) = [];

% sort into order:  axial, coronal, saggital
ssum = sum(poss(:,1:2),2);
[ssum,ind] = sort(ssum);
axish = axish(ind);

% get current position in mm
pos = round(spm_orthviews('Pos'));  % x y z

% axial
h(1) = put_text(axish(1),['z = ' num2str(pos(3))]);

% coronal
h(2) = put_text(axish(2),['y = ' num2str(pos(2))]);

% saggital
h(3) = put_text(axish(3),['x = ' num2str(pos(1))]);

return



function h = put_text(axish,str)

axes(axish)

% remove old text
oldh = findobj(gca,'Type','text');
delete(oldh)

% add new text
xpos = diff(get(axish,'XLim')) .* .65;
ypos = diff(get(axish,'YLim')) .* .06;
h = text(xpos,ypos,str,'Color','y','FontSize',24);

return

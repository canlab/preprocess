function scn_export_spm_window(meth,savefilename)
% scn_export_spm_window(meth,[savefilename] or [overlay])
%
% Modes:
% scn_export_spm_window('setup')
% scn_export_spm_window('setup',overlayimgname)
% Set up SPM figure window paper size, etc. for saving
% The optional argument sets the spm_orthviews display range based on your
% image
%
% scn_export_spm_window('save','myfile')
% saves SPM window to myfile.png
%
% Run setup first, then save.
%
% tor wager
% aug 3, 06

fh = findobj('Tag','Graphics');
if isempty(fh) || ~(ishandle(fh))
    disp('No SPM figure window.  Using current figure.');
    fh = gcf;
end

switch meth
    case 'setup'

        if nargin > 1 && ~isempty(savefilename)
            % set display window on orthviews based on input image
            v=spm_read_vols(spm_vol(savefilename)); v = v(:);
            ub = mean(v)+4*std(v);
            spm_orthviews('Window',1,[0 ub])
        end

        % set colors
        set(fh, 'InvertHardCopy', 'off');
        set(fh, 'color', 'black');

        scn_export_papersetup;

        % turn off crosshairs
        spm_orthviews('Xhairs','off');

    case 'save'
        % now we're ready to save
        saveas(fh,savefilename,'png');

    otherwise
        error('Meth should be ''setup'' or ''save''.')
end


return




function scn_export_papersetup
% make sure that min size of fig. is 400 pixels
sz = get(gcf,'Position');
sz = sz(3:4);   % width and height
szratio = max(sz) ./ min(sz);   % max to min size
wh = find(sz == min(sz));
sz(wh) = 400;
wh = find(sz == max(sz));
sz(wh) = 400 * szratio;

% set paper size using current screen
set(gcf,'PaperUnits','points','PaperPosition',[0 0 sz],'PaperType','usletter');
return


res = .01;

% interpolate points in a line between  min and max X
x = min(X(:,1)):res:max(X(:,1))
b = pinv([X(:,1) ones(size(X(:,1),1),1)]) * X(:,2);

y = b(1)*x+b(2);
X = [X; [x' y']];
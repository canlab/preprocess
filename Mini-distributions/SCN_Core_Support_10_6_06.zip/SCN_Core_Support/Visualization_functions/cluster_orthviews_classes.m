function cluster_orthviews_classes(cl,classes,overlay,myview,domontage)
%function cluster_orthviews_classes(cl,classes,overlay,myview,domontage)
%
% Makes montage and cluster orthviews of classes of clusters in different
% solid colors (hard coded colors right now).
%
% tor wager
% 
% Examples:
%classes = c.ClusterSolution.classes;
%overlay = EXPT.overlay;

colors = {'yo' 'go' 'bo' 'ro' 'co' 'mo' 'ko' 'r^' 'g^' 'b^' 'y^' 'c^' 'm^' 'k^'};
colors2 = {[1 1 0] [0 1 0] [0 0 1] [1 0 0] [0 1 1] [1 0 1] [0 0 0]};
colors2 = [colors2 colors2];

% orthviews
cluster_orthviews(cl(classes==1),colors2(1),'overlay',overlay,'solid');

for i = 2:max(classes)
    cluster_orthviews(cl(classes==i),colors2(i),'add','solid');
end

cluster_orthviews_showcenters(cl,myview,overlay,0);


%domontage = 0;
if domontage

% montage: build function call
str = ['montage_clusters(overlay,'];
for i = 1:max(classes)
    clc{i} = cl(classes==i);
    str = [str 'clc{' num2str(i) '},'];
end
str = [str '{'];
for i = 1:max(classes)
    str = [str '''' colors{i} ''''];
    if i ~= max(classes), str = [str ' ']; end
end
str = [str '});'];
eval(str)
end

return


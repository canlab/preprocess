% PLOT_ERROR    Plot a matrix with shaded error area around it
%   PLOT_ERROR(X, Y) plots matrix Y against x-values in X, where Y is a matrix with each row representing a signal.
%   The shaded area represents the standard error across the columns of Y.
%
%   PLOT_ERROR(Y) plots the data matrix Y versus its index.
%
%   PLOT_ERROR(..., colorSpecString) plots the line according to the designated ColorSpec string, and shades the error area
%   by the color of the line
%
%   PLOT_ERROR(AX, ...) plots into the axes designated by the AX axes handle.
%
%   PLOT_ERROR return the handle of the main line object

function line_handle = plot_error(varargin)
        if(isempty(varargin))
            error('No arguments to %s', mfilename);
        end
        
        args = varargin;
        if(ishandle(args{1}))
            h = args{1};
            if(~strcmp(get(h, 'Type'), 'axes'))
                error('Handle %d must be an axes handle.', h);
            end
            args(1) = [];
        else
            h = gca();
        end
        
        if(isempty(args{1}) || (~isvector(args{1}) && ~ismatrix(args{1})))
            error('First argument (if not an axes handle) must be a matrix or vector');
        elseif(length(args) > 1 && isvector(args{1}) && ismatrix(args{2}) && length(args{1}) == size(args{2}, 2))
            x = args{1};
            y = args{2};
            args(1:2) = [];
        else
            y = args{1};
            x = 1:size(y, 2);
            args(1) = [];
        end
        x = x(:);
        
        colorString = '';
        for i=1:length(args)
            if(ischar(args{i}))
                colorString = args{i};
            end
        end
    
        meanData = mean(y);
        errorData = std(y) / sqrt(size(y, 1));

        line_handle = plot(h, x, meanData, colorString);
        hold(h, 'on');
        xVertices = [x; flipud(x)];
        yVertices = [meanData+errorData meanData(end:-1:1)-errorData(end:-1:1)];
        fill(xVertices, yVertices, get(line_handle, 'Color'), 'EdgeColor', 'none', 'FaceAlpha', .25, 'Parent', h);
        hold(h, 'off');
end
% function [P, reslicedImgs] = reslice_imgs(sampleTo, resliceThis, [domask])
%
% arguments are file names of .img files
% if empty, select from GUI
%
% if domask, recalculates a 1 or 0 mask for each image file in resliceThis
%
% Example:
% Reslice a mask image into the space of some functional images, and move
% to the current directory
% -----------------------------------------------------------------------
% [tmp, maskname] = reslice_imgs(image_names(1, :), maskname, 1);
% eval(['!mv ' maskname ' ./'])
% eval(['!mv ' maskname(1:end-4) '.hdr ./'])

function [P, reslicedImgs] = reslice_imgs(sampleTo, resliceThis, varargin)
    domask = 0;

    % using b-spline or fourier really screwed up some of my masks, so trilinear may
    % be better!
    flags = struct('interp', 1, ... % b-spline
        'mask', 0, ...              % do not mask
        'mean', 0, ...              % do not write mean image
        'hold', -1, ...             % i don't think this is used anymore
        'which', 1, ...             % reslice 2nd-nth only
        'wrap', [0 0 0]' ...        % the default; don't know what this is
        );

    if length(varargin) > 0
        domask = varargin{1};
    end

    if isempty(sampleTo)
        sampleTo = spm_get(1, '*.img', 'Select image with desired dimensions', pwd, 0);
    end

    if isempty(resliceThis)
        resliceThis = spm_get(Inf, '*.img', 'Select image(s) to resample', pwd, 0);
    end

    P = str2mat(sampleTo, resliceThis);
    spm_reslice(P, flags)


    if domask
        disp('Re-thresholding masks...')

        for i = 1:size(resliceThis, 1)
            [d, f, e] = fileparts(deblank(resliceThis(i, :)));
            resliced_img = fullfile(d, ['r' f e]);
            spm_imcalc_ui(resliced_img, resliced_img, 'i1>0');
        end
    end

    for i = 1:size(P, 1)-1
        [d, f, e] = fileparts(P(i+1, :));
        if i==1
            reslicedImgs = fullfile(d, ['r' f e]);
        else
            reslicedImgs = strvcat(reslicedImgs, fullfile(d, ['r' f e]));
        end
    end
end

function clusters = extract_raw_data(EXPT,clusters,varargin)
% clusters = extract_raw_data(EXPT,clusters,[con/timgs for ind peaks],[recover-resume at sub#])
%
% tor wager
% Extracts raw image data for each subject in each cluster
% averaging over cluster voxels (saved in clusters.all_data)
% and averaging over subjects (saved in clusters.timeseries)
%
% Options: High-pass filtering, spline detrending, principal components
% 
% inputs:  EXPT, as defined with get_expt_info.m
%          clusters, as defined with tor_extract_rois.m
%           Uses EXPT.FILES.im_files to get raw image names
%
%           Optional: a string matrix of contrast or t-images to define
%           individually significant regions.  Empty input skips this step.
%
%           For high-pass filtering (recommended), enter EXPT.TR, EXPT.HP,
%           and EXPT.FIR (or DX).nruns = [number of images for each
%           session]. 
%           For session intercept fitting only, use EXPT.HP = Inf;
%           requires hpfilter.m
%
%
% Last modified, 9/10/04 
% 5/9/04    - remove CLU and use new tor_extract_rois with direct cluster input.
%           - Also, reads spm_defaults for spm2 compatibility/image orientation
% 9/10/04   - check clusters and raw imgs to make sure mat file info matches;
%             adjust XYZ if necessary
%           - checks for tmp_extract_raw_data and saves diff filename if
%               necessary
% 8/10/05   - extract data from individually significant (or high-value)
%             regions; see extract_indiv_peak_data
% 12/11/05  - make splines and PCs optional
%
% Example: Do 1st subject last, save results afterwards
% cl = extract_raw_data(EXPT,cl,[],[2:7 9:length(EXPT.FILES.im_files) 1]);
% save conjunction_cl_raw cl

dospline = 0;   % spline detrend, if no HP filter
doprincomp = 0; % get principal components from clusters

% --------------------------------------------------------
% Set up inputs
% --------------------------------------------------------

if ~isfield(clusters,'descrip'), clusters(1).descrip = input('Enter descriptive name for these clusters (no spaces or special chars): ','s');,end

fname = [clusters(1).descrip '_raw_data'];  % datestr(now,30)];


startat = 1;
imgs = [];
subjidxs = 1:length(EXPT.FILES.im_files);

if length(varargin) > 0
    imgs = varargin{1};
end
if length(varargin) > 1
    if(isscalar(varargin{1}))
    	subjidxs = varargin{2}:length(EXPT.subjects);
    else
        subjidxs = varargin{2};
    end
    %try, fname = spm_get(1,'Choose tmp_extract_raw_data.mat file to start with');
    %catch, 
    %    fname = input('Type name of raw_data mat file to load: ','s');
    %end
    if exist(fname) == 2
        disp(['Loading saved data: ' fname]);
    else
        fname = spm_get(0,'*mat','Choose raw_data.mat file to load or done to start fresh');
    end

    if ~isempty(fname), load(fname), end
end

% --------------------------------------------------------
% try to get stuff for high-pass filtering
% --------------------------------------------------------
dohp = 0;
TR = []; HP = Inf; spersess = [];
if isfield(EXPT,'TR'), TR = EXPT.TR; end
if isfield(EXPT,'HP'), HP = EXPT.HP; end
if isfield(EXPT,'FIR')
    if isfield(EXPT.FIR,'nruns'),
        spersess = EXPT.FIR.nruns;
    end
end
if isfield(EXPT,'DX')
    if isfield(EXPT.DX,'nsess'),
        spersess = EXPT.FIR.nruns;
    end
end
if ~isempty(TR) && ~isempty(HP) && ~isempty(spersess)
    dohp = 1;
    fprintf(1,'Doing session intercept removal and high-pass filtering using %3.2f TR, %3.2f filter (s).\n',TR,HP);
    
    % set up filtering matrices for fast processing
    y = ones(size(EXPT.FILES.im_files{1},1),1);   % dummy data
    [y,I,S] = hpfilter(y,TR,HP,spersess);

else
    if dospline
        fprintf(1,'HP filter info missing, using spline detrending every 100 images instead.\n'); 
    else
        fprintf(1,'HP filter info missing (no HP); spline detrend option off.\n'); 
    end
end
    
if ~doprincomp
	fprintf(1,'\t(principal components option off.)\n')
end

% --------------------------------------------------------
% checks
% --------------------------------------------------------
spm_defaults

% check clusters to see if SPM mat file info in clusters matches that of
% data to extract.  Adjust voxel coordinates in clusters if necessary.
fprintf(1,'Checking coordinates...\n')
V = spm_vol(EXPT.FILES.im_files{1}(1,:));
[chk, clusters] = check_spm_mat(clusters(1).M,V(1).mat,clusters);
if chk, fprintf(1,'Adjusted vox coords to extracted image space using XYZmm; new XYZ and XYZmm created.'),end
fprintf(1,'\n')


% --------------------------------------------------------
% loop through subjects
% --------------------------------------------------------

for i = subjidxs
    
    fprintf(1,'\nStarting subject %3.0f\n\t', i)
    
    sbjctOK = 1;        % flag; subject has all images in expected places.
    %try
    
	% get rid of empty image names
	wh = all(EXPT.FILES.im_files{i} == ' ',2);
	EXPT.FILES.im_files{i}(find(wh),:) = [];

    [cl] = tor_extract_rois(EXPT.FILES.im_files{i},clusters);

    % check to see if this is the same length as first subject
    if i ~= 1 & size(EXPT.FILES.im_files{i},1) > size(ts{1},1)
        fprintf(1,'Warning! Timeseries for this subject is too long!!!\n'),
        %L = size(ts{1},1);
        sbjctOK = 0;
        
    elseif i ~= 1 & size(EXPT.FILES.im_files{i},1) < size(ts{1},1)
        fprintf(1,'Warning! Timeseries for this subject is too short!!!\n'),
        sbjctOK = 0;     
    else
            %L = size(cl(j).all_data,1);
    end
    
        
	% debug
	%if ~isfield(cl,'timeseries'),
	%	EXPT.FILES.im_files{i}(1:5,:),EXPT.FILES.im_files{i}(end-5:end,:)
		%keyboard
	%end 
		
    if sbjctOK
        
        fprintf(1,'\tWindsorizing and data processing')
        t1 = clock;
        for j = 1:length(cl)

            % index so 1st is cluster, matrix of subjects
            raw{j}(:,:,i) = cl(j).all_data;
            cl(j).timeseries = [];                     % empty to save space
 
            % Windsorize and re-average
            tmp = cl(j).all_data;
            cl(j).all_data = [];                     % empty to save space
        
            for k = 1:size(tmp,2)
                tmp(:,k) = trimts(tmp(:,k),3,[],1);     % last arg does sess break removal and spike correct
                if dohp
                    tmp(:,k) = hpfilter(tmp(:,k),[],S,spersess,I);  % high-pass
                else
                    tmp(:,k) = splineDetrend(tmp(:,k));     % spline detrend every 100 images - remove LF drift
                end
            end
            tmp = nanmean(tmp',1)';
            ts{j}(:,i) = tmp;
        
            % eigenvectors and principal components
            if doprincomp
                warning off                                 % divide by 0 warning if 1 voxel
                [eigv,eigscore,eigval] = princomp(tmp);
                ne = min(3,max(size(eigval)));              % number to save
                eigs{j}(:,i,1:ne) = eigscore(:,1:ne);       % time x subjects x vectors
                warning on
            else
                eigs{j} = [];
            end
            
            % save names
            if i == 1 & j == 1, clusters(j).imnames = cl(j).imnames;,end
        
            clusters(j).imP{i} =  EXPT.FILES.im_files{i};
            clusters(j).sbjctOK(i) = sbjctOK;
        
        end  % loop through clusters
        
        fprintf(1,'%3.0f s. \n', etime(clock,t1));
    else
        for j = 1:length(cl)
            % bad subject, wrong # imgs
            raw{j}(:,:,i) = NaN;
            ts{j}(:,i) = NaN;
            eigs{j}(:,i,:) = NaN;
            clusters(j).imP{i} =  EXPT.FILES.im_files{i};
            clusters(j).sbjctOK(i) = sbjctOK;
        end
            
    end
        
    %catch
	%    disp('Problem with subject.')
	%    for j = 1:length(clusters)
%		    ts{j}(:,i) = NaN;
%		    raw{j}(:,:,i) = NaN;
%	    end

 %   end     % end try


  save(fname, 'ts', 'raw', 'cl', 'eigs')
    
end  % end loop through subjects


% --------------------------------------------------------
% attach data to main clusters
% --------------------------------------------------------

for j = 1:length(clusters)
    
    ts{j}(ts{j} == 0) = NaN;
    
    clusters(j).all_data = ts{j};                   % one column per subject, average over voxels
    clusters(j).timeseries = nanmean(ts{j}')';      % average across subjects
    if doprincomp, clusters(j).prin_comps = eigs{j}; end          
    clusters(j).raw_data = raw{j};                  % time x voxels x subjects

end

% --------------------------------------------------------
% extract individual peaks, if contrast/tmap input is entered
% --------------------------------------------------------

if ~isempty(imgs)
    try
        clusters = extract_indiv_peak_data(clusters,imgs);
    catch
        disp('Error using extract_indiv_peak_data')
    end
end


return




function [chk, clusters] = check_spm_mat(mat1,mat2,clusters)
%check_spm_mat(mat1,mat2,clusters)
% mat1 is from clusters, mat2 is functional (imgs to extract)


chk = mat1 - mat2; chk = chk(:);
chk = chk(1:end-1);             % eliminate SPM scale factor
chk = any(chk);

if chk
    
    % we need to get the correct voxel coords from mat2 (funct) into
    % clusters, keeping the mm_coordinates the same!
    VOL.M = mat2;
    
    for i = 1:length(clusters)
        
        clusters(i).XYZ = mm2voxel(clusters(i).XYZmm,VOL)'; % functional img space, cluster mm coordinates
    
        clusters(i).Z = ones(1,size(clusters(i).XYZ,2));
        clusters(i).XYZmm = voxel2mm(clusters(i).XYZ,mat2);
        
        clusters(i).M = mat2;
        
        clusters(i).voxSize = diag(clusters(i).M(1:3,1:3)');
      
        % skip this, and clusters will have mm list of different length than
        % voxel list (XYZ).  data will be from voxel list.
        %SPM.XYZmm = voxel2mm(SPM.XYZ,VOL.M);    % slow, but gives unique voxels
    end
end

return



function [imgvec,maskvec] = iimg_clusters2indx(cl,volInfo)
% [imgvec,maskvec] = iimg_clusters2indx(cl,volInfo)
% [imgvec,maskvec] = iimg_clusters2indx(cl,my_image_name)
%
% Take a clusters structure and turn it into an indexed image of dims
% volInfo.dim
%
% imgvec: vector of all image voxels
% maskvec: vector of in-mask voxels
% uses
% volInfo.nvox, .wh_inmask, .dim

% convert image to volinfo struct, if necessary
if isstr(volInfo)
    volInfo = iimg_read_img(volInfo,2);
end

xyz = cat(2,cl.XYZ);

wh = sub2ind(volInfo.dim(1:3),xyz(1,:)',xyz(2,:)',xyz(3,:)');

% 
imgvec = false(volInfo.nvox,1);
imgvec(wh) = 1;

maskvec = imgvec(volInfo.wh_inmask);

return

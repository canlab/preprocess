function [dat,maskInfo] = iimg_get_data(maskname,image_names)
% [dat,volInfo] = iimg_get_data(maskname,image_names)
%
% 3 input options for maskname:
% 1) string of mask.img filename
% 2) volInfo structure (iimg_read_img)
% 3) xyz list, 3 rows x n voxels

% get mask info structure and image info
% ------------------------------------------------------------
docheck =1;
if isstruct(maskname)
    % structure
    maskInfo = maskname;
    if ~isfield(maskInfo,'xyzlist')
        error('Need xyzlist in maskInfo.  Try using extended output flag with iimg_read_img.');
    end 
elseif ischar(maskname)
    % string
    maskInfo = iimg_read_img(maskname,1);
else
    % xyz list
    maskInfo = struct('xyzlist',maskname);
    docheck = 0;
end

imgInfo = spm_vol(image_names);

% Check the dimensions
% ------------------------------------------------------------
% only necessary to check the first image, because spm_vol checks the set
if docheck
    anybad = iimg_check_volinfo(maskInfo,imgInfo(1));
    if anybad, error('Reslice images so dimensions and vox sizes match.'); end
end

dat = spm_get_data(imgInfo,maskInfo.xyzlist');





% Notes:
% This is faster for lists with many voxels (like 200,000)
% but is slower for 44,000 voxels
%tic, dat2 = spm_read_vols(spm_vol(image_names));, toc

return







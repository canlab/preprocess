% iimg_write_images(dat,volInfo,outnames)
%
% Write a series of Analyze images given:
% dat, voxels x images matrix of image data in index format
% volInfo, spm-style info structure; see iimg_read_img
% outnames, a string matrix of output filenames (or cell array)

function iimg_write_images(dat, volInfo, outnames)
    if isempty(outnames)
        error('You must specify a string array of output names.');
    end

    if iscell(outnames)
        outnames = char(outnames{:});
    end

    n = size(dat,2);
    if size(outnames,1) ~= n
        error('Number of images (columns of dat) must == number of output img names.');
    end

    if volInfo.nvox ~= size(dat,1)
        error('Dims of dat (vox x images) and volInfo do not match.');
    end

    for i = 1:n
        iimg_reconstruct_3dvol(dat(:,i),volInfo,'outname',deblank(outnames(i,:)));
    end
end
function [y,incpt,HP] = hpfilter(y,TR,HP,spersess,varargin)
% [y,incpt,S] = hpfilter(y,TR,HP,spersess,varargin)
% 
%
% Outputs:
% y         filtered data, session intercepts removed
% incpt     intefcept model pinv, such that incpt * y removes intercept
% HP        smoothing model, such that S * y does HP filtering
%           if sess lengths are unequal, make as long as the longest
%           session; may do funny things to shorter ones?
% 
% EXamples:
%
% [y,I,S] = hpfilter(data,2,120,[169 169 169 173 173]);   % slowest, creates
% intercept and smoothing matrix
% 
% for subsequent voxels with the same session info,
% y = hpfilter(data,[],S,[169 169 169 173 173],I);
%
% y = clusters(1).indiv_timeseries(:,1);
%[y,I,S] = hpfilter(y,2,120,[169 169 169 173 173]);
%y = clusters(1).indiv_timeseries(:,1);
%[y] = hpfilter(y,[],S,[169 169 169 173 173],I);
%
% Regress out average activity in first 2 scans of each session (artifacts)
% y = hpfilter(raw,2,100,EXPT.FIR.nruns,[],1:2);
%
% tor wager
% Modified 5/12/06 to include dummy images for each session

incpt = []; dummyscans = [];
if length(varargin) > 0, incpt = varargin{1};, end
if length(varargin) > 1, dummyscans = varargin{2};, end

if ismatrix(incpt)
    % already an intercept residual forming matrix 
else
    % assume it's spersess, [number of images in each run] vector

    if length(spersess)>1
        incpt = intercept_model(spersess,[],dummyscans);
    else
        incpt = intercept_model(spersess,1,dummyscans);
    end
    incpt = incpt * pinv(incpt);
end

if size(incpt,1) > length(y), 
    disp('Warning: Intercept has more observations than data. spersess is wrong?')
    incpt = incpt(1:length(y),1:length(y));
    
    tmp = cumsum(spersess);
    while tmp(end) > length(y),
        disp('Trying removal of a session.');
        spersess = spersess(1:end-1);
        tmp = cumsum(spersess);
    end
end

y = y - incpt * y;



if ismatrix(HP)
    % it's already an SPM smoothing matrix
    
else
    % make one
    len = max(spersess);    % max number of images in a session (run)
    HP = use_spm_filter(TR,len,'none','specify',HP);
end

% starting and ending images for each session
st = cumsum([1 spersess(1:end-1)]);
en = cumsum(spersess);

for i = 1:length(st)
    
    y(st(i):en(i)) = HP(1:spersess(i),1:spersess(i)) * y(st(i):en(i));

end


return
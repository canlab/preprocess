function [corrclass, taskclass, realclass, likeratio, m, misclass,ptask,indx,cl] = classify_bayes(meth,y,Xi,varargin)
    % [corrclass, taskclass, realclass, likeratio, m, misclass,ptask,indx,cl] = classify_bayes(meth,y,Xi,[var args])
    %
    % y = SOMResults.dat';
    %Xi = MC_Setup.Xi(:,1:2);
    %
    % meth can be:
    % {'linear','diagLinear','quadratic','diagQuadratic','mahalanobis'}  :
    % discriminant analysis
    % 'bayes' : simple Bayes posterior prob classifier
    %
    % tor wager, 10/2/06
    %
    % Feature selection parameters: optional inputs
    %         % selectivity_cutoff: max probability of task given a response in a
    % variable, divided by number of tasks.
    % 1 = variable must exceed .5 for 2 tasks, .2 for 5 tasks, etc.
    % 1.5 = .3 for 5 tasks, .75 for 2 tasks, etc.
    % 0 = no selectivity
    %
    % activation_cutoff: max proportion of studies of some type that produced a
    % response in a variable (e.g., voxel)
    % .1 is default
    % 0 is no selectivity
    %
    % Examples:
    % [corrclass, taskclass, realclass, likeratio, m, misclass] = ...
    % classify_bayes('bayes',MC_Setup.unweighted_study_data',Xi,'selectivity_cutoff',1); corrclass
    %
    % [corrclass, taskclass, realclass, likeratio, m, misclass] =
    % classify_bayes('bayes',MC_Setup.unweighted_study_data',Xi,'selectivity_cutoff',1,'activation_cutoff',.08); corrclass

    dofeature = 1;
    selectivity_cutoff = 1.5;
    activation_cutoff = .1;
    dopca = 0;
    doxval = 1;
    doplot = 1;
    
    for i = 1:length(varargin)
        if isstr(varargin{i})
            switch varargin{i}
                % reserved keywords
                case 'nofeature', dofeature = 0;
                case 'reduction', dopca = 0;
                case 'noxval', doxval = 0;
                case 'noplot', doplot = 0;
                    
                    % functional commands
                case 'selectivity_cutoff', selectivity_cutoff = varargin{i+1};
                case 'activation_cutoff', activation_cutoff = varargin{i+1};

                otherwise, warning(['Unknown input string option:' varargin{i}]);
            end
        end
    end

    origvars = size(y,2);
    [nstudies,ntasks] = size(Xi);
    realclass = indic2condf(Xi);

    % eliminate no-variance voxels
    % -----------------------------------------------------------------
    [y,whsave] = eliminate_constant(y);

    nvars = size(y,2);
    nalltasks = sum(sum(Xi));

    fprintf(1,'\n')
    str = ('Inital computation'); disp(str)

    % get max and min ptask, to avoid taking log of 1 or 0
    % -----------------------------------------------------------------
    % can't take log of 0 or 1, so shrink these extreme values
    sy = sum(y);
    ptask = (Xi' * y) ./ repmat(sy,ntasks,1);
    mymax = max(ptask(ptask < 1));
    mymin = min(ptask(ptask > 0));

    erase_string(str)

    % y is all data
    % trainset = training set, studies x voxels (regions)
    % testvec = test vector, 1 x voxels (regions)

    if dofeature
        % select features
        % -----------------------------------------------------------------

        selectivity_cutoff = selectivity_cutoff./ntasks;
        str = sprintf('Feature selection: selectivity: %3.2f, activation: %3.2f\n',selectivity_cutoff,activation_cutoff);
        disp(str)

        maxp = max(ptask);  % max prob of task across vars
        pt = (Xi' * y) ./ repmat(sum(Xi)',1,nvars);  % proportion of each task that activated in an area
        ptmax = max(pt);
        whomsave = maxp > (selectivity_cutoff) & ptmax > activation_cutoff;

        if sum(whomsave) == 0
            disp('Warning: No variables meet feature selection criteria.');
            whomsave = (maxp == max(maxp));
        end

        whsave = whsave(whomsave);  % overall indices of saved voxels
        y = y(:,whomsave);
        ptask = ptask(:,whomsave);
        nvars = size(y,2);
        fprintf(1,'Selected: %3.0f ',nvars);
        % get weights on voxels based on n activations.... ******
    end

    if dopca
        % reduce data
        % -----------------------------------------------------------------
        y = pca_reduction(y);
    end

    maxlike = zeros(nstudies,1);
    taskclass = zeros(nstudies,1);
    likeratio = zeros(nstudies,1);

    if doxval

        fprintf(1,'Cross-validating: 00000');
        for i = 1:nstudies

            if mod(i,10) == 0, fprintf(1,'\b\b\b\b\b%05d',i); end
            testvec = y(i,:)';
            trainset = y;
            trainset(i,:) = [];

            X = Xi;
            X(i,:) = [];

            [taskclass(i),maxlike(i),likeratio(i)] = get_class(meth,X,trainset,testvec,ntasks,mymax,mymin);
        end

    else
        % no x validation
        ptask(ptask == 1) = mymax;
        ptask(ptask == 0) = mymin;

        for i = 1:nstudies
            testvec = y(i,:)';
            [taskclass(i),maxlike(i),likeratio(i)] = choose_most_likely(ptask,testvec); % taking the log inside here is not efficient
        end
    end %doxval

    [m,dp,corr,far,misclass] = confusion_matrix(realclass,taskclass);

    wh = (realclass ~= 0);
    n = sum(wh);
    corrclass = 1 - sum(misclass) ./ n;

    % get class vectors for output, in original image length
    [mx,r] = max(ptask,[],1);

    indx = zeros(origvars,ntasks);
    for i = 1:ntasks
        thistask = (r == i); % & (max(ptask) > ptaskcutoff);
        indx(whsave(thistask),i) = ptask(i,thistask)';
    end

    cl = [];
    if doplot
        cl = classify_viz_regions(indx);
    end

    return


    % notes


    %%%no  prior_task = sum(Xi) ./ sum(Xi(:));
    %ptask = ptask .* repmat(prior_task',1,nvars);

    % this is exactly proportional to above but wrong.
    %pa = repmat(sum(y) ./ nstudies,ntasks,1);
    %ptask = (Xi' * y) ./ nalltasks ./ pa;



    % ====================================================================
    % --------------------------------------------------------------------
    %
    % Support functions
    %
    % --------------------------------------------------------------------
    % ====================================================================

function [taskclass,maxlike,likeratio] = get_class(meth,X,trainset,testvec,ntasks,mymax,mymin)
    switch meth
        case 'bayes'
            % proportion of activations that came from each task
            % p task | activation, with flat priors for task
            % posterior probability of task | activation in voxel (Region)
            ptask = (X' * trainset) ./ repmat(sum(trainset),ntasks,1);

            %(xy / sumx) * (sumx./allsum) ./ (sumy./nstudies)
            % add task priors
            %prior_task = sum(X) ./ sum(X(:));
            %ptask = ptask .* repmat(prior_task',1,nvars);

            % gives posterior probability
            % %                 pa = repmat(sum(trainset) ./ (nstudies-1),ntasks,1);
            % %                 ptask = (Xi' * trainset) ./ (nalltasks-1) ./ pa(j);

            ptask(ptask == 1) = mymax;
            ptask(ptask == 0) = mymin;

            % choose most likely task
            [taskclass,maxlike,likeratio] = choose_most_likely(ptask,testvec);


        case {'linear','diagLinear','quadratic','diagQuadratic','mahalanobis'}
            condf = realclass;
            condf(i) = [];
            %[taskclass(i),err,ptask,logp] = classify(testvec',trainset,condf,meth);
            [taskclass(i),err] = classify(testvec',trainset,condf,meth);

        otherwise error('Unknown method.')
    end

    return


function [taskclass,maxlike,likeratio] = choose_most_likely(ptask,testvec)


    ptask = log(ptask);    % likelihoods; summing these = taking product of probabilities

    taskprob = ptask * testvec;

    % choose most likely task
    [maxlike,taskclass] = max(taskprob);
    if all(taskprob == 0)
        likeratio = NaN;
    else
        likeratio = max(taskprob) ./ min(taskprob);
    end

    return


function [y,wh] = eliminate_constant(y)
    str = sprintf('Eliminating constant variables'); disp(str);
    %whomit = find(all(y == repmat(mean(y),nstudies,1)));
    tmp = sum(y);
    whomsave = ~(tmp == 0); %| tmp == nstudies);

    y = y(:,whomsave);
    wh = find(whomsave);
    erase_string(str);

    return



function score = pca_reduction(x)

    str = sprintf('\nData reduction'); disp(str);
    [pc,score,latent] = princomp(full(x),'econ');

    % %         if issparse(x)
    % %             [score,S,V] = svds(x,'econ');
    % %         else
    % %             [score,S,V] = svd(x,'econ');
    % %         end
    % %         latent = diag(S);

    % Eigenvalue plot
    figure('Color','w'), set(gca,'FontSize',18),bar(latent),
    xlabel('Components'),ylabel('Variance')

    erase_string(str);
    num_to_save = sum(latent>1);
    num_to_save = input(sprintf('Enter num. to save (%3.0f are > 1) : ',num_to_save));

    score = score(:,1:num_to_save);

    return


    % ====================================================================
    % --------------------------------------------------------------------
    %
    % Other utility functions
    %
    % --------------------------------------------------------------------
    % ====================================================================

function erase_string(str)
    fprintf(1,repmat('\b',1,length(str))); % erase string
    %fprintf(1,'\n');
    return

function subcl = subclusters_from_local_max(cl,dthresh)

subcl = [];

for i = 1:length(cl)
    
    [xyz, XYZmm, Z, class] = cluster_local_maxima(cl(i),dthresh,0);

    if all(class == 0)  % no peak maxima; just use the existing cluster
        %this_subcl = cl;
        % make same as subclusters by saving only relevant fields
        this_subcl = struct('title',cl(i).title,'threshold',cl(i).threshold,'M',cl(i).M,'dim',cl(i).dim,'voxSize',cl(i).voxSize, ...
            'name',cl(i).name,'numVox',cl(i).numVox,'XYZ',cl(i).XYZ,'XYZmm',cl(i).XYZmm,'Z',cl(i).Z, ...
            'mm_center',cl(i).mm_center,'from_cluster',i);
        
    else
        this_subcl = cluster2subclusters(cl(i),class);
    end
    
    % keep track of which larger cluster this came from; for cluster_table
    for j = 1:length(this_subcl)
        this_subcl(j).from_cluster = i;
    end

    try
        subcl = [subcl this_subcl];
    catch
        warning('internal error with subcluster consistency. this should work fine,but fix code...');
        subcl = merge_clusters(subcl,this_subcl);
    end
    
    
end


return

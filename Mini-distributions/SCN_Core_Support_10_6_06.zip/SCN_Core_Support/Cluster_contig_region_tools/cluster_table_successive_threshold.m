function cluster_table_successive_threshold(cl,sizethr)
%     cluster_table_successive_threshold(cl,[sizethr])
%
% cluster table of a cell array of clusters cl{1} cl{2} etc.
% Prints table of cl{1} and then any additional regions in cl{2:n} that are
% not within 10 mm of a previously printed cluster
% 
% table titles are hard-coded to be consistent with meta-analysis toolbox right now
    
mind = 10;  % distance
if nargin < 2, sizethr = 0; end

fprintf(1,'Height\n');
cluster_table(cl{1},1,0);
fprintf(1,'\n');

subc = subclusters_from_local_max(cl{1}, mind);
higher_thr = subc;

if isempty(cl{1}), disp('No significant activation'); end

strs = {'Stringent' 'Medium' 'Lenient'};

for i = 2:length(cl)

    fprintf(1,'Additional regions at Extent: %s and size >= %3.0f\n',strs{i-1},sizethr);
    subc = subclusters_from_local_max(cl{i}, 10);
    
    if isempty(higher_thr)
        dosubctable = 1;    % subclusters in table, this is first table...
        outside_range = ones(1,length(subc));
    else
        dosubctable = 0;
        [close_enough,outside_range,nearest_distance,closest_cluster] = cluster_close_enough(higher_thr,subc,mind);
    end
    
    % size threshold
    sz = cat(1,subc.numVox); sz = sz' >= sizethr;
    
    cluster_table(subc(outside_range & sz),dosubctable,0);
    fprintf(1,'\n');

    higher_thr = merge_clusters(higher_thr,subc);

end


return



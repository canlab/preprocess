function [cl,names] = cluster_names(cl,addflag)
% function [cl,names] = cluster_names(cl,[addflag])
%
% Assign names to cl(x).shorttitle
% Do not use spaces or underscores or special chars for best results
%
% Addflag is optional; if 1, uses current orthview display

spm_orthviews('Xhairs','on');

if addflag
    % don't create new figure
else
     cluster_orthviews(cl,{[1 0 0]});
end

for i = 1:length(cl)
    
    goname = 1;
    
    if isfield(cl(i),'shorttitle') && ~isempty(cl(i).shorttitle)
            goname = 0;
    end
        
    if goname
        spm_orthviews('Reposition',cl(i).mm_center);
        
        cl(i).shorttitle = input('Enter short name for this cluster: ','s');
        
        names{i} = cl(i).shorttitle;
    end
end


return
function [r,xy,v,zp,dfe] = weighted_reg(z,w,varz)

% Calculate weighted average using weighted linear least squares
%
% Model:
% z_i = 1*zpop + noise
%
% INPUT:
%
% z - data matrix (nsub x T)
% w = weights
% varz - variance of data at each time point (nsub x T)
%
% OUTPUT:
%
% r = weighted correlation coeff across columns of z
% xy = weighted covariance matrix
% v = weighted variance estimates for each column of z
% zp = weighted mean of each column of z
%



[m,n] = size(z);

W = diag(w);                    % Weight matrix
X = repmat(1,m,1);              % Design matrix - 1 column of all ones to calculate average 

zp = inv(X'*W*X)*X'*W*z;        % weighted population mean

e = z - repmat(zp,m,1);         % residuals

dfe_v = zeros(n,1);             
R = eye(m) - X*inv(X'*W*X)*X'*W;    % residual inducing matrix

% Calculate effective degrees of freedom

for i=1:n,

    V = diag(varz(:,i));
    dfe_v(i) = (trace(R*V)^2)/trace(R*V*R*V);       % Satherwaite approximation
    
end;

dfe = mean(dfe_v);               % Calculate average df over all time points. 


MSE = (e'*W*e)/dfe;             % Mean square error

xy = inv(X'*W*X)*MSE;           % Covariance matrix for zp;
xy = 0.5*(xy+xy');              % Remove rounding error

v = diag(xy);                   % Variance for zp
r = xy./sqrt(v*v');             % Correlation matrix for zp


return
  
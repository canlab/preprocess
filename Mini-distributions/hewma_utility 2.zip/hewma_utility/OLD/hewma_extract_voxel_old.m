function [dat,files] = hewma_extract_voxel(EXPT,coords)
% function [dat,files] = hewma_extract_voxel(EXPT,coords)

zsl = num2str(coords(3));

EXPT = getfunctnames2(EXPT,['z_slice' zsl '.mat'],'tmp');
files = str2mat(EXPT.tmp{:});

EXPT = getfunctnames2(EXPT,['var_slice' zsl '.mat'],'tmp');
vfiles = str2mat(EXPT.tmp{:});

load hewma0001/hewma_timeseries xdim ydim

try
    load([EXPT.subdir{1} filesep 'lam'])    % load lambda param, assume same for all subjects
catch
    error('Cannot find lam.mat.  Start in dir above individual ewma results dirs.')
end


fprintf(1,'Loading data, subject ');

for i = 1:length(EXPT.subdir)
    fprintf(1,'%3.0f ',i);
    
    % load EWMA stat
    load(files(i,:)); 
    zdat = full(zdat);
    T = size(zdat,2);
    zdat = reshape(zdat,xdim,ydim,T);


    dat(i,:) = squeeze(zdat(coords(1),coords(2),:));
    
    % load variance
    load(vfiles(i,:)); 
    vardat = full(vardat);
    vardat = reshape(vardat,xdim,ydim,T);


    vdat(i,:) = squeeze(vardat(coords(1),coords(2),:));
    
end
fprintf(1,'\n');

[p,tm,Zcor,sbmean,Zpop,tvals,sb,stats] = hewma2(dat, vdat, lam,1);

%figure;plot(dat');
%hold on; plot(mean(dat),'k','LineWidth',2);
%title('EWMA statistics with mean');


return


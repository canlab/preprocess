function cluster_kmeans_parcel(x,CLU,doplot)
%
% K-means clustering of voxels
% input:  x, a voxels x data matrix
%         CLU, a structure containing a list of XYZ coordinates and z-scores for voxels
%         (see clusters2CLU.m)
%         a plot flag
%
% tor wager
%
%

tor_fig; view(135,30); axis vis3d

% ----------------------------------------------------
% make initial histogram 
% ----------------------------------------------------


nbins = [length(unique(x(:,1))) length(unique(x(:,2)))];
[h,c] = hist3(x,nbins);
h = log(h);

%han = axes('Position',[.52 .08 .45 .38]);
set(gca,'FontSize',16)
barh = bar3(h);
title('Log frequency')
set(barh,'FaceColor',[.5 .5 .5],'EdgeColor',[0 0 0])
xlabel('Activation duration')
ylabel('Change Point')


% ----------------------------------------------------
% k-means clustering
% ----------------------------------------------------

nclasses = input('How many classes?');

err = 1; indx = 1;
while err
    try
        classes = kmeans(x, nclasses);   % ,'start','uniform');
        err = 0;
    catch
    end
    indx = indx + 1;
    if indx == 11, disp('kmeans: tried 10 times.  No solution.'); err = 0;, return, end
end


% ----------------------------------------------------
% define colors and sort by class size
% ----------------------------------------------------

colors = {[1 0 0] [0 1 0] [0 0 1] [1 1 0] [1 0 1] [0 1 1]};
while length(colors) < nclasses, colors = [colors colors];,end

for i = 1:nclasses, nvox(i) = sum(classes==i);,end
[nvox,i] = sort(nvox,2,'descend');

%colors = colors(i);
colors(i) = colors(1:length(i));


% ----------------------------------------------------
% bar color change
% ----------------------------------------------------

for cc = 1:nclasses
    hist_indic{cc} = zeros(size(h));
end

for ii = 1:size(h,1)
    for jj = 1:size(h,2)
        
        if h(ii,jj) > 0
            
            bincenter = [c{1}(ii) c{2}(jj)];
            
            % class for this bin
            d = distance(bincenter,x);
            wh = find(d == min(d));
            clas = classes(wh(1));
            
            % put in histogram indicator
            hist_indic{clas}(ii,jj) = 1;
            
        end
    end
end


% plot bars in color
for cc = 1:nclasses
    
    htmp = h .* hist_indic{cc};
    
    hold on;
    hhtmp = bar3(htmp);
    set(hhtmp,'FaceColor',colors{cc})
    
end

hhtmp = bar3(zeros(size(h)));
set(hhtmp,'FaceColor',[.8 .8 .8])

drawnow


h1 = get(gca,'Children');

CLU.Z = classes';


% ----------------------------------------------------
% re-make separate clusters for each class
% and plot on brain
% ----------------------------------------------------

clear cl2 
for i = 1:nclasses
    CLUtmp = CLU;  
    wh = find(CLUtmp.Z == i);
    CLUtmp.XYZmm = CLUtmp.XYZmm(:,wh);
    CLUtmp.XYZ = CLUtmp.XYZ(:,wh);
    CLUtmp.Z = CLUtmp.Z(:,wh);
    cl2{i} = tor_extract_rois([],CLUtmp,CLUtmp);
    
    if i == 1
        cluster_orthviews(cl2{i},colors(i));
    else
        cluster_orthviews(cl2{i},colors(i),'add');
    end
end
f1 = findobj('Tag','Graphics'); % spm fig window handle

figure(f1)
han = axes('Position',[.52 .08 .45 .38]);
copyobj(h1,han); view(135,30); axis vis3d

set(gca,'FontSize',16)
title('Log frequency')
xlabel('Activation duration')
ylabel('Change Point')

drawnow


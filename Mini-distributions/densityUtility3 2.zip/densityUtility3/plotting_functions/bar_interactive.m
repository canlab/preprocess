function bar_interactive
% bar_interactive
%
% create interactive bar-plot that pops up in spm_orthviews window
%
% tor wager


% used in button-up fcn callback

global han      % handle of gui
global P        % names of images

global xnames   % x-axis names

global VOL      % volume info for images
global VDAT     % volume data

% -------------------------------------------------------------------
% * essential stuff for the viewing
% -------------------------------------------------------------------

% find the spm window, or make one from a p-image

fh = findobj('Tag','Graphics');
if isempty(fh) || ~ishandle(fh), cl = pmap_threshold; end
figure(fh)

set(gcf,'WindowButtonUpFcn','dat = bar_interactive_btnupfcn;')

return
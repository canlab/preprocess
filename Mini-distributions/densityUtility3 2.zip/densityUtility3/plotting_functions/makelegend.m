function makelegend(names,colors)

tor_fig; hold on;
for i = 1:length(names)
    
    
    h(i) = plot(0,0,colors{i},'MarkerFaceColor',colors{i}(1));
    
end

legend(h,names);

axis off

return
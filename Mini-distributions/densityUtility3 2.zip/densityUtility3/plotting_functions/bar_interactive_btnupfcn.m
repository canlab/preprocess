function dat = bar_interactive_btnupfcn;
% [dat] = bar_interactive_btnupfcn;
%
% function for loading and plotting hewma data from a voxel.  must have declared globals f,f2,VOL,EXPT
% see hewma_timeseries_plot, the shell function.

global han      % handle of gui
global P        % names of images

global xnames   % x-axis names

global VOL      % volume info for images
global VDAT     % volume data


% get image names
if isempty(P), 
    try load SETUP class_avg_images; P = class_avg_images;, catch, end
end

if isempty(P),
    P = spm_get(Inf,'*img','Select Images for bar plot');
end

% if no images selected, don't display anything.
if isempty(P), return, end
    
% get axis tick names
if isempty(xnames),
    try load SETUP Xinms; xnames = Xinms;, catch, end
end

VOL = spm_vol(P);
VOL(1).M = VOL(1).mat;    

% activate window
if isempty(han) || ~ishandle(han), 
    fh = findobj('Tag','Graphics');
    uicontrol(fh,'Style','Frame','Position',[.45 .02 .52 .5],...
        'BackgroundColor',[.8 .8 .8]);  % colored frame
    
    han = axes('Position',[.52 .08 .45 .38]);, 

else, axes(han);, end
set(gca,'FontSize',16);

% get coordinate
coord = spm_orthviews('Pos');
coord = mm2voxel(coord',VOL(1));
mm = round(spm_orthviews('Pos')');


% extract data and plot
if isempty(VDAT), 
    VDAT = spm_read_vols(VOL);
end

dat = squeeze(VDAT(coord(1),coord(2),coord(3),:));

hold off;
barh = bar(dat); set(barh,'FaceColor',[.7 .7 .7]);

set(gca,'XTickLabel',xnames);
title(sprintf('[x,y,z] = %3.0f, %3.0f, %3.0f',mm(1),mm(2),mm(3)),'FontSize',16);

return
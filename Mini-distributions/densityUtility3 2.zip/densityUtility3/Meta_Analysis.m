global DB
global cl

DB = []; cl = [];

Meta_Analysis_gui;
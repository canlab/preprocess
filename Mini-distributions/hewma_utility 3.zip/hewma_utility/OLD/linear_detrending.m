function Zdt = linear_detrending(Zm)

%
% Zm - nsub x T matrix;
%
% Zdt - linearly detrended version of Zm (baseline retained)
%


nsub = size(Zm,1);
T = size(Zm,2);

% Design matrix

X = zeros(T,2);
X(:,1) = 1;
X(:,2) = (1:T)'/T;


% Detrend

Zdt = zeros(size(Zm));

for i=1:nsub,
    
    beta = pinv(X)*Zm(i,:)';
    Zdt(i,:) = Zm(i,:) - beta(2)*X(:,2)';               % Remove linear trend - keep baseline
    
end;


return;
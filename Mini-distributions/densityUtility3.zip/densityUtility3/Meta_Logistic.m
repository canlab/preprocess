function DB = Meta_Logistic(DB,varargin)
% DB = Meta_Logistic(DB,[verbose],[mask image name])
% 
% NEEDS:
%
% to set up design:
%DB.(fields)   % lists of fields containing task conditions for each coordinate point
%DB.pointind   % indices of which coord points are in which unique
%                contrast
%DB.X
%
% to run analysis:
% DB.PP         % list of contrast image names
% DB.studyweight  % weights
% 'Activation.img' or a mask input argument (2nd arg).
%
% Examples:
% DB = Meta_Logistic(DB,2,.05)


global dims
global cols

spm_defaults; defaults.analyze.flip = 0;

if length(varargin) > 0, vb = varargin{1};, else, vb = 1;, end


% ---------------------------------------
% Set up design matrix
% names = contrast names, also output image names
% prunes DB
% ---------------------------------------
[X,names,DB] = Meta_Logistic_Design(DB);
cols = size(X,2);

w = DB.studyweight;
w = w - mean(w) + 1;    % weights should be mean 1 for logistic regression

DB.X = X; DB.Xnames = names;

% ---------------------------------------
% Set up images
% ---------------------------------------

% image dimensions, etc.
V = spm_vol(DB.PP(1,:));
Vall = spm_vol(DB.PP);

dims = V.dim(1:3);

if vb > 0, fprintf(1,'\n\t\tNew image dims: %3.0f %3.0f %3.0f %3.0f ',dims(1), dims(2), dims(3), cols),end

% ---------------------------------------
% brain masking
% e.g., could mask with overall activation image
% ---------------------------------------

mask = []; 
if length(varargin) > 1, 
    mask = varargin{2};, 
    if isstr(mask), Vm = spm_vol(mask);, mask = spm_read_vols(Vm);,
            % if a mask file, then load it
    elseif length(mask) == 1
        % if a number, treat this as threshold value for pa_overall
        % I recommend .001, which is a 0.1% chance of activating across all
        % tasks
        if ~(exist('Activation.img') == 2),
            try
                Vm = spm_vol('../Activation.img'); 
            catch
                P = spm_get(1,'Select Activation.img');
                Vm = spm_vol(P);
            end
        else
            Vm = spm_vol('Activation.img');
        end
        maskimg = spm_read_vols(Vm);,
        mask = real(maskimg > mask);  % threshold 
    end
end
if isempty(mask), mask = ones(dims);,end

nvox = mask(:); nvox = sum(nvox>0);
fprintf(1,'\nVoxels in mask: %3.2f\n',nvox);


                                   
% -------------------------------------------------------------------
% * for each slice...
% -------------------------------------------------------------------

fprintf(1,'\nRunning Logistic Regression Slice %02d',0)

for slicei = 1:dims(3)
    
    if vb > 1, t1 = clock;, fprintf(1,'\b\b%02d',slicei),end
    
    % returns image names
    process_slice(slicei,Vall,X,w,names,vb,mask(:,:,slicei));


    %if vb > 1, fprintf(1,'\t%6.0f s for slice',etime(clock,t1)),end
end


return







% -------------------------------------------------------------------
%
%
%
%
% * SUB-FUNCTIONS
%
%
%
%
% -------------------------------------------------------------------    
    
    
function process_slice(slicei,Vall,X,w,names,vb,varargin)

mask = []; if length(varargin) > 0, mask = varargin{1};, end
sl = []; if length(varargin) > 1, sl = varargin{1};, end

global dims
global cols

% -------------------------------------------------------------------
% * load the slice
% -------------------------------------------------------------------

if isempty(sl)
    
if vb > 0, fprintf(1,'Load >'), end 
et = clock;
if ~isempty(mask) & ~(sum(sum(sum(mask))) > 0)
    % skip it
    betas = NaN * zeros([dims(1:2) cols]);
    t = NaN * zeros([dims(1:2) cols]);
    p = NaN * zeros([dims(1:2) cols]);
    if vb > 0, fprintf(1,'\b\b\b\b\b\b');,end

    return
else
    sl = timeseries_extract_slice(Vall,slicei);
end

if vb > 1, fprintf(1,'\b\b\b\b\b\b elapsed: %3.0f s fitting',etime(clock,et)),end

else
    % we've already loaded the slice!
    
end

if ~isempty(mask), sl(:,:,1) = sl(:,:,1) .* mask;, end


% -------------------------------------------------------------------
% * find in-mask voxels
% -------------------------------------------------------------------

sumsl = sum(sl,3);  % sum of all contrasts

% find indices i and j for all in-mask voxels
wvox = find(sumsl ~= 0 & ~isnan(sumsl));
[i,j] = ind2sub(size(sl(:,:,1)),wvox);

%fprintf(1,[repmat('\b',1,19) '%3.0f voxels > '],length(i))


% -------------------------------------------------------------------
% * compute regression for each in-mask voxel
% -------------------------------------------------------------------

% output images -- initialize
betas = NaN * zeros([dims(1:2) cols]);
t = betas;
p = ones([dims(1:2) cols]);

Fmap = NaN * zeros([dims(1:2)]);
omnp = ones([dims(1:2)]);


et = clock;
warning off     % because of iteration limit
    
fprintf(1,'%04d',0);

for k = 1:length(i)

    y = squeeze(sl(i(k),j(k),:)); 
    
    % convert from weighted to indicator (on/off)
    % only works for spherical convolution!!
    y = double(y>0);

    [b,dev,stats]=glmfit(X,[y ones(size(y))],'binomial','logit','off',[],w); % pvals are more liberal than Fisher's Exact!

    % omnibus test - R^2 change test
    % --------------------------------------------------------
    sstot = y'*y;
    r2full = (sstot - (stats.resid' * stats.resid)) ./ sstot;
    dffull = stats.dfe;
    
    [br,devr,statsr]=glmfit(ones(size(y)),[y ones(size(y))],'binomial','logit','off',[],w,'off');
    r2red = (sstot - (statsr.resid' * statsr.resid)) ./ sstot;
    dfred = statsr.dfe;
    
    if r2full < r2red, fprintf(1,'Warning!'); r2red = r2full;,fprintf(1,'\b\b\b\b\b\b\b\b'); end
    [F,op,df1,df2] = compare_rsquare_noprint(r2full,r2red,dffull,dfred);
    % --------------------------------------------------------
    
    betas(i(k),j(k),:) = b(2:end);
    t(i(k),j(k),:) = stats.t(2:end);
    p(i(k),j(k),:) = stats.p(2:end);
    
    Fmap(i(k),j(k)) = F;
    omnp(i(k),j(k)) = op;
    
    if mod(k,100)==0, fprintf(1,'\b\b\b\b%04d',k);,end
    %if k == 1000, fprintf(1,'%3.0f s per 1000 vox.',etime(clock,et)), end
end
fprintf(1,'\b\b\b\b');

warning on

if vb > 1, fprintf(1,[repmat('\b',1,14+9) ' elapsed: %3.0f s'],etime(clock,et));, end

clear sl



% -------------------------------------------------------------------
% * write output images
% ------------------------------------------------------------------- 

emptyimg = zeros(dims);     % in case we need to create a new volume, used later as well
    
warning off
%if vb > 1, fprintf(1,'\n\tWriting output > '), end

for i = 1:cols

	write_beta_slice(slicei,Vall(1),betas,emptyimg,'beta_',names);
    write_beta_slice(slicei,Vall(1),t,emptyimg,'t_',names);
    write_beta_slice(slicei,Vall(1),p,emptyimg,'p_',names);
    
end

write_beta_slice(slicei,Vall(1),Fmap,emptyimg,'F_',{'Omnibus'});
write_beta_slice(slicei,Vall(1),omnp,emptyimg,'p_',{'Omnibus'});

warning on

if vb > 1, fprintf(1,[repmat('\b',1,14+1)]);, end
    
    
return







function Pw = write_beta_slice(slicei,V,betas,emptyimg,varargin)
% Pw = write_beta_slice(sliceindex,V,data,empty,prefix)
% Slice-a-metric version
warning off % due to NaN to int16 zero conversions
V.dim(4) = 16; % set to float to preserve decimals

prefix = 'check_program_';
names = {''};               % for field only
if length(varargin) > 0, prefix = varargin{1};,end      % field name
if length(varargin) > 1, names = varargin{2};,end       % level names

for voli = 1:size(betas,3) % for each image/beta series point
    %if voli < 10, myz = '000';, elseif voli < 100, myz = '00';, else myz = '000';,end
    V.fname = [prefix names{voli} '.img'];
    V.descrip = ['Created by Meta_Logistic'];

    % create volume, if necessary
    if ~(exist(V.fname) == 2), spm_write_vol(V,emptyimg);,end
        
    spm_write_plane(V,betas(:,:,voli),slicei);
    
    if ~(exist('Pw')==1), Pw = which(V.fname);, 
    else Pw = str2mat(Pw,which(V.fname));
    end
    
end



warning on
return
function [DB] = Meta_Select_Contrasts(DB)
% [DB] = Meta_Select_Contrasts(DB)
%
% Set up logistic regression design matrix from DB
%
% needs to set up design:
%DB.(fields)   % lists of fields containing task conditions for each coordinate point
%DB.pointind   % indices of which coord points are in which unique
%                contrast
%DB.x          % x coordinates, just to get # of points

global dolist
dolist = 1;

testfield = 'xxx';
X = []; Xnms = {};

while ~isempty(testfield)
    
    % get field name
    testfield = getfield(DB);
    
    if isempty(testfield), 
        % done
    else
            
        % get unique levels
        levels = getlevels(DB,testfield);

        % get indicators for these levels
        [ti,tasknms] = string2indicator(DB.(testfield),levels);

        X = [X ti];
        Xnms = [Xnms tasknms];
    end
    
end

% get only unique contrast entries
include = sum(X,2);

%inc_con = include(DB.pointind);

DB = Meta_Prune(DB,include);        % this excludes contrast-wise

%DB = prune(DB,include,inc_con);    % this excludes point-wise


% -----------------------------------------------------
% Re-do Final contrast weights
% -----------------------------------------------------

if isfield(DB,'SubjectiveWeights'),
    w = DB.rootn .* DB.SubjectiveWeights(DB.pointind);
else
    w = DB.rootn;
end

% these must sum to 1 !
DB.studyweight = w ./ sum(w);


return





function testfield = getfield(DB)
% Empty or field name from DB
global dolist

% list field names
fprintf(1,'Database field names\n---------------------------\n')
N = fieldnames(DB);
if dolist
    for i = 1:length(N),
        tmp = DB.(N{i}); len = length(tmp);
        if len == length(DB.x), fprintf(1,'%s\n',N{i});,end
    end

    fprintf(1,'\n');
    dolist = 0;
end

gook = [];
while isempty(gook)
    testfield = input('Enter field name or return if finished: ','s');

    if isempty(testfield),
        gook = 1;
    else
        gook = strmatch(testfield,N);
    end
    if isempty(gook), fprintf(1,'Not a field name.'); pause(1); fprintf('\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b');, end
end

return





function levels = getlevels(DB,testfield);

eval(['levels = DB.' testfield ';']);
levels = levels(DB.pointind);
[pts,ind] = unique(levels);

fprintf(1,'Unique values of this variable:\n');

for i = 1:size(pts,1), fprintf(1,'%3.0f\t%s\n',i,pts{i});,end
wh = input('Enter vector of levels to use: ');
levels = pts(wh);

return




function DB = prune(DB,include,inc_con)
% Empty or field name from DB

N = fieldnames(DB);
whp = find(include);
whc = find(inc_con);

% special for DB.pointind
%pind = zeros(size(DB.x)); pind(DB.pointind) = 1;
%pind = pind(whp);

for i = 1:length(N),
    
    tmp = DB.(N{i}); len = length(tmp);
    if ismatrix(tmp), len = size(tmp,1);,end
    
    if len == length(include), 
        DB.(N{i}) = tmp(whp);
    elseif len == length(inc_con), 
       if ismatrix(tmp),
           DB.(N{i}) = tmp(whc,:);
       else
           DB.(N{i}) = tmp(whc);
       end
    end
    
end

%DB.pointind = find(pind)';
%[DB.connumbers,DB.pointind] = unique(DB.Contrast);

% re-make pointind
for i = 1:length(DB.connumbers)
    wh = find(DB.Contrast == DB.connumbers(i));
    DB.pointind(i) = wh(1);
end

return





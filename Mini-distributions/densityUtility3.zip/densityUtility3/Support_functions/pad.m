function [x,L] = pad(x,L)
%x = pad(x,L)
% 
% pads x with zeros of length L
%
% or, if L is a vector, to longest of two (NOT DONE)
%
% COLUMN VECTORS

if length(L) == 1
    
    x = [x; zeros(L,size(x,2))];
    
else
    
end

return

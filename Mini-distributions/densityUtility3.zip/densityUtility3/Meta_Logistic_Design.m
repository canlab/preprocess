function [X,Xnms,DB] = Meta_Logistic_Design(DB)
% [X,Xnms,DB] = Meta_Logistic_Design(DB)
%
% Set up logistic regression design matrix from DB
%
% needs to set up design:
%DB.(fields)   % lists of fields containing task conditions for each coordinate point
%DB.pointind   % indices of which coord points are in which unique
%                contrast
%DB.x          % x coordinates, just to get # of points

global dolist
dolist = 1;


% -----------------------------------------------------
% Select conditions and build design matrix
% -----------------------------------------------------

testfield = 'xxx';
X = []; Xnms = {}; allti = [];

while ~isempty(testfield)
    
    % get field name
    testfield = getfield(DB);
    
    if isempty(testfield), 
        % done
    else
            
        % get unique levels
        levels = getlevels(DB,testfield);

        % get indicators for these levels
        [ti,tasknms] = string2indicator(DB.(testfield),levels);

        % get contrast coded regressors (1 to 3 regs allowed now)
        [con,conname] = getcontrasts(ti,tasknms);

        for i = 1:length(conname), conname{i} = [testfield '_' conname{i}];,end
        
        allti = [allti ti];
        X = [X con];
        Xnms = [Xnms conname];
    end
    
end

% -----------------------------------------------------
% Prune database based on in-analysis points (contrasts)
% -----------------------------------------------------

% get only unique contrast entries
include = sum(allti,2);
%inc_con = include(DB.pointind);


%DB = prune(DB,include,inc_con);     % makes new pointind; this excludes
%point-wise

DB = Meta_Prune(DB,include);        % this excludes contrast-wise

%exclude_cons = ~inc_con;

% -----------------------------------------------------
% Prune design matrix
% -----------------------------------------------------
Xpts = X;
X = X(DB.pointind,:);


% -----------------------------------------------------
% Re-do Final contrast weights
% -----------------------------------------------------

if isfield(DB,'SubjectiveWeights'),
    w = DB.rootn .* DB.SubjectiveWeights(DB.pointind);
else
    w = DB.rootn;
end

% these must sum to 1 !
DB.studyweight = w ./ sum(w);



diary DESIGN_REPORT.txt

fprintf(1,'\nDesign Reporting\n---------------------------\nRegressors:\n')
for i = 1:length(Xnms), fprintf(1,'%3.0f\t%s\n',i,Xnms{i});,end
c = cond(X);
fprintf(1,'\nCondition number (1 is good, higher is worse): %3.2f\n', c);

fprintf(1,'\nDependence (X''X) Matrix');
try
    print_matrix(X'*X,Xnms);
catch
end
fprintf(1,'\n')

diary off


return





function testfield = getfield(DB)
% Empty or field name from DB
global dolist

% list field names
fprintf(1,'Database field names\n---------------------------\n')
N = fieldnames(DB);
if dolist
    for i = 1:length(N),
        tmp = DB.(N{i}); len = length(tmp);
        if len == length(DB.x), fprintf(1,'%s\n',N{i});,end
    end

    fprintf(1,'\n');
    dolist = 0;
end

gook = [];
while isempty(gook)
    testfield = input('Enter field name or return if finished: ','s');

    if isempty(testfield),
        gook = 1;
    else
        gook = strmatch(testfield,N);
    end
    if isempty(gook), fprintf(1,'Not a field name.'); pause(1); fprintf('\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b');, end
end

return





function levels = getlevels(DB,testfield);

eval(['levels = DB.' testfield ';']);
levels = levels(DB.pointind);
[pts,ind] = unique(levels);

fprintf(1,'Unique values of this variable:\n');

for i = 1:size(pts,1), fprintf(1,'%3.0f\t%s\n',i,pts{i});,end
wh = input('Enter vector of levels to use: ');
levels = pts(wh);

return






function [con,conname] = getcontrasts(ti,tasknms);

if size(ti,2) == 1
    % simple predictor
    con = ti(:,1);
    conname = tasknms(1);
elseif size(ti,2) == 2
    % 2 levels, simple contrast
    con = ti(:,1) - ti(:,2);
    conname = {[tasknms{2} '-' tasknms{1}]};
elseif size(ti,2) == 3
    
    type = input('Enter coding type: contrast vs. dummy:','s');
    switch type
        case 'contrast'
            c = [1 -2 1; 1 1 -2]';
            con = ti * c;
            conname = {[tasknms{1} '+' tasknms{3} '-' tasknms{2}] [tasknms{1} '+' tasknms{2} '-' tasknms{3}]};
        case 'dummy'
            con = ti(:,1:end-1);
            conname = tasknms(1:end-1);
            for i = 1:length(conname),conname{i} = [conname{i} '-' tasknms{end}];,end
        otherwise
            error('type contrast or dummy!')
    end
else
    h = hadamard(4);
    %error('only two or three levels allowed until program is expanded.');
    % just treat this like a set of preds; don't re-parameterize
    con = ti(:,1:end-1);
    conname = tasknms(1:end-1);
    for i = 1:length(conname),conname{i} = [conname{i} '-' tasknms{end}];,end
end



function DB = prune(DB,include,inc_con)
% Empty or field name from DB

N = fieldnames(DB);
whp = find(include);
whc = find(inc_con);

% special for DB.pointind
%pind = zeros(size(DB.x)); pind(DB.pointind) = 1;
%pind = pind(whp);

for i = 1:length(N),
    
    tmp = DB.(N{i}); len = length(tmp);
    if ismatrix(tmp), len = size(tmp,1);,end
    
    if len == length(include), 
        DB.(N{i}) = tmp(whp);
    elseif len == length(inc_con), 
       if ismatrix(tmp),
           DB.(N{i}) = tmp(whc,:);
       else
           DB.(N{i}) = tmp(whc);
       end
    end
    
end

%DB.pointind = find(pind)';
%[DB.connumbers,DB.pointind] = unique(DB.Contrast);

% re-make pointind
for i = 1:length(DB.connumbers)
    wh = find(DB.Contrast == DB.connumbers(i));
    DB.pointind(i) = wh(1);
end

return





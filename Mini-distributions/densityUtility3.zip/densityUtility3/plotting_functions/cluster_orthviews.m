function cluster_orthviews(varargin)
% cluster_orthviews(inputs in any order)
%
% This function uses spm_orthviews to display activation blobs from a
% clusters structure on a canonical structural brain image. Multiple
% clusters may be plotted in multiple colors, and blobs may be added to an
% existing orthviews figure.
%
% inputs: 
% clusters structures
% colors cell array, e.g., {[0 0 1] [1 0 0] [0 1 0]}
% if no colors cell array, uses Z- or t-scores to color map
% 
% opt: 'add' to suppress making new orthviews
% 'copy' to copy to smaller subfigure with empty axis beside it
% 'unique' to display in unique colors for each cluster
% 'overlay', followed by name of image, to use a custom anatomical overlay

P = which('scalped_single_subj_T1.img');
donew = 1;  % new fig
docopy = 0;  % copy to new axis
dounique = 0;

cl = []; cols = [];

for i = 1:length(varargin)
    
    if iscell(varargin{i}), cols = varargin{i};,
    elseif isstruct(varargin{i}), cl{end+1} = varargin{i};,    
    elseif isstr(varargin{i})
        if strcmp(varargin{i}, 'add'), donew = 0;,end
        if strcmp(varargin{i},'copy'), docopy = 1;,end
        if strcmp(varargin{i},'unique'), dounique = 1;,end
        if strcmp(varargin{i},'overlay'), P = varargin{i+1};,end
    end
    
end

if isempty(P), P = which('scalped_single_subj_T1.img');, end

for i = 1:length(cl)
    CLU{i} = clusters2CLU(cl{i});
    if ~isfield(CLU{i},'Z'), CLU{i}.Z = ones(1,size(CLU{i}.XYZ,2));,end
    if min(size(CLU{i}.Z)) > 1, CLU{i}.Z = CLU{i}.Z(1,:);,end
end



if donew, warning off, spm_check_registration(P), warning on, end %spm_image('init',P), end

if dounique,
    % unique colors for each blob
    colors = {[1 0 0] [0 1 0] [0 0 1] [1 1 0] [1 0 1] [0 1 1]};
    % next 6 colors, make pastel
    for i = 1:length(colors), colors = [colors {colors{i} .* .5}];,end
    % next 6, add blue    
    for i = 7:12, colors = [colors colors(i)];, colors{end}(3) = colors{end}(3) + .5; ,end
    % next 6, add red    
    for i = 7:12, colors = [colors colors(i)];, colors{end}(1) = colors{end}(1) + .5; ,end
     
    
    %while length(colors) < length(cl), colors = [colors colors];, end
    
    ind = 1;
    for i = 1:length(cl)
        while length(colors) < length(cl{i})
            colors = [colors {rand(1,3)}];
        end
        for j = 1:length(cl{i})
            CLUtmp = clusters2CLU(cl{i}(j));
            if ~isfield(CLUtmp,'Z'), CLUtmp.Z = ones(1,size(CLUtmp.XYZ,2));,end
            if min(size(CLUtmp.Z)) > 1, CLUtmp.Z = CLUtmp.Z(1,:);,end
            spm_orthviews('AddColouredBlobs',1,CLUtmp.XYZ,CLUtmp.Z(1,:),CLUtmp.M,colors{ind})
            ind = ind + 1;
        end
    end
else
    % NO unique colors for each blob    
    for i = 1:length(cl)
  
        if isempty(cols) | length(cols) < i
            spm_orthviews('AddBlobs',1,CLU{i}.XYZ,CLU{i}.Z,CLU{i}.M)
        else
            spm_orthviews('AddColouredBlobs',1,CLU{i}.XYZ,CLU{i}.Z(1,:),CLU{i}.M,cols{i})
        end
    
    end
end       
    

if docopy
    hh = gcf;  
    h1 = get(hh,'Children');
    f1 = figure('Color','w'); c= copyobj(h1,f1);

    set(gcf,'Position', [ 210   322   929   407])    %[464 606 672./2 504./2])
    for i = 1:length(c)
        tmp = get(c(i),'Position'); tmp(3) = tmp(3) .* .5;
        set(c(i),'Position',tmp);
    end
    keyboard
end

mypos = mean(cl{1}(1).XYZmm,2);
if length(mypos) < 3, mypos = cl{1}(1).XYZmm; ,end
spm_orthviews('Reposition',mypos)

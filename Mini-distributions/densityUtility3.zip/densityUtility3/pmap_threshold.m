function pmap_threshold(pimg,searchmask,pt)
% pmap_threshold(pimg,img2,p-threshold)
%
% default is FDR
%
% pmap_threshold('Activation_thresholded_pmap.img',DB.maskname);
% pmap_threshold('Activation_thresholded_pmap.img',DB.maskname,.005);


if ~(exist('searchmask') == 1), searchmask = [];, end
if ~(exist('pt') == 1), pt = [];, end

V = spm_vol(pimg);
p = spm_read_vols(V);

if ~isempty(searchmask)
    m = spm_read_vols(spm_vol(searchmask));
    p = p + double(~m);                     % make out of mask values too big
end
    
tmp = p(:); tmp(p > 1-10*eps | isnan(p))=[];   % eliminate out-of-analysis voxels

nvox = length(tmp);

if isempty(pt)
    % FDR threshold
    pt = FDR(tmp,.05);                  % threshold  

    if isempty(pt), pt = -Inf;, end
    fdrstr = 'FDR';
else
    fdrstr = 'UNC';
end
    
% thresholded p image
p(p > pt) = NaN;

minp = min(tmp(tmp>0));      % replace zeros with min p-value so it extracts OK (just technical for display)
p(p<eps) = minp;

p = -log10(p);               % convert for display

sigvox = sum(tmp<pt);

fprintf(1,'Voxels: %3.0f, Threshold: %s p < %3.4f, Sig. Voxels = %3.0f\n',nvox,fdrstr,pt,sigvox);

if sigvox == 0, return, end


[d,f,e] = fileparts(V.fname); V.fname = fullfile(d,[f '_' fdrstr e]); V.descrip = ['-log10(pvalue)'];
spm_write_vol(V,p);

cl = mask2clusters(V.fname);

cluster_orthviews(cl);

return


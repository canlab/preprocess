function EXPT = get_expt_subdir(EXPT)

EXPT.subdir = [];
wc = input('Enter wildcard (e.g., 0*) :','s');
    
d = dir(wc);
    
for i = 1:length(d), EXPT.subdir{i} = d(i).name;,end

return


    
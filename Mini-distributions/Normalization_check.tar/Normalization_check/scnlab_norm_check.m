function EXPT = scnlab_norm_check(EXPT,varargin)
%
% EXPT = scnlab_norm_check(EXPT,[action string])
%
% action strings:
% 'get'     : gets image names
% 'check'   : calculates mutual information values
% 'both'    : get and check

action = 'both';
if length(varargin) > 0, action = varargin{1};,end

if strcmp(action,'get') | strcmp(action,'both')
    
    EXPT = getimages(EXPT);
    
end


if strcmp(action,'check') | strcmp(action,'both')
    
    Pmask = which('brain_avg152T1.img');
    if isempty(Pmask), Pmask = spm_get(1,'*img','Cannot find brain mask: please select');,end
    
    [ds,g,mystd,d,d2,c,c2,mi,b,eigv,eigval] = compare_subjects(EXPT.SUBJECT.het1spgr,Pmask,0,'Norm T1 vs. template',1,EXPT.subdir,EXPT.SUBJECT.P);  
    
    tmp = sortrows(ds,2); tmp = tmp(:,1) - tmp(:,3);
    EXPT.SUBJECT.global_t1 = g';
    EXPT.SUBJECT.std_t1 = mystd';
    EXPT.SUBJECT.names = ([{'Dist. from group, actual-expected chi2'}, {'Mutual info with template'},{'Correlation with template'}]);
    EXPT.SUBJECT.norm_vs_template = [tmp mi' c'];
    
    
    try
        saveas(gcf,['subjplot_Norm_vs_Temp'],'fig'), 
        saveas(gcf,['subjplot_Norm_vs_Temp'],'tif'), close
        saveas(gcf,['multdist_Norm_vs_Temp'],'fig'), 
        saveas(gcf,['multdist_Norm_vs_Temp'],'tif'), close
    catch
        disp('Cannot save images');
    end
    
    
    [ds,g,mystd,d,d2,c,c2,mi,b,eigv,eigval] = compare_subjects(EXPT.SUBJECT.meanfunct,Pmask,0,'Mean norm funct vs. group',1,EXPT.subdir);
    
    tmp = sortrows(ds,2); tmp = tmp(:,1) - tmp(:,3);
    EXPT.SUBJECT.global = g';
    EXPT.SUBJECT.stdev = mystd';
    EXPT.SUBJECT.names2 = ([{'Dist. from group, actual-expected chi2'}, {'Mutual info with grp. mean'},{'Correlation with grp. mean'}]);
    EXPT.SUBJECT.funct_vs_group = [tmp mi' c'];
    
    try
        saveas(gcf,['subjplot_Func_vs_Group'],'fig'), 
        saveas(gcf,['subjplot_Func_vs_Group'],'tif'), close
        saveas(gcf,['multdist_Func_vs_Group'],'fig'), 
        saveas(gcf,['multdist_Func_vs_Group'],'tif'), close
    catch
        disp('Cannot save images');
    end
    
    
    plot_results(EXPT)
   
    
    keyboard
end

    
    
    
    
    
    
function EXPT = getimages(EXPT)  
    

% normalized structural vs. canonical
% normalized structural vs. mean norm functional
% mean norm functional vs. group

% default
P = 'scalped_avg152T1.img';  % canonical
normhi = 'whet1spgr.img';               % normalized hi-res T1 - check against canonical
%hires = 'het1spgr.img';                 % hi-res T1: check against functional
funct = 'mean_snwMCavol.img';             % mean functional in first scan directory
wcard = 'sw*img';                     % wildcard to search for funct images if mean doesn't exist

EXPT = get_expt_subdir(EXPT);
EXPT.SUBJECT.het1spgr = [];
EXPT.SUBJECT.meanfunct = [];

% canonical
EXPT.SUBJECT.P = which(P);
if isempty(EXPT.SUBJECT.P), disp(['Warning: cannot find canonical image: ' P]),end


    
% get normalized images
disp('Normalized Hi-res images:')
    
for i = 1:length(EXPT.subdir)

    str = fullfile(pwd,EXPT.subdir{i},'anatomy',normhi);
    d = dir(str);
   
    if ~isempty(d)
    
        if isempty(EXPT.SUBJECT.het1spgr)
            EXPT.SUBJECT.het1spgr = str;
        else
            EXPT.SUBJECT.het1spgr = str2mat(EXPT.SUBJECT.het1spgr,str);
        end

    else
        disp(['Missing: ' str])
    end
    
end


% get functional images

disp('Mean functional images:')
    
for i = 1:length(EXPT.subdir)
    
    str = fullfile(pwd,EXPT.subdir{i},funct);
    d = dir(str);
    
    if isempty(d)
        disp(['Missing and attempting to create: ' str])
        
        str2 = fullfile(pwd,EXPT.subdir{i},'scan1',wcard);
        df = dir(str2);
        
        if isempty(df),
            disp(['Warning - No images: ' str2]);
        else
            str2 = repmat(fullfile(pwd,EXPT.subdir{i},['scan1' filesep]),length(df),1);
            str2 = [str2 str2mat(df.name)];
            
            tor_spm_mean_ui(str2,str);
        end
    else
            
        if isempty(EXPT.SUBJECT.meanfunct)
            EXPT.SUBJECT.meanfunct = str;
        else
            EXPT.SUBJECT.meanfunct = str2mat(EXPT.SUBJECT.meanfunct,str);
        end

    end
    
end


return




function plot_results(EXPT)


 % plot results
    % ____________________________________________________________
    
    tmp = scale(EXPT.SUBJECT.norm_vs_template); tmp2 = tmp;
    
    % save best two and worst two overall
    overall = tmp; overall(:,2:3) = -1*overall(:,2:3); overall = mean(overall,2);   % higher is worse
    EXPT.SUBJECT.overall_t1 = overall; overall2 = overall;
    tmp = find(overall == min(overall)); wh(1) = tmp; overall(tmp) = NaN;
    tmp = find(overall == min(overall)); wh(2) = tmp; overall(tmp) = NaN;
    tmp = find(overall == max(overall)); wh(3) = tmp; overall(tmp) = NaN;
    tmp = find(overall == max(overall)); wh(4) = tmp; overall(tmp) = NaN;
    P = str2mat(EXPT.SUBJECT.P,EXPT.SUBJECT.het1spgr(wh,:));
    EXPT.SUBJECT.best_t1 = P(1:2,:);
    EXPT.SUBJECT.worst_t1 = P(3:4,:);
    P
    try, spm_check_registration(P);,
    
        h = sort(get(gcf,'Children'));
        axes(h(3)); title('Canonical template');
        axes(h(7)); title(['Best: ' EXPT.subdir{wh(1)}]);
        axes(h(11)); title(['Best: ' EXPT.subdir{wh(2)}]);
        axes(h(15)); title(['Worst: ' EXPT.subdir{wh(3)}]);
        axes(h(19)); title(['Worst: ' EXPT.subdir{wh(4)}]);
        
        h2 = axes('Position',[.6 .05 .3 .25]);
        plot(tmp2,1:length(tmp2)); try, legend(EXPT.SUBJECT.names),catch,end, 
        hold on; plot(overall2,1:length(overall),'ko-','LineWidth',2);drawnow
        set(gca,'YTickLabel',EXPT.subdir,'YTick',1:length(overall))
        xlabel('Value (higher is worse for black and blue lines)')
    catch,
    end
    
    saveas(gcf,'Best_and_worst_t1','fig');
    saveas(gcf,'Best_and_worst_t1','tif');

    disp('Type "return" and then press return to continue.')
    keyboard
    
    
    tmp = scale(EXPT.SUBJECT.funct_vs_group); tmp2 = tmp;
    
    drawnow
    
    % save best two and worst two overall
    overall = tmp; overall(:,2:3) = -1*overall(:,2:3); overall = mean(overall,2);   % higher is worse
    EXPT.SUBJECT.overall_funct = overall; overall2 = overall;
    tmp = find(overall == min(overall)); wh(1) = tmp; overall(tmp) = NaN;
    tmp = find(overall == min(overall)); wh(2) = tmp; overall(tmp) = NaN;
    tmp = find(overall == max(overall)); wh(3) = tmp; overall(tmp) = NaN;
    tmp = find(overall == max(overall)); wh(4) = tmp; overall(tmp) = NaN;
    P = str2mat(EXPT.SUBJECT.P,EXPT.SUBJECT.meanfunct(wh,:));
    EXPT.SUBJECT.best_funct = P(1:2,:);
    EXPT.SUBJECT.worst_funct = P(3:4,:);
    P
 
        try, spm_check_registration(P);,
    
        h = sort(get(gcf,'Children'));
        axes(h(3)); title('Canonical template');
        axes(h(7)); title(['Best: ' EXPT.subdir{wh(1)}]);
        axes(h(11)); title(['Best: ' EXPT.subdir{wh(2)}]);
        axes(h(15)); title(['Worst: ' EXPT.subdir{wh(3)}]);
        axes(h(19)); title(['Worst: ' EXPT.subdir{wh(4)}]);
        
        h2 = axes('Position',[.6 .05 .3 .25]);
        plot(tmp2,1:length(tmp2)); try, legend(EXPT.SUBJECT.names),catch,end, 
        hold on; plot(overall2,1:length(overall),'ko-','LineWidth',2);drawnow
        set(gca,'YTickLabel',EXPT.subdir,'YTick',1:length(overall))
        xlabel('Value (higher is worse for black and blue lines)')
        
    catch,
    end

    saveas(gcf,'Best_and_worst_funct','fig');
    saveas(gcf,'Best_and_worst_funct','tif');
    
return


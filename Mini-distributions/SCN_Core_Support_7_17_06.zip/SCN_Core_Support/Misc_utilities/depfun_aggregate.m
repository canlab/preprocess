% dependencies = depfun_aggregate(funname, excludes)
%   INPUTS
%       funname - function to analyze
%       excludes - cellstrs to exclude from the matches
%
% E.g.:
%   dependencies = depfun_aggregate('whole_brain_fir', 'spm2')

function dependencies = depfun_aggregate(funname, excludes)

    dependencies = depfun(funname, '-quiet');
    dependencies = remove_str_from_cell(dependencies, '/MATLAB');
    
    excludes = cellstr(excludes);
    for i=1:length(excludes)
        dependencies = remove_str_from_cell(dependencies, excludes{i});
    end

    tmpdir = 'tmp_files';
    mkdir(tmpdir);

    %NB: copyfile() should be used for platform-independence, but 
    %its handling permissions incorrectly on my machine - Matthew!rm 
    for i = 1:length(dependencies)
        system(['cp ' dependencies{i} ' ' tmpdir '/']);
%         copyfile(dependencies{i}, 'tmp_files/'); 
        fprintf(1, 'Copied %s to %s.\n', dependencies{i}, tmpdir);
    end
end
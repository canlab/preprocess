function f1 = nmdsfig(pc,varargin)
% f1 = nmdsfig(pc,[clus],[names],[sigmat],[thresh vector],[legend str],[sigmat2],[colors])
%  
%------------------------------------------------------------------------ 
%
%  Create a 1-D or 2-D plot with stimulus coordinates
%  
%------------------------------------------------------------------------ 
%
% pc is objects x dimensions
% clus is a vector of object classes
% names is cell array of names for rows of pc (objects), or empty ([])
%
% sigm is optional matrix of 1, -1, and 0 entries
% signifies which pairs to connect with lines
% positive elements are solid lines, negative elements are dashed
% -- Can be a series of t-maps in 3-D array
%
% [opt] threshold vector of critical t-values, e.g., [2.2 5.4]
% If used, enter t-maps in sigmat
% 
% [opt] a 2nd sigmat, if entered, will plot dashed lines instead of solid
% ones.  this is used by cluster_nmdsfig to plot interactions between
% covariance and behavioral scores
%
% example:
% nmdsfig(pc,clus,names,sigmat);
%
%x = randn(5,2);
%y = [1 1 1 2 2]';
%c = eye(5); c(1,2) = 1; c(1,4) = -1; c(2,3) = 1;
%nmdsfig(x,y,[],c)
%
% example:
% dat = [];
% for i = 1:length(cl), dat=[dat cl(i).BARPLOT.data(:,2)];,end
% [r,p]=corrcoef(dat);
% sig = sign(r) .* (p < .05);
% pc = princomp(dat);
% d = squareform(pdist(dat'));
% [r,p]=corrcoef(dat); r(r>.9999) = 1; D = (1 - r) .^ .5;
% [pc,obs,imp] = shepardplot(D,5);
% pc = cmdscale(d);
% nmdsfig(pc,[],[],sig);
% tor_fig;
% nmdsfig(pc,[],[],sig);
%

% --------------------------------------
% set up defaults
% --------------------------------------


% Draw Lines
clus=ones(1,size(pc,1));
if length(varargin)>0
    clus = varargin{1};
end

for i = 1:size(pc,1);
        names{i} = ['V' num2str(i)];
end;
if length(varargin)>1
    names=varargin{2};
end

    sigmat=[];
if length(varargin) >2; 
    sigmat  = varargin{3}; 
end

thr = 0;
if length(varargin) > 3
    thr  = varargin{4};
    thr = sort(thr);        % thresholds in ascending order, dark to light
end
legmat={'positive','negative'};
if length(varargin) > 4; 
    legmat=varargin{5};
end

sigmat2 = [];
if length(varargin) > 5; 
    sigmat2=varargin{6};
end

colors = {'ro' 'go' 'bo' 'yo' 'co' 'mo' 'ko' 'r^' 'g^' 'b^' 'y^' 'c^' 'm^' 'k^'};
if length(varargin) > 6; 
    colors=varargin{7};
end
while max(clus) > length(colors), colors = [colors colors];,end
if length(colors{1}) == 2,
    colormode = 'text';
elseif length(colors{1}) == 3,
    colormode = 'vector';
else
    error('I don''t understand the format of the colors input.');
end

% --------------------------------------
%%% remove extra dimensions for plotting;
% --------------------------------------
if size(pc,2)>2;
    disp('removing last dimensions for plotting');
elseif size(pc,2)==1;
    disp('switching to 1D configuration plot');
    nmdsfig1D(pc,clus,names,varargin);
    return
end
pc=pc(:,1:2);


% --------------------------------------
%%% draw figure
% --------------------------------------

% --------------------------------------
% set up colour and line thickness parameters
% --------------------------------------

if length(thr) > 1,
    sigmat = repmat(sigmat,[1 1 length(thr)]);    
    % choose colors
    sigcol = [.5 0];  %.5:-.5./length(thr):0;
else
    sigcol = 0;       % black, width = 3
end

% --------------------------------------
% if multiple thr are entered, treats sigmat as a series of t-value maps
% replicate sigmat and threshold, then draw
% --------------------------------------
if ~isempty(sigmat);
for i = 1:length(thr)
    wh = sign(sigmat(:,:,i)) .* (abs(sigmat(:,:,i)) >= thr(i));   % preserve pos or neg t-values
    [hh1,hh2] = drawlines(pc,wh,sigcol(i),legmat);    
end
end


% --------------------------------------
% if a 2nd sigmat is entered, plot dotted lines
% 
% --------------------------------------
if ~isempty(sigmat2);
for i = 1:length(thr)
    wh = sign(sigmat2(:,:,i)) .* (abs(sigmat2(:,:,i)) >= thr(i));   % preserve pos or neg t-values
    [hh3,hh4] = drawlines(pc,wh,sigcol(i),legmat,[1 0 0; 1 1 0],[{':'} {':'}]);    
end
hh = [hh1 hh2 hh3 hh4];
wh = zeros(1,4);
if isempty(hh1), wh(1) = 1; ,end
if isempty(hh2), wh(2) = 1; ,end
if isempty(hh3), wh(3) = 1; ,end
if isempty(hh4), wh(4) = 1; ,end
legmat(find(wh)) = [];
legend(hh,legmat);
end



% --------------------------------------
% plot points
% --------------------------------------

hold on
for j = 1:max(clus)
     switch colormode
         case 'text'
             plot(pc(clus == j,1),pc(clus == j,2),colors{j},'MarkerFaceColor',colors{j}(1),'LineWidth',2,'MarkerSize' ,6)
         case 'vector'
             plot(pc(clus == j,1),pc(clus == j,2),'o','Color',colors{j},'MarkerFaceColor',colors{j},'LineWidth',2,'MarkerSize' ,6)             
     end
end
if ~isempty(names)
    for i =  1:size(pc,1)
        text(pc(i,1)+.025*[max(pc(:,1))-min(pc(:,1))],pc(i,2)+.0,names{i},'Color','b','FontSize',18);
    end
end

xlabel('Component 1'),ylabel('Component 2')
%set(gca,'XTickLabel',{[]});  
%set(gca,'YTickLabel',{[]});  

axis equal;


return


function [hhp,hhn] = drawlines(pc,sigmat,sigcol,legmat,varargin)
    
% sigcol is a scalar between zero and one, lower is 'more salient'
hold on

% linew
lw = 2;

color(1,:) = [0 0 0];   % first line color, 'positive'
color(2,:) = [0 1 1];   % second line color, 'negative'
style{1} = '-';         % first line style
style{2} = '-';         % second line style

if length(varargin) > 0, color = varargin{1}; end
if length(varargin) > 1, style = varargin{2}; sigcol = 0; end

hhp=[];hhn=[];
for i=1:size(pc,1);
     for j=1:size(pc,1);
         if sigmat(i,j) > 0
             hhp = line([pc(i,1) pc(j,1)],[pc(i,2) pc(j,2)]);
             set(hhp,'Color',color(1,:) + [1 1 1] * abs(sigcol),'LineStyle',style{1},'LineWidth',lw - (lw*sigcol)-1)
         elseif sigmat(i,j) < 0
             hhn = line([pc(i,1) pc(j,1)],[pc(i,2) pc(j,2)]);
             set(hhn,'Color',color(2,:) + abs([sigcol sigcol 0]),'LineStyle',style{2},'LineWidth',lw - (lw*sigcol)-1)
         end
     end
end
%legend ([hhp hhn],legmat);
return



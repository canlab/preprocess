% p = FILENAMES(pattern, [['absolute'],['cellstr'|'char']])
%
% A utility function that uses ls or dir on a pattern and returns a list of
% filenames
% OPTIONS:
%   'absolute' - forces filenames to have an absolute path from root - default
%       is to return based upon the pattern (i.e., a relative pattern will
%       produce relative paths, an absolute pattern will return absolute
%       paths
%   'cellstr' - returns filenames as a cell array of strings, a cellstr -
%      this is the default behavior
%   'char' - return filenames as a character array

function p = filenames(pattern, varargin)

    returnChar = 0;
    mustBeAbsolute = 0;

    for i=1:length(varargin)
        switch(varargin{i})
            case 'char'
                returnChar = 1;
            case 'cellstr'
                returnChar = 0;
            case 'absolute'
                mustBeAbsolute = 1;
            otherwise
                warning('Unknown parameter in %s: ''%s''', mfilename(), varargin{i});
        end
    end

    if(mustBeAbsolute && ~localIsAbsolutePath(pattern))
        pattern = fullfile(pwd(), pattern);
    end

    isPCandIsRelative = localPcIsRelativePath(pattern);
    command = localShellCommand(pattern, isPCandIsRelative);
    [status, output] = system(command);
    outputString = java.lang.String(output);

    if(outputString.indexOf('Parameter format not correct') ~= -1)
        error('Incorrect format for "%s". Are you sure you''re using the right kind of slashes?', pattern);
    elseif(outputString.indexOf('No such file or directory') ~= -1 || outputString.indexOf('File Not Found') ~= -1)
        if(returnChar), p = []; else p = {}; end
    else
        p = char(outputString.split('\n'));
        if(isPCandIsRelative)
            [basepath, dummy, dummy, dummy] = fileparts(pattern);
            if(~isempty(basepath))
                p = [repmat([basepath filesep()], size(p,1), 1) p];
            end
        end
        if(~returnChar)
            p = cellstr(p);
        end
    end

end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Subfunctions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function command = localShellCommand(pattern, isPCandIsRelative)
    if(isunix())
        command = sprintf('ls -1d %s', escapeForShell(pattern));
    elseif(ispc())
        whfileseps = strfind(pattern, filesep());
        whwildcards = strfind(pattern, '*');
        % if there's a wildcard before the last file separator, we have a
        % problem
        if(length(whfileseps) > 0 && length(whwildcards) > 0 && whwildcards(1) < whfileseps(end))
            error('There appears to be a wildcard before the last file separator in "%s", which Windows cannot handle, unfortunately.', pattern);
        else
            if(isPCandIsRelative)
                command = sprintf('dir /B %s', escapeForShell(pattern));
            else
                command = sprintf('dir /B /S %s', escapeForShell(pattern));
            end
        end
    else
        error('What kinda system you got?');
    end
end


function isPCandIsRelative = localPcIsRelativePath(pattern)
    isPCandIsRelative = ispc() && ~localIsAbsolutePath(pattern);
end

function isAbsolute = localIsAbsolutePath(pattern)
    isAbsolute = 0;
    if(ispc() && (~isempty(strfind(pattern, '\\')) || ~isempty(strfind(pattern, ':\'))))
        isAbsolute = 1;
    elseif(isunix())
        location = strfind(pattern, '/');
        if(~isempty(location) && any(location == 1))
            isAbsolute = 1;
        end
    end
end

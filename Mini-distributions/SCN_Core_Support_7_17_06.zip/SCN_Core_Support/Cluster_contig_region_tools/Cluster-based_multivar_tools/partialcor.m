function [x,y,r,p,rrob,prob] = partialcor(X,y,i)
% function [x,y,r,p,rrob,prob] = partialcor(X,y,i)
% 
% partial correlation between column i of X and y
% X is n x k matrix of predictors (do not include intercept)
% y is n x 1 data vector
%
% x, y are adjusted predictor and data
% r, p are Pearson's correlation and p-value
% rrob and prob use robust IRLS.
%
% Warning: p-values are not adjusted for use of degrees of freedom in
% partial correlation computation w/o robust option!  OK for robust
%
% Modified by Tor Wager, July 2006
% :mean of y retained in case we're interested in the intercept
% :if X of interest is intercept, returns robust mean, controlling for
% other columns of X

x = X(:,i);

X(:,i) = [];

% add intercept if not already in model
no_intercept = any(all(diff(X)) < eps);
if no_intercept, X(:,end+1) = 1; end

W = X * pinv(X);

x = x - W * x;

% leave mean of y in in case we're interested in the intercept
y = y - W * y + mean(y);


if nargout > 2
    [r,p] = corrcoef(x,y);
    r = r(1,2); p = p(1,2);
end

if nargout > 4
    % robust IRLS
    
    [b,stats]=robustfit(X,y,'bisquare',[],'off');
    
    if all(x<eps)
        % x is an intercept; weighted mean
        rrob = stats.w' * y ./ sum(stats.w);
    else
        % weighted correlation
        rrob = weighted_corrcoef([x y],stats.w);
        rrob = rrob(1,2);
    end
    prob = stats.p(i);
    
end


return


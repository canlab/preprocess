% new Z-score based subclustering



% make meshgrid of Z-values for 3-d volume 



% get gradients for slices


% get mask of local maxima - gradient small (0?) and neighbors lower



% get mask of local maxima for slices transposed, to give 3 d



% combine masks to get 3-D local maxima




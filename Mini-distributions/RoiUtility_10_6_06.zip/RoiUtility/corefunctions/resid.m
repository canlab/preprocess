function [r,X] = resid(X,y)
% [r,X] = resid(X,y)
%
% tor wager
% residuals from model fit
%
% adds intercept, if missing

% find intercept
wint = find(all(X == repmat(X(1,:),size(X,1),1)));
if isempty(wint), X(:,end+1) = 1;,end

r = y - X * pinv(X) * y;

return

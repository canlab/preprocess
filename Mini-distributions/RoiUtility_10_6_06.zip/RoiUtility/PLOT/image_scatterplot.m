function h = image_scatterplot(P,meth,varargin)
% h = image_scatterplot(P,method(string),varargin)
% method = 'avgvs3'
% tor wager
% 

V = spm_vol(P); v = spm_read_vols(V);

switch meth
    case 'avgvs3'
        % plots the average of images 1 and 2 against values in 3
        % e.g., plot the average of task and control against the difference
        % or the avg of OLS and robust estimates against the difference
        
        disp('Plotting avg of v1 and v2 (x) against v3 (y)')
        
        v1 = squeeze(mean(v(:,:,:,1:2),4));
        v2 = squeeze(v(:,:,:,3));
        
    otherwise
        error('unknown action string')
end

v1 = v1(:); v2 = v2(:); 
wh = isnan(v1) | isnan(v2) | v1 == 0 | v2 == 0;
v1(wh) = []; v2(wh) = [];

figure('Color','w'); h = plot(v1,v2,'k.'), set(gca,'FontSize',16)

r = corrcoef(v1,v2);
disp(['r = ' num2str(r(1,2))])

return

function Ps = fullpath(Pspm)
% tor wager
% Pspm is file name with no path or relative path
% Searches for file in curr dir, then in specified dir
% Returns absolute path name (full path)

[d f e] = fileparts(Pspm);
Ps = which(['./' f e]);

if isempty(Ps)
    
    if ~isempty(d), 
        cwd = pwd;
        try
            eval(['cd(''' d ''')']);,
        catch
            warning('Specified directory does not exist!')
            Ps = [];
            return
        end
        
        Ps = which(Pspm);
        cd(cwd)
    end
end

return

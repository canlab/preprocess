function [eff,eff_vector] = calcEfficiency(contrastweights,contrasts,xtxitx,svi)
% function [eff,eff_vector] = calcEfficiency(contrastweights,contrasts,xtxitx,svi)
%
% contrastweights   a row vector of length equal to number of rows of contrasts indicating relative weights
% contrasts         a matrix of contrasts to test, one row per contrast, one col per condition in X
% xtxitx            pinv(X), where X is the design matrix
% svi               S * Vi, where S is the filtering matrix and Vi is the intrinsic autocorrelation matrix
%
% eff               overall efficiency, equal to eff_vector * contrastweights
% eff_vector        vector of efficency scores for each contrast
%
% by Tor Wager

if isempty(svi), svi = eye(size(xtxitx,2));,end

if ~isempty(contrasts)											% compute the variance of the contrasts
           try
			  eff_vector = diag(contrasts*xtxitx*svi*xtxitx'*contrasts');
              		  eff = length(eff_vector)./(contrastweights * eff_vector);
			  eff_vector = 1 ./ eff_vector;
              % it's 1/ because we want to minimize the variance, but we maximize fitnessMatrix value.
           catch
             disp('using contrasts: matrices or contrasts are wrong sizes!!!')
             disp('Trying to do: eff_vector = diag(contrasts*xtxitx*svi*xtxitx''*contrasts'')')
	        disp('...and then eff = length(eff_vector)./(contrastweights * eff_vector);')

             contrasts = contrasts	
             whos xtxitx
             whos svi
	         contrastweights = contrastweights
             xtxitx = diag(xtxitx*svi*xtxitx')
             error('Exiting...')
           end
           
		   
 else	
           if isempty(contrastweights),
               contrastweights = ones(1,size(xtxitx,1)-1);
           end
  
           try
			   eff_vector = diag(xtxitx*svi*xtxitx');
               eff = length(eff_vector)./([contrastweights 0] * eff_vector); % variance of chosen regressors.
               % eff_vector(eff_vector == 0) = .0001;
			   eff_vector = 1 ./ eff_vector;
           catch
               disp(['no contrasts version: wrong sizes!!!'])
               contrastweights = [contrastweights 0]
               whos xtxitx
               whos svi
               diag(xtxitx*svi*xtxitx')
               error('Exiting...')
           end

 end
 
 return
function [cl,names] = cluster_names(cl)
% function [cl,names] = cluster_names(cl)
%
% Assign names to cl(x).shorttitle
% Do not use spaces or underscores or special chars for best results
%


for i = 1:length(cl)
    
    goname = 1;
    
    if isfield(cl(i),'shorttitle'),
        % do nothing
        
        if ~isempty(cl(i).shorttitle)
            %  do nothing
            goname = 0;
        end
    end
        
    if goname
        cluster_orthviews(cl(i),{[1 0 0]});
        
        cl(i).shorttitle = input('Enter short name for this cluster: ','s');
        
        names{i} = cl(i).shorttitle;
    end
end


return
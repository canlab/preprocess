function p = filenames(pattern, varargin)
% p = filenames(pattern, [return char array?])
%
% A utility function that uses ls or dir on a pattern and returns a list of
% filenames
% Default is to return a cellstr, but a char array is also possible

returnchar = 0;

if(length(varargin) > 0)
    returnchar = varargin{1};
end

if(isunix())
    command = sprintf('ls -1d %s', pattern);
elseif(ispc())
    command = sprintf('dir /B %s', pattern);
else
    error('What kinda system you got?');
end

[status, output] = system(command);
outputString = java.lang.String(output);

% Special chars will break the code above.
% Look for problem; if we find one, try again with " " around pattern
if findstr(outputString,'Badly placed')
    % try again
    if(isunix())
        command = sprintf('ls -1d "%s"', pattern);
    elseif(ispc())
        command = sprintf('dir /B "%s"', pattern);
    else
        error('What kinda system you got?');
    end

    [status, output] = system(command);
    outputString = java.lang.String(output);
end

    
if(outputString.indexOf('No such file or directory') ~= -1 || outputString.indexOf('File Not Found') ~= -1)
    if(returnchar) p = []; else p = {}; end
elseif(returnchar)
    p = char(outputString.split('\n'));
else
    p = cellstr(char(outputString.split('\n')));
end

return
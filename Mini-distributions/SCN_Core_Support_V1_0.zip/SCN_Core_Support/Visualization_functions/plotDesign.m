function [X,d,out,hpreds] = plotDesign(ons,rt,TR,varargin)
% [X,d,out,hpreds] = plotDesign(ons,rt,TR,varargin)
%
% simple function to plot a design
% plots regressors and color-coded onset times as little sticks, with RT represented as height of the stick 
%
% ons is a cell array of onset times in s   OR a delta indicator function matrix
% rt is a cell array of rts for each onset event
% TR is the repetition time for sampling, in s
% optional argument is the y offset for plotting rts, default = 2
% 
% returns the model matrix (X) and the delta function d
%
% optional arguments
% 1     yoffset: default is 2
% 2     vector of epoch durations in s for each trial type, default is events
%
% examples:
% plot epochs of different lengths stored in conditions(*).stimlength
% [X3,d] = plotDesign(evtonsets,[],1,2,cat(2,conditions.stimlength));

rtin = rt;      % original rt, to tell if rt is values or empty
yoffset = 2;    
durs = []; out = [];
if length(varargin) > 0, yoffset = varargin{1};,end
if length(varargin) > 1, durs = varargin{2};, durs = durs ./ TR;, end

colors = {'r' 'g' 'b' 'c' 'm' 'y'};

% build models

if iscell(ons)
    [X,d] = onsets2delta(ons,TR);
else
    X = getPredictors(ons,spm_hrf(TR)./max(spm_hrf(TR)));
    d = ons; clear ons
    for i = 1:size(d,2)
        ons{i} = (find(d(:,i)) - 1) .* TR;
    end
end

if ~isempty(rtin),
    [X2,d2,out] = rt2delta(ons,rt,TR);
else
    % placeholder for plotting only
    for i = 1:length(ons), rt{i} = 1000 * ones(size(ons{i}));, end
end

while size(X,2) > length(colors), colors = [colors colors];,end


% make figure

figure('Color','w'); 
if ~isempty(rtin), subplot(4,1,1);,end
set(gca,'FontSize',16); hold on;
hpreds = [];

for i = 1:length(ons)
    
    hpreds(i) = plot(X(:,i),colors{i});

    h = plot([ons{i} ons{i}]'./(TR),[repmat(-yoffset,length(rt{i}),1) rt{i}]'./(1000.*TR) - yoffset,colors{i});
    
    if ~isempty(durs)
        for j = 1:length(ons{i})
            hh = drawbox(ons{i}(j)./TR,durs(i),colors{i},yoffset);    
        end
    end
    
end

title('Predicted activity')


% plot 2

if ~isempty(rtin), 
    
    subplot(4,1,2); set(gca,'FontSize',16); hold on;
    for i = 1:length(ons)
        
        plot(out.rtlinearX(:,i),colors{i})
        h = plot([ons{i} ons{i}]'./(TR),[repmat(-yoffset,length(rt{i}),1) rt{i}]'./(1000.*TR) - yoffset,colors{i});

    end
    title('Activity x reaction time (linear)')
    
    subplot(4,1,3); set(gca,'FontSize',16); hold on;
    for i = 1:length(ons)
        
        plot(out.rtquadX(:,i),colors{i})
        h = plot([ons{i} ons{i}]'./(TR),[repmat(-yoffset,length(rt{i}),1) rt{i}]'./(1000.*TR) - yoffset,colors{i});

    end
    title('Activity x reaction time (quadratic)')
    
    subplot(4,1,4); set(gca,'FontSize',16); hold on;
    ind = 1;
    for i = 1:length(ons)
        
        hh(1) = plot(out.rtclassX(:,ind),colors{i},'LineStyle','-'); ind = ind + 1;
        hh(2) = plot(out.rtclassX(:,ind),colors{i},'LineStyle','--'); ind = ind + 1;
        hh(3) = plot(out.rtclassX(:,ind),colors{i},'LineStyle',':'); ind = ind + 1;
        
        %tmp = find(out.rtclass(:,ind)); 
        %h = plot([tmp tmp]'./(TR),[repmat(-yoffset,length(rt{i}),1) rt{i}]'./(1000.*TR) - yoffset,colors{i});

    end
    
    legend(hh,{'Fast' 'Medium' 'Slow'})
    xlabel('Time (TRs)')
    title('Activity for trials classified by RT')
    
else
    % single plot, add x label
    if TR == 1, xlabel('Time (s)'), else, xlabel('Time (TRs)'),end
end


return



function h1 = drawbox(time,dur,color,yoffset);

x = [0 1 1 0]; x = x * dur + time;
y = [0 0 1 1] - yoffset; 

h1 = fill(x,y,color,'FaceAlpha',.5,'EdgeColor','none');

return


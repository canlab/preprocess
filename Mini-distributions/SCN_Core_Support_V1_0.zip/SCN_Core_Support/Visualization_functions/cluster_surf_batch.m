function surf_handles = cluster_surf_batch(varargin)
% surf_handles = cluster_surf_batch(varargin)
%
%
% Uses
% Single-map visualization
% ------------------------------------------------------------------
% P2 = threshold_imgs('rob_tmap_0001.img',tinv(1-.005,12),15,'pos');
% cluster_surf_batch(P2);
%
% surf_handles = cluster_surf_batch(cl,{[1 0 0]},cl2);
%
% Two maps with overlap
% ------------------------------------------------------------------
% surf_handles = cluster_surf_batch(cl,{[1 0 0] [0 1 0] [1 1 0]},cl2);


% Input arguments
% cl, then colors, then cl2, in that order

if length(varargin) == 0
    disp('Choose thresholded image to get clusters from.')
    imgname = spm_get(1);
    cl = mask2clusters(imgname);
    
elseif isstruct(varargin{1})
    cl = varargin{1};
    
elseif isstr(varargin{1})
    cl = mask2clusters(varargin{1});

else
    error('You must input either nothing, an image name, or a cluster structure.');
end

color = {[1 0 0]};
if length(varargin) > 1
    color = varargin{2};
end

cl2 = [];
if length(varargin) > 2
    cl2 = varargin{3};
end

mydistance = 5;

% Run surfaces

surfhan = cluster_surf(cl,cl2,mydistance,color);
set(gcf,'Color','w'); axis off; camzoom(1.3)

[hh1,hh2,hh3,hl,a1,a2,a3] = make_figure_into_orthviews;
view(180,-90); [az,el]=view; h = lightangle(az,el);

sh2 = cluster_surf(cl,cl2,mydistance,'left',color);
[az,el]=view; h = lightangle(az,el);set(gcf,'Color','w'); axis off;

sh3 = cluster_surf(cl,cl2,mydistance,'right',color);
[az,el]=view; h = lightangle(az,el);set(gcf,'Color','w'); axis off;

sh4 = cluster_surf(cl,cl2,mydistance,'bg',color);
lightRestoreSingle(gca);
[az,el]=view; h = lightangle(az,el);set(gcf,'Color','w'); axis off;



surf_handles = [surfhan sh2 sh3 sh4];
% function [P,newP] = reslice_imgs(sampleTo,resliceThis,[domask])
%
% arguments are file names of .img files
% if empty, select from GUI
%
% if domask, recalculates a 1 or 0 mask for each image file in resliceThis

function [P,newP] = reslice_imgs(sampleTo,resliceThis,varargin)
    domask = 0;
    if length(varargin) > 0, domask = varargin{1}; ,end

    flags.hold = -1;
    flags.which = 1;

    if isempty(sampleTo),
        sampleTo = spm_get(1,'*.img','Select image with desired dimensions',pwd,0);
    end

    if isempty(resliceThis),
        resliceThis = spm_get(Inf,'*.img','Select image(s) to resample',pwd,0);
    end

    P = str2mat(sampleTo,resliceThis);

    spm_reslice(P,flags)

    if domask
        disp('re-binarizing masks...')

        for i = 1:size(resliceThis,1)
            [d,f,e] = fileparts(deblank(resliceThis(i,:)));
            resliced_img = fullfile(d, ['r' f e]);
            spm_imcalc_ui(resliced_img,resliced_img,'i1>0');
        end
    end

    for i = 1:size(P,1)-1
        [d,f,e] = fileparts(P(i+1,:));
        if i==1,
            newP = fullfile(d, ['r' f e]);
        else
            newP = strvcat(newP, fullfile(d, ['r' f e]));
        end
    end

end

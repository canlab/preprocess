function g = tor_global(P,varargin)

    fprintf(1,'getting globals.\t')
    V = spm_vol(deblank(P(1,:)));
    mask = [];
    if mask == 0, mask = [];, end

    if length(varargin) > 0,
        mask = varargin{1};

        fprintf(1,'masking volumes.\t')
        % ----------------------------------------------------------------------------------
        % * load mask, and mask all subjects' contrast values
        % so that we show only those voxels existing for all subjects.
        % ----------------------------------------------------------------------------------
        Vm = spm_vol(mask);

        % check to make sure same dimensions

        chk = Vm.mat - V.mat; chk = chk(:);
        chk = chk(1:end-1);             % eliminate SPM scale factor
        chk = any(chk);

        if chk,
            % reslice mask if we need to
            fprintf(1,'(reslicing mask).\t')
            [tmp,mask] = reslice_imgs(varargin{1},deblank(P(1,:)),1);
            Vm = spm_vol(mask);
        end

        % get mask data
        mask = spm_read_vols(Vm);

        mask = double(mask ~= 0 & ~isnan(mask));
    end


    for i = 1:size(P,1)
        % for each image

        g(i,1) = get_global(deblank(P(i,:)),mask);

    end
end




function g = get_global(p,mask)
    dat = spm_read_vols(spm_vol(p));

    if ~isempty(mask), dat = dat .* mask;, end

    dat = dat(:);
    dat(isnan(dat) | dat == 0) = [];

    g = mean(dat);
end




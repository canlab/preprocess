function mask_image(img,mask,outname)
% mask_image(img,mask,outname)
%
% mask_image('n15_avgpet.img',EXPT.mask,'n15_avgpet_brain.img');

V = spm_vol(img); v = spm_read_vols(V);

M = spm_vol(mask); m = spm_read_vols(M);

if any(size(v) - size(m))
    error('Images are different sizes!');
    
else
    
    dat = double(v .* (abs(m) > 0));
    
    V.fname = outname;
    
    spm_write_vol(V,dat);
    
end

return


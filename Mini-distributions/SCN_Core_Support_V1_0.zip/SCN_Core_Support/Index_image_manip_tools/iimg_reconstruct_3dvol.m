function mask_vol = iimg_reconstruct_3dvol(dat,V)
% 
%
% Reconstruct a 3-D volume from a dat index list

mask_vol = reshape(dat,V.dim(1:3));

return


function res = depfun_aggregate(funname);

res = depfun(funname);
res = remove_str_from_cell(res,'/MATLAB72/');
%res = remove_str_from_cell(res,'/spm2/');

mkdir tmp_files

for i = 1:length(res)
    str = ['!cp ' res{i} ' tmp_files/'];
    disp(str);
    eval(str);
    
end

return
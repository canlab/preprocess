function x = intercept_model(nsess,varargin)
% x = intercept_model(nsess,[nruns],[Indx of dummy scans in each session])
%
% Build design matrix X for intercepts
% given vector of session lengths [s1 s2 s3] in images
% OR
% the total number of points and the number of runs
%
% tor wager, 2/9/05
% Modified May 12, 2006 to include dummy scan regressors
%
% Examples:
% nsess = [166 166 144 137];
% x = intercept_model(nsess);
%
% x = intercept_model(166*5,5);
%
%
% Xi = intercept_model(EXPT.FIR.nruns,[],1:2);

if length(varargin) > 0, nruns = varargin{1};,end

if length(nsess) == 1
    if ~exist('nruns'), error('Enter number of runs as 2nd arg or include all scans per sess in nsess vector');,end
    
    npoints = nsess;        % treat nsess as number of points total, will re-calc in a second
    scanlen = npoints/nruns;  
    if scanlen ~= round(scanlen),warning(['Scan length is not an integer! scanlen = ' num2str(scanlen) ', rounded = ' num2str(round(scanlen))]),end
    nsess = repmat(round(scanlen),1,nruns);
end

npoints = sum(nsess);   % number of time points total
nruns = length(nsess);  % number of runs

x = zeros(npoints,nruns);

st = cumsum([1 nsess]);   
en = st(2:end) - 1;         % ending values
st = st(1:end-1);           % starting values

for i = 1:nruns
    x(st(i):en(i),i) = 1;
end

if length(varargin) > 1 && ~isempty(varargin{2})
    % Model dummy regressors
    x = [x model_dummy(npoints,st',varargin{2})];
end

return



function x = model_dummy(npoints,st,wh)
% dummy regressors for first scan or two (at least, that's the intended
% use)

k = length(wh);
x = zeros(npoints,k);

for i = 1:k
    ind =st+wh(i)-2;    % which to filter
    ind(ind<=1) = [];   % if negative numbers (end of runs), this makes it ok
    x(ind,i) = 1;
end



return

function Pout = filename_get_new_root_dir(P)
% Pout = filename_get_new_root_dir(P)
%
% Append a new root directory to filenames

str = spm_get(-1,'*','Get new root directory');
[d,f,e] = fileparts(deblank(P(1,:)));
Pout = fullfile(str,[f e]);

for i = 2:size(P,1)
    
    [d,f,e] = fileparts(deblank(P(i,:)));
    
    Pout = str2mat(Pout,fullfile(str,[f e]));
    
end

return


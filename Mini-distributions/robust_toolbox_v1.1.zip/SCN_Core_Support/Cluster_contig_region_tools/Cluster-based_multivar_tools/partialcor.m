function [x,y,r,p,rrob,prob] = partialcor(X,y,i)
% function [x,y,r,p,rrob,prob] = partialcor(X,y,i)
% 
% partial correlation between column i of X and y
% X is n x k matrix of predictors (do not include intercept)
% y is n x 1 data vector
%
% x, y are adjusted predictor and data
% r, p are Pearson's correlation and p-value
% rrob and prob use robust IRLS.
%
% Warning: p-values are not adjusted for use of degrees of freedom in
% partial correlation computation!

x = X(:,i);

X(:,i) = [];

% add intercept
if ~any(sum(X) - size(X,1) < eps), X(:,end+1) = 1;, end

W = X * pinv(X);

x = x - W * x;

y = y - W * y;

if nargout > 2
    [r,p] = corrcoef(x,y);
    r = r(1,2); p = p(1,2);
end

if nargout > 4
    % robust IRLS
    
    [b,stats]=robustfit(x,y,'bisquare');
    rrob = weighted_corrcoef([x y],stats.w);
    rrob = rrob(1,2);
    prob = stats.p(2);
    
end


return


function voldata = iimg_reconstruct_3dvol(dat,maskInfo,varargin)
% voldata = iimg_reconstruct_3dvol(dat,maskInfo,[optional args])
% Reconstruct a 3-D volume from a dat index list
% 
%
%
% Optional inputs: if entered, will write .img file to disk
% 'outname', followed by output name
% 'descrip', followed by description for img file

% --------------------------------------
% * Make sure dat matches maskInfo info
% --------------------------------------
ndat = length(dat);

if ~isfield(maskInfo,'nvox') 
    error('maskInfo.nvox and other fields not found.  Use iimg_read_image.m to prepare maskInfo.'); 
end 
    
if ndat == maskInfo.nvox
    % assume data is in original image vector list; do nothing
    
else
    % assume data is only in-mask, and reconstruct
    
    if ~isfield(maskInfo,'n_inmask') || ~isfield(maskInfo,'nvox') 
        error('maskInfo.n_inmask and other fields not found.  Use iimg_read_image.m with extended output flag to prepare maskInfo.'); 
    end 
    if ndat == maskInfo.n_inmask

    dat2 = double(maskInfo.image_indx);
    dat2(maskInfo.wh_inmask) = dat;
    dat = dat2;
    
    else
        error('volume info in struct does not seem to match number of voxels in index image.');
    end
end

% --------------------------------------
% * Reshape to 3D
% --------------------------------------

voldata = reshape(dat,maskInfo.dim(1:3));
    


% --------------------------------------
% Optional output for writing image file to disk:
% --------------------------------------

if length(varargin) > 0
    
    descrip = 'Created by iimg_reconstruct_3dvol';
    
    for i = 1:length(varargin)
    arg = varargin{i};
    if ischar(arg)
        switch lower(arg)
            case 'outname', outname = varargin{i+1};
            case 'descrip', descrip = varargin{i+1};
        end
    end
    end

    outname = make_img_filename(outname);
    maskInfo.fname = outname;
    maskInfo.descrip = descrip;
        
    spm_write_vol(maskInfo,voldata);

end


return




function [name,d] = make_img_filename(name)

[d,name]=fileparts(name);
name = [name '.img'];

return

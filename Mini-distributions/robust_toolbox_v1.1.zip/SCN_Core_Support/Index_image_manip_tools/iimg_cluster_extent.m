function [dat,nvox] = iimg_cluster_extent(dat,volInfo,k)
%
% Apply a cluster size threshold to a series of index image data vectors
% (each img is one column)
% given volInfo (must be created with iimg_read_img, with extended output)

% do nothing if extent threshold
if isempty(k) || k < 2, nvox = [];, return, end

[clindx,nvox] = iimg_cluster_index(dat(volInfo.wh_inmask),volInfo.xyzlist',k);

for i = 1:size(dat,2)
    clindx2 = zeros(volInfo.nvox,1);    % put in original index dims
    clindx2(volInfo.wh_inmask) = clindx(:,i);

    dat(:,i) = dat(:,i) .* (clindx2 > 0);
end

return
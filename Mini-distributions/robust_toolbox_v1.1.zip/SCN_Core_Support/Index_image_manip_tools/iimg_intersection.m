function [maskindx,mask_vol,name] = iimg_intersection(varargin)
%[maskindx,mask_vol,name] = iimg_intersection(name1, name2, etc.)
%
% Make a mask of the intersection of n image files (pos or neg values)
%
% fastest if one output requested.
% 
if nargin == 0, imname = spm_get(1); else imname = varargin{1}; end

[V,dat] = iimg_read_img(imname);
maskindx = V.image_indx;

for i = 2:length(varargin)
    
    [maskindx] = iimg_mask(maskindx,dat(:,1));

end

if nargout == 2
    mask_vol = iimg_reconstruct_3dvol(dat,V);
    
elseif nargout == 3
        
        name = input('Enter output filename: ','s');
        
        mask_vol = iimg_reconstruct_3dvol(dat,V,'outname',name,'descrip','intersection image created with iimg_intersection');
        
end

return

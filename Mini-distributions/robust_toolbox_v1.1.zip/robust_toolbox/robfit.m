function EXPT = robfit(EXPT,varargin)
% EXPT = robfit(EXPT,[which cons],[dools],[mask])
%
% Tor Wager, last modified 4/12/04 to add OLS and difference maps
%
% This function does a robust fit on contrasts specified in EXPT.SNPM.connames,
% using images in EXPT.SNPM.P
% The model should be stored (without intercept) in EXPT.cov
% Empty EXPT.cov will result in a one-sample t-test
%
% For each contrast, it saves con, t, p, filtered t imgs, and clusters.mat 
% p-value images are 2-tailed!
%
% All predictors should be in a matrix of column vectors, stored in EXPT.cov.
% They are centered and scaled in this function.
% Intercept is added as 1st predictor
%
% see get_expt_info.m for how to make the EXPT structure
% fields should be:
% EXPT.SNPM.P           containing image names of individual subjects
% EXPT.SNPM.connames    str mtx of contrast names for each P string matrix
% EXPT.SNPM.connums     contrast numbers for each P
% EXPT.cov              empty for 1-sample ttest, or containing covariates
% [mask] is the name of the mask file to use
%
% [Which cons] optional vector of which arrays in EXPT.SNPM.P to use
% e.g., [1 2 4] runs the first, second, and 4th sets of image names
%
% Example:
% EXPT = robfit(EXPT,[6:2:29]);   
%
% DO OLS, cons 1-4, use gray matter mask
% mask = which('scalped_avg152T1_graymatter_smoothed.img');
% [dummy,mask] = reslice_imgs(EXPT.SNPM.P{1}(1,:),mask);   % reslice mask
% to image space
% EXPT = robfit(EXPT,1:4,1,mask);

linestr = '____________________________________________________________';

% -----------------------------------------------------
% center and scale predictors
% -----------------------------------------------------
if ~isfield(EXPT,'cov'), EXPT.cov = [];, end
covt = EXPT.cov;

if ~isempty(covt)
    
    fprintf(1,'Robfit.m\n%s\nPreparing covariates:\n',linestr);
    
    if length(covt) > size(covt,1), covt = covt'; fprintf(1,'Transposed covariate matrix.\n'); end
    
    for i = 1:size(covt,2)
    if all( covt==1 | covt == -1)
        fprintf(1,'Cov %3.0f: Contrast codes; no centering. Will be saved in rob_tmap_%04d\n',i,i+1);
        % Contrast codes; do not center; this gives Type III SS
    else
        fprintf(1,'Cov %3.0f: Centering and scaling to unit variance. Will be saved in rob_tmap_%04d\n',i,i+1);
        covt = scale(covt);
    end
    
    end
   
else
    fprintf(1,'Robfit.m\n%s\nIntercept only (no covariates) ',linestr);
end

EXPT.cov = covt;

fprintf(1,'%s\n',linestr);

% intercept: automatically added if doing robustfit.m
% covt = [ones(1,size(covt,1)) covt];
%covt(:,end+1) = 1;



if length(varargin)>0,wh=varargin{1};,else,wh=1:length(EXPT.SNPM.P);,end
if length(varargin)>1,dools = varargin{2};, else, dools = 1;, end
if length(varargin)>2,domask = varargin{3};, else, domask = 0;, end

% ----------------------------------------------------
% * set up the gui figure
% ----------------------------------------------------
f = [];
%f = figure('Color','w');
%tmp = get(gcf,'Position') .* [1 1 .5 .1];
%set(gcf,'Position',tmp)
%set(gcf,'MenuBar','none','NumberTitle','off')
%figure(f), set(gca,'Xlim',[0 100])

% ----------------------------------------------------
% * run robust regression for selected sets
% ----------------------------------------------------

for i = wh
    % * run robust regression 
    % ----------------------------------------------------
    warning off
    try,disp('');disp(['Robfit.m - working on ' EXPT.SNPM.connames(i,:)]),catch,end
    if dools, disp('Running OLS and IRLS comparison (slower) - to turn this off, use 0 as 3rd input argument.'),end
    disp(linestr)
    
    if dools
        [EXPT.SNPM.rob_betas{i},EXPT.SNPM.ols_betas{i}] = rob_fit(EXPT.SNPM.P{i},covt,EXPT.SNPM.connums(i),f,dools,domask);
    else
        [EXPT.SNPM.rob_betas{i}] = rob_fit(EXPT.SNPM.P{i},covt,EXPT.SNPM.connums(i),f,dools,domask);
    end
    warning on
    
    % * compare
    % ----------------------------------------------------


end



return



function [newP,newP2] = rob_fit(P,covt,index,f,dools,domask)

% --------------------------------------------
% find the in-analysis voxels
% --------------------------------------------

V = spm_vol(P); v = spm_read_vols(V);

% mask, if spc
if domask
    Vm = spm_vol(domask);, vm = spm_read_vols(Vm);,
    vm = repmat(vm,[1 1 1 size(v,4)]);
    v = v .* vm;
end

wh=sum(v,4);
wh = ~isnan(wh) & wh ~= 0; 
%wh(all(v == 0,4) = 0;
[x,y,z] = ind2sub(size(wh),find(wh));

tmp = sum(wh(:)); if tmp == 0, disp('No voxels in analysis!'), end
whplanes = unique(z);

% --------------------------------------------
% set up output arrays
% --------------------------------------------

for j = 1:size(covt,2) + 1
    %IRLS
    vo{j} = zeros(size(wh)) .* NaN;     % save betas
    vot{j} = zeros(size(wh)) .* NaN;    % save t values
    vop{j} = zeros(size(wh)) .* NaN;    % save p values
    
    % OLS
    vo2{j} = zeros(size(wh)) .* NaN;     % save betas
    vot2{j} = zeros(size(wh)) .* NaN;    % save t values
    vop2{j} = zeros(size(wh)) .* NaN;    % save p values
    
    % comparison between IRLS and OLS
    voz3{j} = zeros(size(wh)) .* NaN;    % save Z scores for difference
    vop3{j} = zeros(size(wh)) .* NaN;    % save p values
end
fprintf(1,'\nworking on %s (first subject)\n...and other images.\n%6.0f voxels, %3.0f planes in analysis\n\t',P(1,:),sum(wh(:)),length(whplanes))
fprintf(1,'Done: 000%%');
savewh = sum(wh(:));

% --------------------------------------------
% perform regression
% --------------------------------------------

for i = 1:length(x)
  
    t = squeeze(v(x(i),y(i),z(i),:));
    %   b = pinv(covt) * t;         % regular linear model fit
    
    % NEW way: uses Rousseeuw's algorithm - much slower
    % The problem is that this is biased towards finding results!  Improper
    % control of false positive rate.
    %Rousseeuw, P.J. (1984), "Least Median of Squares Regression," 
    %Journal of the American Statistical Association, Vol. 79, pp. 871-881.
    
    %[res]=fastmcd_noplot([covt t]);
    % remove n most extreme outliers and recompute correlation
    %wh = res.flag==0; tnew = t; xnew = covt;
    %tnew(wh) = []; xnew(wh,:) = [];
    %[bb,dev,stats] = glmfit(xnew,tnew);

    % * fit models for IRLS and OLS
    % ----------------------------------------------------  
    
    % robustfit, IRLS, 
    doirls = 1; %dools = 1;
    if doirls
        if isempty(covt)
            % intercept only (one-sample t-test)
            [bb,stats]=robustfit(ones(length(t),1),t,'bisquare',[],'off');   
        else
            [bb,stats]=robustfit(covt,t);           
        end
      
    end % if robustfit
    
    for j = 1:length(bb)
        vo{j}(x(i),y(i),z(i)) = bb(j);
        vot{j}(x(i),y(i),z(i)) = stats.t(j);
        vop{j}(x(i),y(i),z(i)) = stats.p(j);
    end
    
    
    if dools
        if isempty(covt)
            % intercept only (one-sample t-test)
            [bb2,dev,stats2]=glmfit(ones(length(t),1),t,[],[],'off',[],[],'off');
        else
            [bb2,dev,stats2]=glmfit(covt,t);           
        end
        
        for j = 1:length(bb)
            vo2{j}(x(i),y(i),z(i)) = bb2(j);
            vot2{j}(x(i),y(i),z(i)) = stats2.t(j);
            vop2{j}(x(i),y(i),z(i)) = stats2.p(j);
        end
        
        % * calculate Z-test for comparison
        % ----------------------------------------------------
        if i == 1, df = stats2.dfe;, [mn,vv] = tstat(df); end
        
        zdiff = stats.t ./ sqrt(vv) - stats2.t ./ sqrt(vv); % z-scores by dividing by t-distribution variance
        zdiff = zdiff ./ sqrt(2);                           % diff between z-scores is distributed with var=sum of var(z1) + var(z2)
                                                            % ...thus,sigma
                                                            % (z1 - z2) = sqrt(2) 
                                                            % e.g., - http://www.mathpages.com/home/kmath046.htm
        pdiff = 2 * (1 - normcdf(abs(zdiff)));              % 2-tailed
         
        for j = 1:length(bb)
            voz3{j}(x(i),y(i),z(i)) = zdiff(j);
            vop3{j}(x(i),y(i),z(i)) = pdiff(j);
        end
    end



    if rem(i,100) == 0
        %figure(f), try,barh(100*i / length(x)),catch,end
        %set(gca,'Xlim',[0 100]),set(gca,'YTickLabel',i),drawnow
        %text(5,.5,['Voxel ' num2str(i) ' of ' num2str(length(x))],'Color','r')
        fprintf(1,'\b\b\b\b%03d%%',round(100*i / length(x)));
    end
   
end
fprintf(1,' done. ')
fprintf(1,'\twriting volumes.\n')

if index < 10, myz = '000';, else, myz = '00';, end
mydir = ['robust' myz num2str(index)];
eval(['mkdir ' mydir])
cd(mydir)

% save setup stuff
try
    SETUP.files = P;
    SETUP.covariates = covt;
    SETUP.V = V;
    SETUP.planes = whplanes;
    SETUP.nvoxels = savewh;
    SETUP.sample_robust_res = res;
    SETUP.df = df;
    save SETUP SETUP
catch
    warning('Error creating SETUP file');
end

V = V(1); [d,f,e] = fileparts(V.fname);
cwd = pwd;

for i = 1:length(vo)
    

    % * write output images for IRLS
    % ----------------------------------------------------
    
    if i < 10, myz = '000';, else, myz = '00';, end
    V.fname = fullfile(cwd,['rob_beta_' myz num2str(i) e]);
    V.descrip = 'IRLS robust regression betas, beta_0001 is intercept';
    
    if i == 1, newP = V.fname;
    else
        newP = str2mat(newP,V.fname);
    end
    
    disp(['Writing ' V.fname])
    spm_write_vol(V,vo{i});
    
    V.fname = fullfile(cwd,['rob_tmap_' myz num2str(i) e]);
    V.descrip = 'IRLS robust regression t-scores, tmap_0001 is intercept';
    disp(['Writing ' V.fname])
    spm_write_vol(V,vot{i});
    
    V.fname = fullfile(cwd,['rob_p_' myz num2str(i) e]);
    V.descrip = 'IRLS robust regression p values, rob_p_0001 is intercept';
    disp(['Writing ' V.fname])
    spm_write_vol(V,vop{i});

    % * write output images for OLS
    % ----------------------------------------------------
    
    if dools
        V.descrip = 'OLS regression betas from robfit.m, beta_0001 is intercept';
        V.fname = fullfile(cwd,['ols_beta_' myz num2str(i) e]);
    
        if i == 1, newP2 = V.fname;
        else
            newP2 = str2mat(newP,V.fname);
        end
    
        disp(['Writing ' V.fname])
        spm_write_vol(V,vo2{i});
    
        V.fname = fullfile(cwd,['ols_tmap_' myz num2str(i) e]);
        V.descrip = 'OLS regression t-scores from robfit.m, tmap_0001 is intercept';
        disp(['Writing ' V.fname])
        spm_write_vol(V,vot2{i});
    
        V.fname = fullfile(cwd,['ols_p_' myz num2str(i) e]);
        V.descrip = 'OLS regression p values from robfit.m, rob_p_0001 is intercept';
        disp(['Writing ' V.fname])
        spm_write_vol(V,vop2{i});
        
        % * write output images for comparison
        % ----------------------------------------------------
        V.descrip = 'IRLS-OLS difference z-scores from robfit.m, beta_0001 is intercept';
        V.fname = fullfile(cwd,['irls-ols_z_' myz num2str(i) e]);
    
        if i == 1, newP2 = V.fname;
        else
            newP2 = str2mat(newP,V.fname);
        end
    
        disp(['Writing ' V.fname])
        spm_write_vol(V,voz3{i});
    
        V.fname = fullfile(cwd,['irls-ols_p_' myz num2str(i) e]);
        V.descrip = 'IRLS-OLS 2-tailed p-values from robfit.m, tmap_0001 is intercept';
        disp(['Writing ' V.fname])
        spm_write_vol(V,vop3{i});
    
    end % do ols
        
end % contrasts (vo)



cd ..

return
function [clpos, clneg, dat, volInfo] = robust_results_threshold(pthr,kthr,varargin)
% [clpos, clneg, dat, volInfo] = robust_results_threshold(pthr,kthr,[pimg],[timg],[cmd strings])
%
% Threshold a p-value image and return values in a second image (designed
% for t-images, but can be anything.)
%
% Examples
% -------------------------------------------------------------------------
% Default: use rob_p_0001.img and t_0001.img
% [clpos, clneg, dat, volInfo] = robust_results_threshold(.005,10);
%
% Do not display orthviews, but write masks
% [clpos, clneg, dat, volInfo] = robust_results_threshold(.001,10,'nodisplay','write');
%
% Threshold correlation map (rob_p_0002.img) and mask with pos intercept activation 
% [clpos, clneg, dat, volInfo] = robust_results_threshold(.005,10,'cov1','mask','../mask_images/hr_corr_pos_fdr05.img');

% --------------------------------------
% * Set up arguments
% --------------------------------------

% defaults

pimg = 'rob_p_0001.img';
timg = 'rob_tmap_0001.img';
writeoutput = 0;
mask  = [];
display = 1;
clpos = []; clneg = [];
dofdr = 0;

% inputs
for i = 1:length(varargin)
    arg = varargin{i};
    if ischar(arg)
        switch lower(arg)
            case 'mask', mask = varargin{i+1};
            case 'p', pimg = varargin{i+1};
            case 't', timg = varargin{i+1};
            case 'intercept', pimg = 'rob_p_0001.img'; timg = 'rob_tmap_0001.img';
            case 'cov1', pimg = 'rob_p_0002.img'; timg = 'rob_tmap_0002.img';
            case 'cov2', pimg = 'rob_p_0003.img'; timg = 'rob_tmap_0003.img';
            case 'cov3', pimg = 'rob_p_0004.img'; timg = 'rob_tmap_0004.img';
            case 'write',writeoutput = 1;
            case 'nodisplay', display = 0;
            case 'fdr', dofdr = 1;
        end
    end
end

% --------------------------------------
% * Threshold p-values
% --------------------------------------
if dofdr
    [volInfo,dat] = iimg_read_img(pimg,1);
    pt = FDR(dat,pthr);       % get threshold for FDR
    if isempty(pt) || isinf(pt), fprintf(1,'No voxels pass FDR threshold.\n'); return, end
    fprintf(1,'FDR: threshold is p < %3.4f\n',pt);
    dat(dat>pt) = 0;
else
    [dat,volInfo] = iimg_threshold(pimg,'thr',[0 pthr],'k',kthr);
end

% --------------------------------------
% * apply mask, if specified
% --------------------------------------

if ~isempty(mask), dat = iimg_mask(dat,mask,volInfo); end

fprintf(1,'\nVoxels: %3.0f total: ',sum(dat>0));

% --------------------------------------
% * get t-values
% --------------------------------------

% get t-values, masked with significant p- voxels
dat = iimg_mask(dat,timg,volInfo);

fprintf(1,'+ %3.0f  ',sum(dat>0)); fprintf(1,'- %3.0f  ',sum(dat<0));

% --------------------------------------
% * write output images
% --------------------------------------

if writeoutput
    % write output images
    if dofdr, fdrstr = '_fdr'; else fdrstr = []; end
    pstr = num2str(pthr); wh = find(pstr == '.'); wh = wh(1); pstr = pstr(wh+1:end);
    toutname = [timg(1:end-4) '_thr_p' fdrstr pstr timg(end-3:end)];
    tposname = [timg(1:end-4) '_pos_mask_p' fdrstr pstr timg(end-3:end)];
    tnegname = [timg(1:end-4) '_neg_mask_p' fdrstr pstr timg(end-3:end)];
end

if writeoutput
    voldata = iimg_reconstruct_3dvol(dat,volInfo,'outname',toutname);
    iimg_reconstruct_3dvol(dat>0,volInfo,'outname',tposname);
    iimg_reconstruct_3dvol(dat<0,volInfo,'outname',tnegname);
else
    voldata = iimg_reconstruct_3dvol(dat,volInfo);
end
    
% --------------------------------------
% * make clusters
% --------------------------------------

% make clusters
posdat = voldata; posdat(posdat < 0) = 0;
clpos = mask2clusters(posdat,volInfo.mat);

negdat = voldata; negdat(negdat > 0) = 0;
clneg = mask2clusters(negdat,volInfo.mat);

% shouldn't need to do this, but...do we?
possum = 0; negsum = 0;
if ~isempty(clpos)
    sz = cat(1,clpos.numVox); clpos(sz < kthr) = [];
    sz = cat(1,clpos.numVox); possum = sum(sz);
end

if ~isempty(clneg)
    sz = cat(1,clneg.numVox); clneg(sz < kthr) = [];
    sz = cat(1,clneg.numVox); negsum = sum(sz);
end

fprintf(1,'Suprathreshold clusters: + %3.0f (%3.0f vox)   ',length(clpos),possum);
fprintf(1,'- %3.0f (%3.0f vox)\n',length(clneg),negsum);

% --------------------------------------
% * display
% --------------------------------------

if display && (~isempty(clpos) || ~isempty(clneg))
    cluster_orthviews([clpos clneg],'bivalent');
end

return
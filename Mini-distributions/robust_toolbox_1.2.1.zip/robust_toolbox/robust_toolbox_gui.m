function varargout = robust_toolbox_gui(Action, varargin)
    %
    %
    % Tor Wager
    %
    % Thanks to Tom Nichols for the excellent GUI shell!

    %-----------------------------functions-called------------------------
    %
    %-----------------------------functions-called------------------------

    % global variables we need for this shell

    global cl
    global EXPT

    %-Format arguments
    %-----------------------------------------------------------------------
    if nargin == 0, Action='Init'; end


    switch lower(Action)

        case lower('Init')
            %=======================================================================

            %clc
            %BrainVowager_defaults;
            robust_toolbox_gui('AsciiWelcome')
            robust_toolbox_gui('CreateMenuWin')

            % load EXPT

            if ~isempty(EXPT)
                disp('Using EXPT already in memory.');
            elseif exist('EXPT.mat')==2
                disp('loading EXPT.mat'); load EXPT;
            else
                disp('You need to go to the directory containing individual subject results dirs ');
                disp('this directory should have information about the experiment stored in the file EXPT.mat')
                disp('No EXPT file in current directory.');
                EXPT = [];
                fprintf(1, '\n')
            end

            varargout{1} = EXPT;

        case lower('AsciiWelcome')
            %=======================================================================
            disp( 'Welcome to robust_toolbox_gui: Robust Analyses.')
            fprintf('\n')

        case lower('Ver')
            %=======================================================================
            varargout = {'SCNlab Robust Menu'};



        case lower('CreateMenuWin')
            %=======================================================================
            close(findobj(get(0, 'Children'), 'Tag', 'robust_toolbox_gui Menu'))


            %-Initialize robust_toolbox_gui menu window
            %-----------------------------------------------------------------------
            [F, winwid, winh] = robust_toolbox_gui('initFigure');


            % default button sizes and positions, etc.

            topbutton = winh-100;        % y location of top button
            butspace = 35;               % y spacing of buttons

            fullbutxy = [160 30];       % full-length button width and height
            halfbutxy = [80 30];        % (left-hand) half-width button w and h
            rightbutxy = halfbutxy;
            rightbutx = 110+halfbutxy(1)+5;  % right-hand button start x





            %-Frames and text
            %-----------------------------------------------------------------------
            axes('Position', [0 0 80/winwid winh/winh], 'Visible', 'Off')
            text(0.5, 0.475, 'Robust Toolbox', ...
                'FontName', 'Times', 'FontSize', 36, ...
                'Rotation', 90, ...
                'VerticalAlignment', 'middle', 'HorizontalAlignment', 'center', ...
                'Color', [1 1 1]*.6);

            text(0.2, 0.96, 'SCN Lab', ...
                'FontName', 'Times', 'FontSize', 16, 'FontAngle', 'Italic', ...
                'FontWeight', 'Bold', ...
                'Color', [1 1 1]*.6);

            uicontrol(F, 'Style', 'Frame', 'Position', [095 005 winwid-100 winh - 30], ...
                'BackgroundColor', robust_toolbox_gui('Color'));  % colored frame
            uicontrol(F, 'Style', 'Frame', 'Position', [105 015 winwid-120 winh - 50]);  % inner gray frame

            %-Buttons to launch robust_toolbox_gui functions
            %-----------------------------------------------------------------------

            % -------------------------------------------
            % Section - Random Effects Analysis
            uicontrol(F, 'Style', 'Text', ...
                'String', 'Random Effects', 'FontSize', 14, ...
                'HorizontalAlignment', 'Center', ...
                'Position', [115 topbutton+30 fullbutxy], ...
                'ForegroundColor', 'y', 'FontWeight', 'b');
            % -------------------------------------------

            % Robust setup
            str = 'CreateExpt(''robfit'');';                            % callback function
            str = robust_toolbox_gui('ExpandString', str);               % display then execute
            uicontrol(F, 'String', 'Setup', ...
                'Position', [110 topbutton-(1-1)*butspace fullbutxy], ...
                'CallBack', str, ...
                'Interruptible', 'on', ...
                'ForegroundColor', 'k', 'FontWeight', 'b');

            % Robust RFX Analysis
            str = 'EXPT = robfit(EXPT, [], 0, EXPT.mask);';            % callback function
            str = robust_toolbox_gui('ExpandString', str);               % display then execute
            uicontrol(F, 'String', 'Robust RFX', ...
                'Position', [110 topbutton-(2-1)*butspace fullbutxy], ...
                'CallBack', str, ...
                'Interruptible', 'on', ...
                'ForegroundColor', 'k', 'FontWeight', 'b');

            % Robust Results
            str = 'robust_results3(EXPT, .005, 10);' ;
            str = robust_toolbox_gui('ExpandString', str);
            uicontrol(F, 'String', 'Robust Results', ...
                'Position', [110 topbutton-(3-1)*butspace fullbutxy], ...
                'CallBack', str, ...
                'Interruptible', 'on', ...
                'ForegroundColor', 'k', 'FontWeight', 'b');

            % -------------------------------------------
            % Next section - Robust Seed Analysis
            uicontrol(F, 'Style', 'Text', ...
                'String', 'Robust Seed Analysis', 'FontSize', 14, ...
                'HorizontalAlignment', 'Center', ...
                'Position', [115 topbutton-(4.2-1)*butspace fullbutxy], ...
                'ForegroundColor', 'y', 'FontWeight', 'b');
            % -------------------------------------------


            % Select Seeds - opens up scn_roi_gui to: 1) set ROIs, 2) extract data,
            % 3) save seeds
            str1 = 'disp(''You need to get clusters of interest and extract data from them to use as seeds.''); ';
            str = [str1 'scn_roi_gui;'];                                         % callback function
            str = robust_toolbox_gui('ExpandString', str);                 % display then execute
            uicontrol(F, 'String', 'Cluster Menu (Setup)', ...
                'Position', [110 topbutton-(5-1)*butspace fullbutxy], ...
                'CallBack', str, ...
                'Interruptible', 'on', ...
                'ForegroundColor', 'k', 'FontWeight', 'b');

            % Robust Seed
            %str1 = 'disp(EXPT.SNPM.connames), whc = input(''Which contrasts? (e.g., [1:5]) : ''); ';
            str1 = 'doglobal = input(''Use global contrast covariate? (1/0) ''); ';
            str = [str1 'EXPT = robseed(EXPT, cl, 1:length(EXPT.SNPM.P), 0, EXPT.mask, doglobal);'];
            str = robust_toolbox_gui('ExpandString', str);                 % display then execute
            uicontrol(F, 'String', 'Robust Seed Analysis', ...
                'Position', [110 topbutton-(6-1)*butspace fullbutxy], ...
                'CallBack', str, ...
                'Interruptible', 'on', ...
                'ForegroundColor', 'k', 'FontWeight', 'b');

            % Robust Seed Results - replace robust_results 2 for robseed_results
            % (on server)
            str = 'robust_results2(EXPT, .005, 10);' ;
            str = robust_toolbox_gui('ExpandString', str);
            uicontrol(F, 'String', 'Robust Seed Results', ...
                'Position', [110 topbutton-(7-1)*butspace fullbutxy], ...
                'CallBack', str, ...
                'Interruptible', 'on', ...
                'ForegroundColor', 'k', 'FontWeight', 'b');


            % -------------------------------------------
            % Next section - display
            uicontrol(F, 'Style', 'Text', ...
                'String', 'Display results map', 'FontSize', 14, ...
                'HorizontalAlignment', 'Center', ...
                'Position', [115 topbutton-(8-1)*butspace fullbutxy], ...
                'ForegroundColor', 'y', 'FontWeight', 'b');
            % -------------------------------------------

            buttontext = {'Display Menu' ...
                'Threshold/Display' ...
                'Activation + correlation' ...
                'Cluster tools menu' ...
                'Intercept' ...
                'Cov 1' ...
                'Cov 2' ...
                'Cov 3' ...
                };
            str = 'robust_toolbox_gui(''results'');';                          % callback function
            pop1 = uicontrol(F, 'Style', 'popupmenu', 'Tag', 'ResultsPop', ...
                'String', buttontext, ...
                'Position', [110 topbutton-(9-1)*butspace+15 fullbutxy], ...
                'CallBack', str, ...
                'Interruptible', 'on', ...
                'ForegroundColor', 'k', 'FontWeight', 'b');




            set(F, 'Pointer', 'Arrow', 'Visible', 'on')




        case lower('Color')
            %=======================================================================
            % robust_toolbox_gui('Color')
            %-----------------------------------------------------------------------
            % %-Developmental livery
            % varargout = {[0.7, 1.0, 0.7], 'Lime Green'};
            %-Distribution livery
            varargout = {[.8 0.7 1.0], 'Purple'};


        case lower('ExpandString')
            %=======================================================================
            % robust_toolbox_gui('ExpandString')
            % Expand an action button callback string (a command string to be
            % evaluated)
            % so that it first displays the command, and then executes it
            %-----------------------------------------------------------------------
            str = varargin{1}; str2 = [];
            for i = 1:length(str)
                if str(i) == ''''
                    str2(end+1) = '''';
                    str2(end+1) = '''';
                else
                    str2(end+1) = str(i);
                end
            end

            str = ['disp(''' char(str2) '''), ' str ];     % display then execute

            varargout = {str};


        case lower('initFigure')
            %=======================================================================
            % [F, winwid, winh] = robust_toolbox_gui('initFigure')
            %-----------------------------------------------------------------------
            % Get the position of the main BrainVowager menu, or if
            % not available, default screen pos.

            % default sizes, etc.
            S = get(0, 'ScreenSize');

            winwid = 300;               % window width
            winh = 400;                 % window height
            pos = [S(3)/2+150, S(4)/2-140, winwid, winh];  % default

            % look for figures to place this one next to, in this order (last is preferred):
            h = [];
            h = findobj('Tag', 'BrainVowager_gui Menu');
            h = findobj('Tag', 'scn_fir_results_gui Menu');

            if ~isempty(h),
                pos = get(h, 'Position');
                winwid = pos(3);
                winh = pos(4);
                pos(1) = pos(1) + winwid;   % put next to main figure
            end

            %-Open robust_toolbox_gui menu window
            %----------------------------------------------------------------------

            F = figure('Color', [1 1 1]*.8, ...
                'Name', robust_toolbox_gui('Ver'), ...
                'NumberTitle', 'off', ...
                'Position', pos, ...
                'Resize', 'off', ...
                'Tag', 'robust_toolbox_gui Menu', ...
                'Pointer', 'Watch', ...
                'MenuBar', 'none', ...
                'Visible', 'off');

            varargout{1} = F; varargout{2} = winwid; varargout{3} = winh;


        case lower('results')
            %=======================================================================
            % robust_toolbox_gui('results')
            %----------------------------------------------------------------------

            if isempty(EXPT), warning('EXPT is empty.  not created, or not declared global in base workspace?'); end

            % get overlay image, if we have the ROI gui open
            han = findobj('Tag', 'scn_roi_gui Menu');
            if ~isempty(han)
                scn_roi_gui('overlay');
                P = guidata(han);
            else
                P = []; % default overlay
            end

            % callbacks
            % buttontext = {'Display Menu' 'Threshold/Display' 'Thresh/Disp with Scatterplots' 'Intercept' 'cov1' 'Cluster tools menu'};
            pop1 = findobj('Tag', 'ResultsPop');
            indx = get(pop1, 'Value');

            % callback functions

            callbk = {@noop_callback ...
                @robust_results_threshold_callback ...
                @active_plus_corr_scatterplot_plugin ...
                @scn_roi_gui ...
                @intercept_callback ...
                @cov1_callback ...
                @cov2_callback ...
                @cov3_callback ...
                };
            feval(callbk{indx});
            
        otherwise
            error('Unknown action string')
    end
end

%--------------------
% Callback functions
%--------------------
function noop_callback()
end

function robust_results_threshold_callback()
    robust_results_threshold_wrapper();
end

function intercept_callback()
    robust_results_threshold_wrapper('intercept');
end

function cov1_callback()
    robust_results_threshold_wrapper('cov1');
end

function cov2_callback()
    robust_results_threshold_wrapper('cov2');
end

function cov3_callback()
    robust_results_threshold_wrapper('cov3');
end

function robust_results_threshold_wrapper(cov_or_int_string)
    pthr = spm_input('Enter p-value threshold (uncorrected). Type "Inf" (without quotes) for FDR: ', 1);
    kthr = spm_input('Enter extent threshold (min cluster size) in voxels: ');
    display_string = spm_input('Display results? ', [], 'y/n', {''; 'nodisplay'}, 1);
    display_string = display_string{1};
    
    cov_or_int_string
    if(~exist('cov_or_int_string', 'var') || isempty(cov_or_int_string))
        pimg = spm_get(1, 'rob_p*img', 'Select a p-image file to get clusters from', pwd);
        robust_results_threshold(pthr, kthr, 'p', pimg, display_string);
    else
        robust_results_threshold(pthr, kthr, display_string, cov_or_int_string);
    end
end
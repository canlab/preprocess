% function robust_results3(EXPT, u, k, ['contrastname', contrastname], ['covnames', covariatenames], ['resultnames', resultnames], ['pause for display', 0|1])
%
% Displays the results of a random effects analysis contained in a robust* directory. By default, saves .png
% files in axial and medial views.
%
% u: uncorrected threshold (e.g., .001) or 'FDR' % currently ignored! real thresholds set in multi_threshold!
% k: extent threshold (minimum size of cluster)
%
% FDR IS NOW VALID ONLY FOR INCREASES
%
% E.g.:
% % After loading an EXPT object...
% robdirs = filenames('robust00[0-9][0-9]');
% for i=1:length(robdirs)
%     cd(robdirs{i});
%     robust_results3(EXPT, .005, 10);
%     close all;
%     cd('..');
% end
%
% To pause after each one, run:
% for i=1:length(robdirs)
%     cd(robdirs{i});
%     robust_results3(EXPT, .005, 10);
%     keyboard;
%     close all;
%     cd('..');
% end

function robust_results3(EXPT, u, k, varargin)
    [tmp currentdir] = fileparts(pwd()); %#ok - this is a signal to mlint to ignore the fact that tmp is never used

    result_names = {'Intercept' 'Cov 1' 'Cov 2' 'Cov 3' 'Cov 4' 'Cov 5' 'Cov 6' 'Cov 7' 'Cov 8' 'Cov 9' 'Cov 10' 'Cov 11' 'Cov 12'};
    pause_for_display = 0;
    thresholds = [];

    for i=1:length(varargin)
        if(ischar(varargin{i}))
            switch(varargin{i})
                case 'contrastname'
                    result_names{1} = varargin{i+1};
                case 'covnames'
                    result_names = {'Intercept' varargin{i+1}{:}};
                case 'resultnames'
                    result_names = varargin{i+1};
                case 'display thresholds'
                    thresholds = varargin{i+1};
                case {'pausefordisplay' 'pause for display'}
                    pause_for_display = varargin{i+1};
            end
        end
    end

    warning off

    % convert u to t-threshold
    df = length(EXPT.subjects) - length(dir('rob_p_0*.img'));
    fprintf(1, '\n\n\nrobust_results3 thinks there are %d degrees of freedom.\n', df);

    uorig = u;

    % if uncorrected threshold
    if ~ischar(u)
        t = tinv(1-u, df);
        fprintf(1, 'Height thresh: t = %3.2f (%3.0f Ss, %3.0f df @ p < %3.4f, extent = %3.0f\n', t, length(EXPT.subjects), df, uorig, k);
    else
        uorig = 0.05;
    end

    ovl = [];
    if isfield(EXPT, 'overlay');
        disp(['Using overlay image: ' EXPT.overlay]);
        ovl = EXPT.overlay;
    end

    save_cl_results();
    display_activations();
    

    warning on

    
    
    %------------------%
    % Nested functions %
    %------------------%
    
    function save_cl_results()
        for i=1:length(result_names)
            tmap_file = sprintf('rob_tmap_%04d.img', i);
            if exist(tmap_file, 'file')
                switch i
                    case 1 % intercept results
                        headers = {'Overall pos activation' 'Overall neg activation'};
                        mat_files = {[currentdir '_intercept_pos'] [currentdir '_intercept_neg']};
                    otherwise
                        headers = {sprintf('%s pos effect', result_names{i}) sprintf('%s neg effect', result_names{i})};
                        mat_files = {sprintf('%s_%04d_pos', currentdir, i) sprintf('%s_%04d_neg', currentdir, i)};
                end

                fprintf(1, '\n---------------------------------------------\n%s\n---------------------------------------------\n', headers{1});
                %FDR threshold
                if ischar(u) && strcmp(u, 'FDR')
                    t = spm_uc_FDR(.05, [1 df], 'T', 1, spm_vol(tmap_file), 0);
                    fprintf(1, 'Height thresh FDR-corr: t = %3.2f (%3.0f Ss, %3.0f df @ p < %3.4f, extent = %3.0f\n', t, length(EXPT.subjects), df, uorig, k);
                end

                pos_thresh_imgs = threshold_imgs(tmap_file, t, k, 'pos');
                cl = mask2clusters(pos_thresh_imgs); %#ok
                save(mat_files{1}, 'cl');

                fprintf(1, '\n---------------------------------------------\n%s\n---------------------------------------------\n', headers{2})
                neg_thresh_imgs = threshold_imgs(tmap_file, t, k, 'neg');
                cl = mask2clusters(neg_thresh_imgs); %#ok
                save(mat_files{2}, 'cl');
            end
        end
    end

    function display_activations()
        for i=1:length(result_names)
            tmap_file = sprintf('rob_tmap_%04d.img', i);
            if exist(tmap_file, 'file')
                fprintf(1, '\n---------------------------------------------\nDisplaying %s\n---------------------------------------------\n', result_names{i});
                if(~isempty(thresholds))
                    cl = multi_threshold2(tmap_file, 'T', df, 'overlay', ovl, 'title', sprintf('%s - %s', currentdir, result_names{i}), 'save images', 1, 'thresholds', thresholds); %#ok
                else
                    cl = multi_threshold2(tmap_file, 'T', df, 'overlay', ovl, 'title', sprintf('%s - %s', currentdir, result_names{i}), 'save images', 1); %#ok
                end
                if(pause_for_display)
                    input('Press return/enter to continue');
                end
            end
        end
    end
end



function model = modelSaturation(model,varargin)
% function model = modelSaturation(model,[threshold])
%
% replaces all values above some threshold with a specified value
% to model saturation effects
% default = 4 (4 x max HRF)
%
% 3/30/01 Tor Wager
%

if nargin > 1, thresh = varargin{1};,else thresh = 4;,end

model(model(:,:) > thresh) = thresh;

return
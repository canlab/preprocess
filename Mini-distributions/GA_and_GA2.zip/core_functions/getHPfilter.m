function R = getHPfilter(freq,numsamps)

% freq is number of frequencies to cut off.
base = 1:2*pi/numsamps:2*pi

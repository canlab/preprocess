function a=m2bin(m)

%   a=m2bin(m)
%   converts from mseq in terms of -1 and 1 to 0 and 1s

a=(m+1)/2;



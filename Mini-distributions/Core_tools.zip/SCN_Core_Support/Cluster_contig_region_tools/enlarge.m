function cl = enlarge(cl)
% function cl = enlarge(cl)
% 
% enlarge cluster

X = cl.XYZ; Xout = X;

for i = 1:3
    Xtmp = X; 
    Xtmp(i,:) = Xtmp(i,:) + 1; Xout = [Xout Xtmp];         % add to dim
    Xtmp(i,:) = Xtmp(i,:) - 2; Xout = [Xout Xtmp];      % subtract 1 from dim
end

Xout = unique(round(Xout)','rows')';
cl.XYZ = Xout;
cl.XYZmm = voxel2mm(Xout,cl.M);
cl.Z = ones(1,size(cl.XYZ,2));

cl.numVox = size(cl.XYZmm,2);
return

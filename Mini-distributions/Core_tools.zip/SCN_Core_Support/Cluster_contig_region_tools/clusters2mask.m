function [m,V,cl] = clusters2mask(cl,V,varargin)
% [m,V,cl] = clusters2mask(cl,V,[opt: write Z-scores])
% tor wager
%
% This function has 2 modes!  If V is a structure:
%
% converts clusters structure to a mask image, given V structure with V.mat
% field.  V.mat is an SPM mat file. V.dim is dims of image
% m is mask img data, V is mask vol info
% Also replaces cl.XYZ (voxels)
%
% If V is a vector of mask dimensions:
%
% converts clusters to mask image using existing XYZ and dims of mask
%
% see also voxels2mask, for a faster function that uses XYZ voxel coords

doZ = 0;
if length(varargin) > 0, doZ = varargin{1};,end

if isstruct(V)
    %%% MM way
    
m = zeros(V.dim(1:3));

for i = 1:length(cl)
    
    cl(i).XYZ = mm2voxel(cl(i).XYZmm,struct('M',V.mat),1)';
    
    % eliminate out of range
    
    
    ind = sub2ind(V.dim(1:3),cl(i).XYZ(1,:)',cl(i).XYZ(2,:)',cl(i).XYZ(3,:)');
    
    if doZ, m(ind) = cl(i).Z;,else, m(ind) = 1;, end
        
end

V.fname = 'clustermask.img';
spm_write_vol(V,double(m));
disp('Written clustermask.img')


else
    %%% VOXEL way
    for i = 1:length(cl)
        mask(:,:,:,i) = voxel2mask(cl(i).XYZ',V);
    end
    m = sum(mask,4);
    m = double(m > 0);
end
    
return

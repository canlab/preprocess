function [dat, xyz, masked_vol] = iimg_mask(maskindx,dat,V)
% [masked_indx, xyz, masked_vol] = iimg_mask(maskindx,dat,V)
%
% fastest way to mask an image:
% [masked_indx, masked_vol] = iimg_mask(maskindx,dat)
%
% slower: also get xyz list of voxel coordinates in-mask
% where mask defined by V.wh_inmask
%
% even slower: reconstruct a 3-D volume and return in masked_vol

[Vtmp,maskindx] = iimg_read_img(maskindx);
[Vtmp,dat] = iimg_read_img(dat);

if any(size(maskindx) - size(dat)),
    error('Mask and image data do not match.');
end

dat = dat .* (abs(maskindx) > 0);

if nargout > 1
    wh = find(dat);
    xyz = V.xyzlist(wh,:);
end

if nargout > 2
    % slower, reconstruct mask
    if nargin < 3, error('You must enter volume structure V to reconstruct 3-D vol');, end
    masked_vol = iimg_reconstruct_3dvol(dat,V);
end

return

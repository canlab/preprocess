function [dat,V] = iimg_make_sure_indx(inputarg,extended_output_flag)
% [dat,V] = iimg_make_sure_indx(inputarg,[extended_output_flag])
%
% Make sure input is an index list, and convert if not
%
% Dependent function: use iimg_read_img

if nargin < 2, extended_output_flag = 0;, end

[m,n] = size(inputarg);

if isstr(inputarg)
    % it's a file name
    [V,dat] = iimg_read_img(inputarg,extended_output_flag);

elseif n > 1
    % it's a matrix
    dat = inputarg(:);
    
else
    % it's an index vector
    % do nothing
    dat = inputarg;
end

return

    



function indx = iimg_xyz2spheres(xyz,xyzlist,r)
% indx = iimg_xyz2spheres(xyz,xyzlist,r)

n = size(xyzlist,1);

whorig = (1:n)';        % original voxel index


% eliminate xyz points that are not even close (outside box)
cmax = max(xyz);
cmin = min(xyz);
d = [xyzlist - repmat(cmax,n,1)    repmat(cmin,n,1) - v];   
wh = any(d > r,2);

xyzlist(wh,:) = [];
whorig(wh) = [];

r2 = r.^2;
indx = zeros(n,1);

% for each voxel, find xyzlist coords within r
% add ones to indx
for i = 1:size(xyz,1)
    
    myx = xyz(i,:);
    
    % find list xyz in box around coord
    wh = abs(xyzlist(:,1) - myx(1)) > r;
    xyzlist(wh,:) = []; whorig(wh) = [];

    wh = abs(xyzlist(:,2) - myx(2)) > r;
    xyzlist(wh,:) = []; whorig(wh) = [];
    
    wh = abs(xyzlist(:,3) - myx(3)) > r;
    xyzlist(wh,:) = []; whorig(wh) = [];
    
    n = size(xyzlist,1);
    d = sum(   ( repmat(myx,n,1) - xyzlist ).^2 ,2   );
    
    wh = whorig( d <= r2 );

    indx(wh) = 1;
    
end




return



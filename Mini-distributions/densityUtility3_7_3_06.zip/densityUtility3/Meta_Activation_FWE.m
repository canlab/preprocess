function Meta_Activation_FWE(meth,varargin)
%Meta_Activation_FWE(meth)
%
% Meta_Activation_FWE('all',DB,iterations)   [default]
% > Run all of the commands below in sequence
%
% Meta_Activation_FWE('setup',DB)
% > Create activation map .img and MC_Setup structure; save MC_Info
%
% Meta_Activation_FWE('mc',iterations)
% > Create or add null hypothesis iterations to MC_Info
%
% Meta_Activation_FWE('results')
% > Get and plot results
% Examples:
% For contrasts, positive con values
% Meta_Activation_FWE('results',1,'poscon') 
% Negative con values
% Meta_Activation_FWE('results',1,'negcon') 

switch meth
    
%%
    case 'setup'
        % ------------------------------------------------
        % Setup and write activation probability map
        % ------------------------------------------------
        tic
        DB = varargin{1};
        
        docons = input('Compute contrasts across conditions also? (1/0)','s');
        if docons
            [X,connames,DB,Xi,Xinms,condf,testfield,contrasts] = Meta_Logistic_Design(DB);
            [MC_Setup,activation_proportions] = meta_prob_activation(DB,Xi,contrasts,connames,Xinms);
        else
            [MC_Setup,activation_proportions] = meta_prob_activation(DB);
            disp('Activation map written: Activation_proportion.img');
        end
        
        % THE CODE BELOW IS REQUIRED FOR BLOB-SHUFFLING ONLY
        % ------------------------------------------------
        % set up blobs for all studies
        % ------------------------------------------------
        str1 = sprintf('Getting blobs for all studies'); fprintf(1,str1);
        s = size(MC_Setup.unweighted_study_data,2);     
        MC_Setup.cl = cell(1,s);
        for i = 1:s
            MC_Setup.cl{i} = iimg_indx2contiguousxyz(MC_Setup.unweighted_study_data(:,i),MC_Setup.volInfo,1);
        end
        erase_string(str1);

        % ------------------------------------------------
        % Save setup info
        % ------------------------------------------------
        if exist('MC_Info.mat','file')
            save MC_Info -append MC_Setup activation_proportions
            disp('Appended info to existing MC_Info.');
        else
            save MC_Info MC_Setup activation_proportions
            disp('Created new MC_Info.');
        end

        toc

        
        
        
%%
    case 'mc'
        % ------------------------------------------------
        % Monte Carlo iterations (create or add to existing)
        % ------------------------------------------------
        tic
        iter = varargin{1};     % iterations to create or add

        [MC_Setup, maxprop, uncor_prop, maxcsize, startat] = setup_mc_vars(iter);

        last = length(maxprop.act);

        fprintf(1,'Iteration ');

        for i = startat:last

            fprintf(1,'%03d ',i);

            %[maxprop(i),uncor_prop(i,:),maxcsize(i,:)] = meta_stochastic_activation(MC_Setup);

            [mp,up,cs] = meta_stochastic_activation_blobs(MC_Setup);
            
            maxprop.act(i) = mp.act; uncor_prop.act(i,:) = up.act; maxcsize.act(i,:) = cs.act;
            if isfield(mp,'poscon')
                maxprop.poscon(i) = mp.poscon; uncor_prop.poscon(i,:) = up.poscon; maxcsize.poscon(i,:) = cs.poscon;
                maxprop.negcon(i) = mp.negcon; uncor_prop.negcon(i,:) = up.negcon; maxcsize.negcon(i,:) = cs.negcon;
            end
            
            if mod(i,10) == 0 || i == last
                str1 = sprintf('Saving results in MC_Info'); fprintf(1,str1);
                save MC_Info -append maxprop uncor_prop maxcsize
                erase_string(str1);
            end

            fprintf(1,'\b\b\b\b');

        end

        fprintf(1,'Done!\n');
        toc

        
        
%% 
    case 'results'
        % ------------------------------------------------
        % Get results, threshold, and display
        % ------------------------------------------------

        if length(varargin) > 1, doplots = varargin{2}; else doplots = 1; end
        if length(varargin) > 2, maptype = varargin{3}; else maptype = 'act'; end


        % load Setup and prepare thresholds and data vectorized image 
        [MC_Setup, statmap, imgprefix, maxprop, uncor_prop, maxcsize] = setup_results_vars(maptype);

        % get and plot thresholds
        [maxthr,uncor_thr,maxcthr] = get_thresholds(maxprop, uncor_prop, maxcsize,'act',doplots);

        % plot proportions or contrast in statmap
        if doplots, subplot(1,3,3); plot_act_prop(statmap,maxthr,uncor_thr); end




        % Height threshold -- whole brain FWE corrected
        i1 = statmap > maxthr;  wh = find(i1);
        fprintf(1,'p < .05 Corrected: %3.0f voxels\n',length(wh));

        % Write results image
        indic2mask(i1,statmap,MC_Setup,[imgprefix '_FWE_height.img']);

        % get clusters to save; old plotting functions
        %cl = mask2clusters([imgprefix '_FWE_height.img']);
        %if doplots, cluster_orthviews(cl); end

        % Extent threshold --  corrected based on cluster size
        e1 = meta_cluster_extent_threshold(MC_Setup.volInfo.xyzlist',statmap,uncor_thr(1),maxcthr(1));
        e2 = meta_cluster_extent_threshold(MC_Setup.volInfo.xyzlist',statmap,uncor_thr(2),maxcthr(2));
        e3 = meta_cluster_extent_threshold(MC_Setup.volInfo.xyzlist',statmap,uncor_thr(3),maxcthr(3));

        e = e1 | e2 | e3;
        % Write results image
        indic2mask(e,statmap,MC_Setup,[imgprefix '_FWE_extent.img']);

        % any of the above
        indic = i1 | e;

        % Write results image
        indic2mask(indic,statmap,MC_Setup,[imgprefix '_FWE_all.img']);

        % plot if asked for
        %cl = mask2clusters('Activation_FWE_all.img');
        if doplots, 
            
            % multi-threshold view
            [cl,dat] = iimg_multi_threshold(statmap, ...
            'thresh',[maxthr sort(uncor_thr,'descend')], ...
            'size',[1 sort(maxcthr)], ...
            'volInfo',MC_Setup.volInfo);
        
            %cluster_orthviews(cl); 
        end

        
        
        
%%
    otherwise
        error('Unknown method.');
end


return










%%
% ====================================================================
% --------------------------------------------------------------------
%
% Monte Carlo subfunctions
%
% --------------------------------------------------------------------
% ====================================================================

function [MC_Setup, maxprop, uncor_prop, maxcsize,startat] = setup_mc_vars(iter)

% These should be loaded in file
MC_Setup = []; maxprop = [];  uncor_prop = []; maxcsize = [];

if ~(exist('MC_Info.mat','file'))
    error('You must have an MC_Info file in the current dir that contains MC_Setup.');
else
    load MC_Info
end

if isempty(maxprop)
    % no existing results; initialize
    str1 = sprintf('No MC iterations found yet.  Creating maxprop, uncor_prop, maxcsize\n');fprintf(1,str1);

    maxprop.act = zeros(iter,1);
    uncor_prop.act = zeros(iter,3);
    maxcsize.act = zeros(iter,3);
    
    if isfield(MC_Setup,'ctxtxi')  % do by-conditions also
        maxprop.poscon = zeros(iter,1);
        uncor_prop.poscon = zeros(iter,3);
        maxcsize.poscon = zeros(iter,3);

        maxprop.negcon = zeros(iter,1);
        uncor_prop.negcon = zeros(iter,3);
        maxcsize.negcon = zeros(iter,3);
    end
    
else
    % existing iterations; append
    str1 = sprintf('MC iterations found: %3.0f.  Appending new: %3.0f iterations\n',length(maxprop.act),iter);fprintf(1,str1);

    maxprop.act = [maxprop.act; zeros(iter,1)];
    uncor_prop.act = [uncor_prop.act; zeros(iter,3)];
    maxcsize.act = [maxcsize.act; zeros(iter,3)];
    
    if isfield(MC_Setup,'ctxtxi')  % do by-conditions also
        maxprop.poscon = [maxprop.poscon; zeros(iter,1)];
        uncor_prop.poscon = [uncor_prop.poscon; zeros(iter,3)];
        maxcsize.poscon = [maxcsize.poscon; zeros(iter,3)];

        maxprop.negcon = [maxprop.negcon; zeros(iter,1)];
        uncor_prop.negcon = [uncor_prop.negcon; zeros(iter,3)];
        maxcsize.negcon = [maxcsize.negcon; zeros(iter,3)];
    end
end

startat = find(maxprop.act == 0); startat = startat(1);

return




%%
% ====================================================================
% --------------------------------------------------------------------
%
% Results subfunctions
%
% --------------------------------------------------------------------
% ====================================================================



% --------------------------------------------------------------------
% Load some key variables for getting results
% --------------------------------------------------------------------
function [MC_Setup, statmap, imgprefix, maxprop, uncor_prop, maxcsize] = setup_results_vars(maptype)

% should be loaded in file
MC_Setup = []; maxprop = [];  uncor_prop = []; maxcsize = [];

% load file
% ------------
if ~exist('MC_Info.mat','file')
    error('You must have an MC_Info file in the current dir that contains MC_Setup.');
else
    load MC_Info
end

% check mc iterations
% ------------
if isempty(maxprop)
    % no existing results; error
    str1 = sprintf('No MC iterations found in MC_Info. You must create using Meta_Activation_FWE(''mc'',iter)\n');fprintf(1,str1);
end

if any(maxprop.act == 0)
    wh = find(maxprop.act == 0);
    fprintf(1,'Warning! %3.0f Empty iteration results: Removing from all iteration variables.',length(wh));
    maxprop.act(wh) = [];
    uncor_prop.act(wh,:) = [];
    maxcsize.act(wh,:) = [];
    
    if isfield(MC_Setup,'ctxtxi')  % do by-conditions also
        maxprop.poscon(wh) = [];
        uncor_prop.poscon(wh,:) = [];
        maxcsize.poscon(wh,:) = [];

        maxprop.negcon(wh) = [];
        uncor_prop.negcon(wh,:) = [];
        maxcsize.negcon(wh,:) = [];
    end
end

% Set up statistic image data to be thresholded
% ------------

switch maptype
    case 'act'
        % overall activation
        % use existing props, or set up empty to read from file
        if ~(exist('activation_proportions') == 1), activation_proportions = []; end
        % get activation proportions indicator or just check it
        statmap = setup_activation_proportions(activation_proportions,MC_Setup);

        imgprefix = 'Activation';
        
    otherwise
        % contrast across conditions
        statmap = MC_Setup.con_data;
        numcons = size(statmap,2);
        if numcons > 1
            connum = input(['Enter contrast number (1 thru ' num2str(numcons) ': ']);
            statmap = statmap(:,connum);
        end
        
        % check for correct field names
        switch maptype
            case 'poscon'
                imgprefix = [MC_Setup.connames(connum) '_Pos'];
            case 'negcon'
                % flip sign so thresholding will work the same way
                statmap = -statmap;
                
                imgprefix = [MC_Setup.connames(connum) '_Neg'];
                
            otherwise error('map type (3rd arg.) must be ''act'', ''poscon'', or ''negcon''');
        end


end
return


% --------------------------------------------------------------------
% Check that we have activations loaded, or load them from image
% --------------------------------------------------------------------

function activation_proportions = setup_activation_proportions(activation_proportions,MC_Setup)
% check/load true meta activations
% ------------
if isempty(activation_proportions)
    name = 'Activation_proportion.img';
    str1 = sprintf('Loading %s', name);fprintf(1,str1);
    if ~exist(name,'file')
        error('You must have an Activation_proportion.img file in the current dir, or run ''all'' option to create.');
    end

    mask = MC_Setup.volInfo.fname;
    if ~exist(mask,'file')
        error(['Cannot find mask image: ' mask]);
    end
    activation_proportions = meta_read_image(name,mask);
    erase_string(str1);
end

% check length
len = size(MC_Setup.volInfo.xyzlist,1);
if len ~= length(activation_proportions),
    error('activation image and results have different numbers of in-analysis voxels.  Has the mask image changed??');
end



return




% --------------------------------------------------------------------
% Get significance thresholds and plot histograms
% --------------------------------------------------------------------

function [maxthr,uncor_thr,maxcthr] = get_thresholds(maxprop, uncor_prop, maxcsize,fldname, doplots)

% flip signs of thresholds for negative contrast so code will work
% generically
if strcmp(fldname,'negcon')
    maxprop.(fldname) = -maxprop.(fldname);
    uncor_prop.(fldname) = -uncor_prop.(fldname);
end

maxthr = prctile(maxprop.(fldname),95);
uncor_thr = mean(uncor_prop.(fldname));
maxcthr = prctile(maxcsize.(fldname),95);

if doplots
    tor_fig(1,3);


    [h,x] = prepare_histogram(maxprop.(fldname));

    plot(x,h,'k','LineWidth',2);
    title('Null hypothesis activation proportion');
    yl = get(gca,'YLim');
    plot([maxthr maxthr],yl,'Color',[.5 .5 .5],'LineWidth',2);
    sym = {'--' '.-' ':'};

    for i = 1:3
        plot([uncor_thr(i) uncor_thr(i)],yl,sym{i},'Color',[.5 .5 .5],'LineWidth',2);
    end
    legend({'Max whole-brain density' 'p < .05 corrected' 'p < .05' 'p < .01' 'p < .001'});
    drawnow

    subplot(1,3,2);
    [h,x] = prepare_histogram(maxcsize.(fldname));

    plot(x,h,'LineWidth',2);
    colors = {'b' 'g' 'r'};
    yl = get(gca,'YLim');
    title('Null hypothesis cluster sizes');

    for i = 1:3
        plot([maxcthr(i) maxcthr(i)],yl,sym{i},'Color',colors{i},'LineWidth',2);
    end
    legend({'p < .05' 'p < .01' 'p < .001'});
    drawnow

end

return

% --------------------------------------------------------------------
% Plot activation proportions with thresholds
% --------------------------------------------------------------------
function plot_act_prop(activation_proportions,maxthr,uncor_thr)

[h,x] = prepare_histogram(activation_proportions);

plot(x,h,'k','LineWidth',2);
title('Observed activation proportions');
yl = get(gca,'YLim');
plot([maxthr maxthr],yl,'Color',[.5 .5 .5],'LineWidth',2);
sym = {'--' '.-' ':'};

for i = 1:3
    plot([uncor_thr(i) uncor_thr(i)],yl,sym{i},'Color',[.5 .5 .5],'LineWidth',2);
end
legend({'Observed proportions' 'p < .05 corrected' 'p < .05' 'p < .01' 'p < .001'});
drawnow

return



% --------------------------------------------------------------------
% Get significant regions based on extent 
% --------------------------------------------------------------------

function  indic = meta_cluster_extent_threshold(xyzlist,data,thr1,sizethr)

norig = size(xyzlist,2);

meet_primary = data > thr1;
wh1 = find(meet_primary);        % voxels that do meet primary


% consider only vox that meet primary
wh = find(~meet_primary);        % voxels that do not meet primary threshold
xyzlist(:,wh) = [];
clear wh

% check size OK
n = size(xyzlist,2);

if n > 50000
    disp('Too many voxels to cluster. Skipping.');
    return
end

% cluster
clid = spm_clusters(xyzlist);

csize = zeros(norig,1);     % in Original (full voxel) index

u = unique(clid);
for i = 1:length(u)
    wh = find(clid == i);   % voxels in this cluster
    csize(wh1(wh)) = length(wh); % put cluster size there; translate to full index
end

indic = csize > sizethr;

% results display stuff
sigvox = find(indic);

fprintf(1,'\nThresh = %3.4f, size threshold = %3.0f: %3.0f sig. voxels.\n',thr1,sizethr,length(sigvox));

if isempty(sigvox),
    return
else
    rg = [min(csize(sigvox)) max(csize(sigvox))];
end
fprintf(1,'Cluster sizes range from %3.0f to %3.0f\n\n',rg(1),rg(2));


return


% --------------------------------------------------------------------
% Quick way to write a mask image for significant data
% --------------------------------------------------------------------

function indic2mask(indic,activation_proportions,MC_Setup,name)
wh = find(indic);

data = zeros(size(activation_proportions));
data(wh) = activation_proportions(wh);
meta_reconstruct_mask(data,MC_Setup.volInfo.xyzlist,MC_Setup.volInfo.dim(1:3),1,MC_Setup.volInfo,name);
return




% ====================================================================
% --------------------------------------------------------------------
%
% Other utility functions
%
% --------------------------------------------------------------------
% ====================================================================

function erase_string(str1)
fprintf(1,repmat('\b',1,length(str1))); % erase string
%fprintf(1,'\n');
return


function h = makeColumn(h)
if length(h) > size(h,1) && size(h,1)==1, h = h'; end
return



function [h,x,nbins] = prepare_histogram(data)

nbins = min(length(data)./5,100);

[h,x] = hist(data,nbins);

% pad to make nice display
if length(x)>1, firstx = 2*x(1) - x(2); else firstx = 0; end
lastx = 2*x(end) - x(end-1);

% make column
h = makeColumn(h);
x = makeColumn(x);

z = zeros(1,size(h,2));

h = [z;h;z]; x = [firstx;x;lastx];

h = h ./ repmat(sum(h),size(h,1),1);

return



function [volInfo,clusters] = parcel_images(maskname,image_names) 
%[volInfo,clusters] = parcel_images(maskname,image_names)

%% Get data 
str = display_string('Loading data.');
[dat,volInfo] = iimg_get_data(maskname,image_names);
erase_string(str);

%% Rank data
str = display_string('Getting ranks.');
n = size(dat,2);
rdat = zeros(size(dat));
for i = 1:n
    % see also tiedrank in matlab
    rdat(:,i) = rankdata(dat(:,i));
end
erase_string(str);

%% Get principal components
[eigvec, compscore, eigval] = princomp(rdat,'econ');
figure;plot(eigval,'ko-');

% figure;plot(0:length(eigval),[0; cumsum(eigval)./sum(eigval)],'ko-')
% ylabel('Variance explained'); xlabel('Components')

nc = input('how many comps to save? ');

volInfo.eigval = eigval;
volInfo.eigvec = eigvec(:,1:nc);
volInfo.score = compscore(:,1:nc);

%% Cluster voxels based on locations in component space

% Locations of voxels in component space
locs = volInfo.eigvec * diag(sqrt(volInfo.eigval(1:nc)));

str = display_string('Clustering voxels.');

nparcels = 16;
idx = kmeans(locs,nparcels);

erase_string(str);

%% plot
tor_fig(1,2);
colors = {[1 0 0] [0 1 0] [0 0 1] [1 1 0] [0 1 1] [.5 1 0] [0 1 .5] [1 .5 0] [1 0 .5] [0 .5 1] [.5 0 1]};
colors = [colors colors];

for i = 1:nparcels
    wh = find(idx==i);
    plot(locs(wh,1),locs(wh,2),'.','Color',colors{i});
end
xlabel('Dim 1'),ylabel('Dim 2')

subplot(1,2,2);
for i = 1:nparcels
wh = find(idx==i);
plot(locs(wh,3),locs(wh,2),'.','Color',colors{i});
end
xlabel('Dim 3'),ylabel('Dim 2')
drawnow

%% get clusters of voxels for each class
clusters = cell(1,nparcels);
corrclusters = [];

for i = 1:nparcels

    volInfo.classes(:,i) = double(idx==i);

    avgregion = dat * volInfo.classes(:,i);
    voldata = iimg_reconstruct_3dvol(volInfo.classes(:,i),volInfo);
    cl = mask2clusters(voldata,volInfo.mat);
    
    % cluster processing and data extraction
    sz = cat(1,cl.numVox); wh = find(sz < 5); cl(wh) = [];
    cl = tor_extract_rois(image_names,cl);
    cl = rmfield(cl,'P');
    cl = rmfield(cl,'imP');

%% correlate with behavior
%     [cc,pp] = corrcoef([EXPT.cov cat(2,cl.timeseries)]);
%     wh = find(pp(1,2:end) < .05);
%     corrcl = cl(wh);
%     for j = 1:length(corrcl)
%         [x,y,r,p,rrob,prob] = partialcor(EXPT.cov,cat(2,cl(j).timeseries),1);
%         sz = size(corrcl(j).XYZ,2);
%         corrcl(j).Z = repmat(cc(1,wh(j)+1),1,sz);
%     end
    
% robust partial correlations
    corrcl = [];
    for j = 1:length(cl)
        [x,y,r,p,rrob,prob] = partialcor(EXPT.cov,cl(j).timeseries,1);
        if prob < .05, 
            sz = size(cl(j).XYZ,2);
            cl(j).Z = repmat(rrob,1,sz);
            corrcl = [corrcl cl(j)];
            
        end
    end
    
    corrclusters = [corrclusters corrcl];
    
    %if ~isempty(corrcl), cc(1,find(wh)+1), montage_clusters([],corrcl); end
    
    if i == 1, cluster_orthviews(cl,colors(i));
    else
        cluster_orthviews(cl,colors(i),'add');
    end
    
    clusters{i} = cl;
    %volInfo.parcel_names{i} = input('Name this parcel: ','s');
    volInfo.averages(:,i) = avgregion;
end
%% end loop

volInfo.classes = sparse(volInfo.classes);
return


% Component plot
% nmdsfig(pc,n,nms)

% clustering

% classes = clusterdata(score(:,1:3),'maxclust',10,'linkage','average');







function str = display_string(str)
str = sprintf(str); fprintf(1,'%s',str);
return


function erase_string(str)

len = length(str);
str2 = repmat('\b',1,len);

fprintf(1,str2);

return

DB.rootn = sqrt(DB.Subjects);
[DB.connumbers,DB.pointind] = unique(DB.Contrast);
DB.rootn = DB.rootn(DB.pointind);

[DB.pointind,ii] = sort(DB.pointind);
DB.rootn = DB.rootn(ii);
DB.connumbers = DB.connumbers(ii);

% -----------------------------------------------------
% get Final contrast weights
% -----------------------------------------------------
if isfield(DB,'SubjectiveWeights'),
w = DB.rootn .* DB.SubjectiveWeights(DB.pointind);
else
w = DB.rootn;
end
% these must sum to 1 !
DB.studyweight = w ./ sum(w);
% ------------------------------------------------
% save summary info from this map only
% ------------------------------------------------

[volInfo,mask] = iimg_read_img(DB.maskname,1);
clear cl
[v,s] = size(MC_Setup.unweighted_study_data);

% ------------------------------------------------
% set up blobs for all studies
% ------------------------------------------------
cl = cell(1,s);
for i = 1:s
    cl{i} = iimg_indx2contiguousxyz(MC_Setup.unweighted_study_data(:,i),volInfo,1);
end

% ------------------------------------------------
% Initialize empty mask (to save time later)
% ------------------------------------------------
emptymask = zeros(volInfo.dim(1:3));
function [cl,anyStudy,studyByCluster] = meta_SOMclusters(SOMResults,theData,whSOM,meth)
% [cl,anyStudy,studyByCluster] = meta_SOMclusters(SOMResults,theData,whSOM,meth)
%
% Make clusters and indicator matrices for SOM results
%
% Two modes:
% 'single'
% Gets clusters and indicators for a SOM of your choosing (whSOM)
% [cl,anyStudy,studyByCluster] = meta_SOMclusters(SOMResults,theData,whSOM,'single')
%
% 'group'
% Gets indicators for all SOMs and does multiple correspondence analyses on
% it; makes plots
% [cl,anyStudy,OUT] = meta_SOMclusters(SOMResults,theData,[],'group')

cl = []; anyStudy = []; studyByCluster = [];

if ~(exist('meth') == 1) || isempty(meth), meth = 'group';, end

switch meth
    case 'group'

        fprintf(1,'meta_SOMclusters: Getting and plotting all SOMs. 000');
        cl = {};
        
        % names and sizes
        n = size(SOMResults.SOM,2);
        for i=1:n,
            nms{i}=[num2str(i)];,
            colors{i} = rand(1,3);
        end
        
        for i = 1:n
            fprintf(1,'\b\b\b%03d',i);
            [cltmp,anyStudy(:,i)] = meta_SOMclusters(SOMResults,theData,i,'single');
            cltmp = rmfield(cltmp,'P');
            cl{i} = cltmp;
            cl{i}(cat(1,cl{i}.numVox) < 5) = [];
            nvox(i) = sum(cat(1,cl{i}.numVox));
            
            if i == 1, cluster_orthviews(cl{i},colors(i));,
            else,cluster_orthviews(cl{i},colors(i),'add');
            end
        end
        
        fprintf(1,' Done. Performing MCA.');
        anyStudy = double(anyStudy);
        MCA = tor_mca(anyStudy,[],1,[]);
    
        [OUT] = permute_mtx(double(anyStudy));
        OUT.MCA = MCA;
        OUT.numVox = nvox;
        OUT.names = nms;
        OUT.colors = colors;
        
        figure;
        %nmdsfig(MCA.score(:,1:2),ones(size(MCA.score,1),1),OUT.names,OUT.sigbonf);
        nmdsfig(MCA.score(:,1:2),(1:n)',OUT.names,OUT.sigbonf,.5,[],[],colors);
        
        studyByCluster = OUT;

        fprintf(1,'\n');
        
    case 'single'

        %whSOM = 1;

        hdr = SOMResults.header;
        vol = zeros(hdr.dim(1:3));
        ii = find(SOMResults.IDX == whSOM);
        vol(SOMResults.iMask(ii)) = SOMResults.WTS(ii);
        cl = mask2clusters(vol,hdr.mat);

        % view clusters
        %cluster_orthviews(cl,'unique');

        % figure out whether any study produced a non-zero value in the SOM area
        x = theData(ii,:);
        anyStudy = (sum(x,1) > 0)';

        if nargout > 2
            % figure out whether any study produced a non-zero value in each contiguous
            % cluster within the SOM
            [x,y,z]=ind2sub(hdr.dim(1:3),SOMResults.iMask(ii));
            indx = spm_clusters([x y z]');

            for i = 1:max(indx)
                wh = ii(indx == i); % which points in cluster
                x = theData(wh,:);  % pts by studies
                studyByCluster(:,i) = (sum(x,1) > 0)';
            end
            studyByCluster = double(studyByCluster);

            %burt = double(studyByCluster)' * double(studyByCluster);
        end

    otherwise
        error('Unknown method.  see help file for choices.');
end


return
function P = check_valid_imagename(P)
% P = check_valid_imagename(P)

for i = 1:size(P,1)
    
    if ~(exist(deblank(P(i,:))) == 2)
    
        fprintf(1,'Cannot find image:\n%s\nPlease select correct directory.\n',P(i,:));
        
        dd = spm_get(-1,'*','Select directory.');
        %dd = [dd filesep];
        
        [myd] = fileparts(P(i,:));
        len = length(myd);
        
        P = [repmat(dd,size(P,1),1) P(:,len+1:end)];
        
        disp(P(i,:));
        
    end
end

        
return


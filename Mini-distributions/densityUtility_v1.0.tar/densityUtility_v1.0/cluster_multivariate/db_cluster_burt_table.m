function db_cluster_burt_table(clusters,fnames,DB)
% function db_cluster_burt_table(clusters,field list (cell array of strings),DB)
%
% tor wager
% Prints table of studies and lists whether they found activation in each cluster\
%
% warning: does not count separate CONTRASTS, just STUDIES.
% DB is a structure that contains all info from the database
%
% clusters is a struct in which XYZmm field has list of points
% --should be output of database2clusters, which contains all fields
%
% fnames is a cell array that has names of all fields in clusters to use
% each field should be a list of 1's and 0's in this case, for now.

verbose = 0;

disp('Output of db_cluster_burt_table')

[ustudy,suni] = unique(DB.Study);
disp([num2str(length(ustudy)) ' studies in database'])
fprintf(1,'\n')
        
for stud = 1:length(ustudy)

        % get vectors of values in fnames (e.g., 1 or 0) for each study
        % -------------------------------------------------------------------
        for i = 1:length(fnames)
            eval(['tmp1 = DB.' fnames{i} '(suni);'])
            fmatx(stud,i) = tmp1(stud);
        end
            
    
    % get number of peaks in cluster and fill in rmatx (matx of regional peaks)
    % -------------------------------------------------------------------
    for i = 1:length(clusters)
    
        tmp1 = strcmp(ustudy{stud},clusters(i).Study);
        rmatx(stud,i) = sum(tmp1);
     
    end
    
end
        
    
    % Contingency table - header row
    % -------------------------------------------------------------------
    
    print_header(fnames,clusters)
    
    
    % Contingency table - body
    % -------------------------------------------------------------------
    for i = 1:length(ustudy)
        fprintf(1,'%s\t',ustudy{i})
        for j = 1:length(fnames), fprintf(1,'%3.0f\t',fmatx(i,j)), end
        for j = 1:length(clusters), fprintf(1,'%3.0f\t',rmatx(i,j)), end
        fprintf('\n')
    end
  
    
        
    % Compute indicator matrix and Burt table
    % -------------------------------------------------------------------
    
    rmatx = (rmatx > 0);
    bmatx = [fmatx rmatx];  % superindicator matrix
    burt = bmatx'*bmatx;    % Burt table
    
    
    
    % Indicator matrix - header row
    % -------------------------------------------------------------------
    fprintf('\n')
    fprintf('Superindicator matrix\n')
    print_header(fnames,clusters)
    
    % Indicator matrix - body
    % -------------------------------------------------------------------
    str = repmat('%3.0f\t',1,size(bmatx,2));
    
    for i = 1:length(ustudy)
        fprintf(1,'%s\t',ustudy{i})
        fprintf(1,str,bmatx(i,:)), 
        fprintf('\n')
    end
    
    
    %  Burt table - header row
    % -------------------------------------------------------------------
    fprintf('\n')
    fprintf('Burt Table\n')
    print_header(fnames,clusters)
    
    % Burt table - body
    % -------------------------------------------------------------------
    str = repmat('%3.0f\t',1,size(bmatx,2));
    
    for i = 1:length(fnames)
        fprintf(1,'%s\t',fnames{i})
        fprintf(1,str,burt(i,:)), 
        fprintf('\n')
    end
 
    for i = 1:length(clusters)
        fprintf(1,'%s\t',clusters(i).name)
        fprintf(1,str,burt(i,:)), 
        fprintf('\n')
    end
    
    bmatx1 = bmatx;
    bmatx = bmatx - mean(bmatx(:));
    bmatx = bmatx - repmat(mean(bmatx),size(bmatx,1),1);    % rows
    bmatx = bmatx - repmat(mean(bmatx,2),1,size(bmatx,2));  % columns
    
        % Centered Indicator matrix - header row
    % -------------------------------------------------------------------
    fprintf('\n')
    fprintf('Double-Centered Superindicator matrix\n')
    print_header(fnames,clusters)
    
    % Centered Indicator matrix - body
    % -------------------------------------------------------------------
    str = repmat('%3.6f\t',1,size(bmatx,2));
    
    for i = 1:length(ustudy)
        fprintf(1,'%s\t',ustudy{i})
        fprintf(1,str,bmatx(i,:)), 
        fprintf('\n')
    end

    fprintf(1,'\nBootstrapping\n')
    % remove rows so that some studies activating more overall does not influence
    % the correspondence values
    imatx = bmatx1; 
    imatx = imatx - repmat(mean(imatx,2),1,size(imatx,2));  % rows
    OUT = permute_mtx(imatx,'ss',1,5000,length(fnames));
    
    % here we scale columns, because we want to interpret the columns in metric space
    nms = fnames; for i = 1:size(bmatx,2)-length(fnames),nms = [nms {['V' num2str(i)]}];, end
    tor_mca(bmatx1,'col',length(fnames),nms)
    
return
    



function print_header(fnames,clusters)

fprintf(1,['\nStudy\t']) 
    for j = 1:length(fnames)    
         fprintf(1,'%s\t',fnames{j}) 
    end

    for j = 1:length(clusters)
        if isfield(clusters,'BAstring'), fprintf(1,'%s\t',clusters(j).BAstring)
        else, fprintf(1,'%s\t',clusters(j).name)
        end
    end
    fprintf('\n\t')
    for j = 1:length(fnames),fprintf(1,'\t'),end
    for j = 1:length(clusters)
        fprintf(1,'%3.0f,%3.0f,%3.0f\t',clusters(j).mm_center(1),clusters(j).mm_center(2),clusters(j).mm_center(3))
    end
    fprintf('\n')
    
return
    
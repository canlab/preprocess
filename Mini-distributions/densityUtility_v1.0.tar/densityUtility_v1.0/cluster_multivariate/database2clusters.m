function [newcl,DB] = database2clusters(db_mat,clusters,mydist)
% function [newcl,DB] = database2clusters(db_mat,clusters,mydist)
%
% tor wager
%
% This function turns a database file (stored as variables in a .mat file)
% as created with read_database.m
% into a clusters structure, by finding the points
% that fall within mydist mm from any in-cluster voxel
%
% db_mat: the .mat file containing the database
% clusters: a clusters structure, see tor_extract_rois.m, that has the
%           clusters to group data points in the database at a specified distance
% mydist: distance in mm (euclidean)
%   * if empty, uses 2 mm in a dominance metric 
%       i.e., point must be w/i 2 mm of cluster voxel on every
%       dimension (x,y,z)
%
% newcl.XYZ contains point coordinates
%newcl = database2clusters('switching_database.mat',clusters,5);
%montage_clusters([],clusters,{'r' 'b'},XYZ)
%montage_clusters([],clusters,{'r' 'b'},cat(1,newcl.XYZ))

% ---------------------------------------------
% Put variables in structure
% ---------------------------------------------

load(db_mat)
num = length(Study);
N = whos;

for i = 1:length(N)
    
    if any(N(i).size == num)
        %eval(['whos ' N(i).name])
        str = (['if size(' N(i).name ',2) > size(' N(i).name ',1), ' N(i).name '=' N(i).name ''';, end']);
        eval(str)
        %eval(['whos ' N(i).name])
        eval(['DB.' N(i).name ' = ' N(i).name ';'])
    end
    
end

XYZ = [DB.x DB.y DB.z];
N = fieldnames(DB);
newcl = clusters;

dodom = 0;
if isempty(mydist), mydist = 2;, dodom = 1;, end

% ---------------------------------------------
% Put variables in structure
% ---------------------------------------------

for i = 1:length(clusters)
    
    % find which points are in-cluster (w/i 3.464 mm)
    % max euclidean distance in same 2 x 2 x 2 mm voxel is sqrt(4+4+4) = 3.46 mm
    % use dominance metric: max dist on any dimension is 2 mm
    
    disp(['Doing cluster ' num2str(i)])

    XYZc = clusters(i).XYZmm';
    ind = 1;
    newcl(i).XYZ = [];
    
    for j = 1:size(XYZ,1)   % find all XYZ within cluster
        
       xm = abs(XYZ(j,1) - XYZc(:,1));
       ym = abs(XYZ(j,2) - XYZc(:,2));
       zm = abs(XYZ(j,3) - XYZc(:,3));
            
        if dodom
            % dominance metric
            d = max([xm ym zm]');
        else
            % euclidean dist
            d = (xm.^2 + ym .^2 + zm .^2) .^.5;
        end
            

        %mincl = XYZc(find(d==min(d)),:);
        %disp(['Point: ' num2str(XYZ(j,:)) '--cluster: ' num2str(mincl(1,:)) ': min d = ' num2str(min(d))])
        
        if min(d) <= mydist, 
            
            %mincl = XYZc(find(d==min(d)),:);
            %disp(['Point: ' num2str(XYZ(j,:)) '--cluster: ' num2str(mincl(1,:)) ': min d = ' num2str(min(d))])
        
        
            for k = 1:length(N)
                
                eval(['newcl(i).' N{k} '(ind,:) = DB.' N{k} '(j,:);'])
        
            end
            %disp('found one')
            %keyboard
            
            ind = ind + 1;
            
        end
        
    end
    
    newcl(i).XYZ = newcl(i).XYZ';
    disp(['Found ' num2str(ind-1) ' points'])
end
        
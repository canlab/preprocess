function db_cluster_table(clusters,fnames)
% function db_cluster_table(clusters,fnames)
%
% tor wager
% counts studies in each cluster
%
% clusters is a struct in which XYZmm field has list of points
% --should be output of database2clusters, which contains all fields
%
% fnames is a cell array that has names of all fields in clusters to use

fprintf(1,'Study\tCluster\tx\ty\tz\t')
for i = 1:length(fnames)
    fprintf(1,'%s\t',fnames{i})
end
fprintf(1,'\n')

for i = 1:length(clusters)
    
    cl = clusters(i);
    
    for k = 1:length(clusters(i).x)
    
        fprintf(1,['%s\t%3.0f\t%3.0f\t%3.0f\t%3.0f\t'],cl.Study{k},i,cl.x(k),cl.y(k),cl.z(k))
        
        for j = 1:length(fnames)

            eval(['tmp1 = cl.' fnames{j} '(k);'])
            fprintf(1,'%3.0f\t',tmp1)
            
        end
        
        fprintf(1,'\n')
        
    end
    
end
         
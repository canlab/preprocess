function tor_mca(imatx,smeth,n,nms)
% tor_mca(imatx,smeth,n,nms)
%
% multiple correspondence analysis
% enter an indicator matrix and a scaling method
% 
% imatx: indicator matrix of 1's and 0's
% smeth: 'col' 'row' 'rowcol'
% n:     number of variables in first set
%        now hard-coded for two sets of variables in diff colors
% nms:   cell array of names of varables
%
% I think the standard scaling is column; see Michalidis and Statsoft text
% Not sure whether to analyze Burt table or correlation matrix;
% sources seem to suggest Burt directly.
imatx2 = imatx;
burt2 = imatx'*imatx;   % for last plot

imatx = imatx - mean(imatx(:));

if findstr(smeth,'row')
    imatx = imatx - repmat(mean(imatx,2),1,size(imatx,2));  % rows
end

if findstr(smeth,'col')
    imatx = imatx - repmat(mean(imatx),size(imatx,1),1);    % cols
end

burt = imatx'*imatx;

[pc,score,latent] = princomp(burt);

% Eigenvalue plot
figure('Color','w'), set(gca,'FontSize',18),bar(latent),
xlabel('Components'),ylabel('Variance')

% Component plot
figure('Color','w'), set(gca,'FontSize',18),hold on
plot(pc(1:n,1),pc(1:n,2),'rs','MarkerFaceColor','r','LineWidth',2)
plot(pc(n+1:end,1),pc(n+1:end,2),'bo','MarkerFaceColor','b','LineWidth',2)
for i = 1:size(pc,1),text(pc(i,1),pc(i,2)+.03,nms{i},'Color','k');, end
xlabel('Component 1'),ylabel('Component 2')

% Profile plot
figure('Color','w'), set(gca,'FontSize',18),hold on
x = diag(1./diag(burt2)) * burt2; % this normalizes cov by row var %corrcoef(imatx);
plot(x(1:n,n+1:end)','LineWidth',2); 
legend(nms{1:n})
set(gca,'XTick',1:length(nms)-n)
set(gca,'XTickLabel',nms(n+1:end))
ylabel('% Studies activating') 


% Chi-square: Actual vs. expected
% for the table as a whole, and for each row
% do for each sub-matrix (correspondence analysis on each indicator)
% and for the cross-products (indicator 1 vs. 2)
%keyboard
%chi2 = get_chi2(burt)

%tmp = diag(burt2); e = tmp(1:n) * tmp(n+1:end)'
%e = e ./ sum(e(:))

% is there some combination of weights on columns (Regions) that
% allows us to discriminate among switch types?

% instead, we could permute the columns independently and get
% univariate significance levels for each pair of columns
% but this may be the same as standard correlation?
% ...and also multivariate sig. for chi2 value or something.

return


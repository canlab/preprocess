function cluster_chi2(clusters,fnames,DB)
% function cluster_chi2(clusters,field list (cell array of strings),DB)
%
% tor wager
% counts studies in each cluster
% warning: does not count separate CONTRASTS, just STUDIES.
% DB is a structure that contains all info from the database
%
% clusters is a struct in which XYZmm field has list of points
% --should be output of database2clusters, which contains all fields
%
% fnames is a cell array that has names of all fields in clusters to use

verbose = 0;

disp('Output of cluster_chi2 function')

[tmp,suni] = unique(DB.Study);
disp([num2str(length(tmp)) ' studies in database'])
fprintf(1,'\n')
        

% Count OVERALL did vs. did not involve this condition
% -------------------------------------------------------------------
for j = 1:length(fnames)
           
        str = ['tmp12 = DB.' fnames{j} ';'];
        eval(str)

        tmp12 = tmp12(suni);
        bnull(j) = sum(tmp12 == 1) ./ length(tmp12);
        
        disp([fnames{j} ': ' num2str(100*bnull(j)) '% of studies'])
end
    

for i = 1:length(clusters)
    
    numstudies = length(unique(clusters(i).Study));
    numpts = size(clusters(i).XYZall,1);
    disp(['Cluster ' num2str(i) ': ' num2str(numpts) ' points in ' num2str(numstudies) ' studies.'])
    
    for j = 1:length(fnames)
        
        % count Yesses for this condition
        % -------------------------------------------------------------------
        
        str = ['stud = clusters(i).Study(find(clusters(i).' fnames{j} '));'];
        eval(str)
        
        [allstud,uni] = unique(clusters(i).Study);
        [ustud] = unique(stud);
        scount(j,1) = length(ustud);
            
        if verbose
            fprintf(1,'\tStudies involving %s\n',fnames{j})
        
            for k = 1:length(ustud)
            
                pks(k) = sum(strcmp(stud,ustud{k}));
                fprintf(1,'\t\t%s %3.0f pk\n',ustud{k},pks(k))
            
            end
            
        end
        
        % count Nos for this condition
        % -------------------------------------------------------------------
        
        str = ['stud = clusters(i).Study(find(~clusters(i).' fnames{j} '));'];
        eval(str)
        
        ustud = unique(stud);
        scount(j,2) = length(ustud);
                 
        if verbose
            fprintf(1,'\tStudies NOT involving %s\n',fnames{j})
        
            for k = 1:length(ustud)
            
                fprintf(1,'\t\t%s %3.0f pk\n',ustud{k},sum(strcmp(stud,ustud{k})))
            
            end
        
            fprintf(1,'\n')
        end
               
        % save overall criterion column
        % -------------------------------------------------------------------
        str = ['tmp11 = clusters(i).' fnames{j} ';'];
        eval(str)
        x{i}(:,j) = tmp11(uni);
        
        
    end
    
    % Chi2 and binomial tables
    % -------------------------------------------------------------------
    yesses = scount(:,1)';
    totals = sum(scount,2)';
    [chi2,colnms] = computechi2(yesses,totals);
    fprintf(1,'\n\tOmnibus chi-square test for diffs among conditions in p of study reporting peak\n\t')

    fprintf(1,'Chi2\tdf\tp\tCramV\tSig?\tWarn\tPyes\t\n'), 
    fprintf(1,'\n\t'), fprintf(1,'%3.3f\t',chi2)
    
    fprintf(1,'\n')
    b = binopdf(yesses,totals(1),bnull);
    b = min(b,1-b);
    fprintf(1,'\n\tP-values for binomial test within each condition\n\t')
    for j = 1:length(fnames), fprintf(1,'%s ',fnames{j}),end
    fprintf(1,'\n\t'), fprintf(1,'%3.3f\t',b)
    
    % Contingency table
    % -------------------------------------------------------------------
    fprintf(1,['\n\tStudy\t']) 
    for j = 1:length(fnames)    
         fprintf(1,'%s\t',fnames{j}) 
    end
    fprintf('\n\t')
    for j = 1:length(allstud)
        fprintf(1,['%s\t' repmat('%3.0f\t',1,length(fnames)) '\t\n\t'],allstud{j},x{i}(j,:))
    end
    
    fprintf('\n\t')
    
end


return
    
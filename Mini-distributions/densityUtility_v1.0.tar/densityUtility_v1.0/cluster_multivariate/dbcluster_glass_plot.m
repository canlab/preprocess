function dbcluster_glass_plot(newcl)
% 
% tor wager
% newcl = clusters structure, output of database2clusters.m
%
% Creates 3 views of glass brain with points in each cluster plotted
% in different symbols

mycol = {'bo' 'rs' 'go' 'ms' 'yd' 'c^' 'bv' 'ro' 'gs' 'md' 'y^' 'cv' 'bs' 'r^' 'gd' 'mo' 'yv' 'cs'};
while length(mycol) < length(newcl), mycol = [mycol mycol];, end
    

figure('Color','w')
subplot(1,3,1), hold on

for i = 1:length(newcl)
    plot3(newcl(i).XYZ(1,:),newcl(i).XYZ(2,:),newcl(i).XYZ(3,:),mycol{i})
end

addbrain
view(0,90)
camzoom(1.25)

subplot(1,3,2), hold on
for i = 1:length(newcl)
    plot3(newcl(i).XYZ(1,:),newcl(i).XYZ(2,:),newcl(i).XYZ(3,:),mycol{i})
end
addbrain
view(270,0)
camzoom(1.25)

subplot(1,3,3), hold on
for i = 1:length(newcl)
    plot3(newcl(i).XYZ(1,:),newcl(i).XYZ(2,:),newcl(i).XYZ(3,:),mycol{i})
end
addbrain
view(0,0)
camzoom(1.25)
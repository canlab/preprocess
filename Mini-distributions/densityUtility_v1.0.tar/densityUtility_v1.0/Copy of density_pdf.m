function [u,OUT] = density_pdf(n,iterations)
%function [u,OUT] = density_pdf(n,iterations)
%
% given a brain mask and n coordinate points, this function computes
% a null hypothesis probability density function based on the number 
% of iterations specified, and returns significant density thresholds
% at p < crit_p (default = 0.05).
%
% height thresholds
%
% n is the number of random points
%
% considerations
% - edge effects in determining density
% - speed
% - multiple coordinates at the same point
%
% Tor Wager, 2/6/2002

P = ['brain_mask_1mm.img'];
P = ['brain_avg152T1.img'];     % 2 mm voxels
radius_mm = 10;
th = [.001 .005 .01];
cls = [10 100 1000];
crit_p = .05;

mask_file = P;
t1 = clock;
fname = input('Enter file name for the output ','s');

for i = 1:iterations
    
    % -----------------------------------------------------
    % * get density mask of random values
    % -----------------------------------------------------
   
    if i == 1,
        [mask,searchmask,voxsize] = get_random_mask(n,P); 
        t3 = clock;, 
        oldrad = radius_mm;
        radius = radius_mm ./ mean(voxsize);
        sphere_vol = 4 * pi * radius_mm ^ 3 / 3;
        P = searchmask;     % stores the actual array in P  
    else
        [mask] = get_random_mask(n,P);
    end
                 
    dm = mask2density(mask,radius,searchmask,sphere_vol);
    
    
    % -----------------------------------------------------
    % * checking and setup stuff for 1st iteration
    % -----------------------------------------------------
    
    if i == 4   
        t4 = clock;
        if any(size(mask) - size(P)), error('Mask sizes do not match!'), end
        fprintf(1,'density.pdf | %3.0f voxels, radius = %3.0f mm = %3.2f voxels',sum(searchmask(:)>0),oldrad,radius);
        fprintf(1,'\t%3.0f iterations x %3.0f s per iteration\n',iterations,etime(t4,t3)./4)  
        clear oldrad, clear t3, clear t4
        figure;imagesc(dm(:,:,round(size(dm,3)./2))); pause(5); close
    end   
    
    % -----------------------------------------------------
    % * max height
    % -----------------------------------------------------
    maxd(i) = max(max(max(dm)));
    
    % -----------------------------------------------------
    % * cluster size distribution
    % -----------------------------------------------------
    [numc(:,:,i), cl_size(i,:)] = density2clusters(dm,th,cls);
    
    % -----------------------------------------------------
    % * save if we need to
    % -----------------------------------------------------
    if mod(i,20) == 0,
        eval(['save ' fname ' mask_file radius th cls n i dm maxd numc cl_size'])
        fprintf(1,'%d . ',i)
    end
    
    if mod(i,500) == 0
        t2 = clock;
        fprintf(1,'%3.0f s\n',etime(t2,t1))
    end
    
end

% -----------------------------------------------------
% * get the 95% value for all variables
% -----------------------------------------------------
[u,xpdf,ypdf,xcdf,ycdf,h] = d_pdf(maxd,crit_p,2,f1,f2);

index = 0;
for j = 1:size(numc,2)
    for i = 1:size(numc,1)

        index = index + 1;
        vec = str2num(num2str(numc(i,j,:)));
        cl_u(index) = d_pdf(vec,crit_p);

    end
end
cl_u = reshape(cl_u,size(numc,1),size(numc,2));

OUT.mask_file = mask_file;
OUT.u    = u;
OUT.cl_u = cl_u;
OUT.radius = radius;
OUT.th  = th;
OUT.cls = cls;
OUT.n   = n;
OUT.xpdf = xpdf;
OUT.ypdf = ypdf;
OUT.xcdf = xcdf;
OUT.ycdf = ycdf;
OUT.maxd = maxd;
OUT.numc = numc;
OUT.cl_size = cl_size;
OUT.legend = mylegend;

eval(['save ' fname ' u OUT'])

[f1,f2] =  plot_dens_results(OUT);

t2 = clock;
fprintf(1,'\ndone!\t%3.0f s, average %3.0f s per iteration\n',etime(t2,t1),etime(t2,t1)/iterations) 

return



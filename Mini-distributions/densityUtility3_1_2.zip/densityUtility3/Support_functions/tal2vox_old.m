function vox=tal2vox(tal,VOL)
% converts from talairach coordinate to voxel coordinate
% based on variables from SPM.M (passed here for 
% faster operation)
% e.g., foo=tal2vox([-30 28 -30], VOL)

%
vox=[0 0 0];
vox(1)=(tal(1)-VOL.M(1,4))/VOL.M(1,1);
vox(2)=(tal(2)-VOL.M(2,4))/VOL.M(2,2);
vox(3)=(tal(3)-VOL.M(3,4))/VOL.M(3,3);

return


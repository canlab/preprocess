function [realchi2,chi2p,sig,df,tab] = nonparam_chi2(y,condf,iter,varargin)
% [realchi2,chi2p,sig,df,tab] = nonparam_chi2(y,condf,iter,[w])
%
% weights should be mean = 1

if length(varargin) > 0, w=varargin{1};, else, w=ones(size(y));, end


[realchi2,df,tmp,tmp,warn,tab,e] = chi2test([y condf],'obs'); 

%iter = 5000;
n = length(y);

% weights
y = y .* w;

% initialize output
chi2 = zeros(n,1);

for i = 1:iter
    yp = y(randperm(n));
    
    [chi2(i)] = chi2test([yp condf],'obs');
end

chi2p = sum(chi2>=realchi2) ./ length(chi2);
    
sig = chi2p <= .05;


return


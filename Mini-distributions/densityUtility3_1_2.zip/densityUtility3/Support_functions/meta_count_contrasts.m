function [num,wh,weighted_num] = meta_count_contrasts(DB,testfield,fieldvalue)
% [num,wh,weighted_num] = meta_count_contrasts(DB,testfield,fieldvalue)
%
% e.g., testfield = 'Stimuli'
% fieldvalue = 'faces';
% [num,wh] = meta_count_contrasts(DB,testfield,fieldvalue)

wh = strcmp(DB.(testfield),fieldvalue);
[u,i] = unique(DB.Contrast(wh));
num = length(u);

if nargout > 2
    % weighted total
    for i = 1:length(u)
        tmp = find(DB.connumbers == u(i));   % the index in contrast list for this con number
        if isempty(tmp), disp('Warning! No contrast-list entry for existing contrast number.  Was DB modified?');,end
        whcons(i) = tmp;
    end

    if isempty(u), weighted_num = 0;, return, end
    
    w = DB.studyweight;  w = w ./ mean(w);
    w = w(whcons);
    weighted_num = sum(w);

end


return



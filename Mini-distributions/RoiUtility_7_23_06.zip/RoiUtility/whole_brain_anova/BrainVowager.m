% shell to start SCNlab BrainTools

global EXPT
global cl

BrainVowager_gui;

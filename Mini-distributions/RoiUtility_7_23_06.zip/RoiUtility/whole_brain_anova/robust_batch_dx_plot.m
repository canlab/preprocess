function EXPT = robust_batch_dx_plot(EXPT,actionstr,varargin)
% EXPT = robust_batch_dx_plot(EXPT,actionstr,[startat directory])
%
% actionstr = 'save' 'plot' 'both'

if length(varargin) > 0, startat = varargin{1};, else, startat = 1;, end

d = dir('robust00*');

if strcmp(actionstr,'save') | strcmp(actionstr,'both')

for i = startat:length(d)
    
    fprintf(1,'\n*---------\n%s\n',d(i).name)
    
    cd(d(i).name)
    
    d2 = dir('robust00*mat');
    
    for j = 1:length(d2)
        
        fprintf(1,'\t%s\n',d2(j).name)
        clear cl
        load(d2(j).name)
        
        if ~isempty(cl)
            [cl,EXPT] = extract_dxbeta_data(EXPT,cl,0);
        end
        
        eval(['save ' d2(j).name ' cl'])
        
    end
    
    cd ..
    
end

end     % save part




if strcmp(actionstr,'plot') | strcmp(actionstr,'both')

    name = input('Type name of mat file containing cl variable (clusters), no extension, e.g., robust00*_intercept_pos: ','s');
    name = [name '.mat'];
    
    doindiv = input('Plot whole group (0) or individual diffs high/low split (1): ');
    
    smoothlen = input('Enter # tp to weight for exponential smoothing (0 is none, recommend 3 for TR=2): ');
    
    
    for i = startat:length(d)
    
        fprintf(1,'\n*---------\n%s -- SAVING IN TIMECOURSE_PLOTS SUBDIR\n',d(i).name)
    
        cd(d(i).name)
    
        d2 = dir(name);
        fprintf(1,'\t%s\n',d2.name)
        clear cl
        load(d2.name)
    
        if ~isempty(cl)
            plot_dx_hrfs(EXPT,cl,0,1,smoothlen,doindiv);
        end
        
        cd ..
    end
    
    
end % do plot part




return
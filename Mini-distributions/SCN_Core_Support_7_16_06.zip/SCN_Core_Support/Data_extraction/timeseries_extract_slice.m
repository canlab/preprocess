function sl = timeseries_extract_slice(V,sliceno);
        % function sl = timeseries_extract_slice(V,sliceno)
        %
        % For a given set of image names or memory mapped volumes (V)
        % extracts data from slice # sliceno and returns an X x Y x time
        % matrix of data.
        % uses spm_slice_vol.m
        %
        % tor wager
      
            
        if isstr(V), V = spm_vol(V);,end
            
            
        mat = spm_matrix([0 0 sliceno]);     % matrix for spm_slice_vol
        
            
        for i = 1:length(V)
                
            sl(:,:,i) = spm_slice_vol(V(i),mat,V(i).dim(1:2),0); 
            
        end


        return
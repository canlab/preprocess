function subcl = subclusters_from_local_max(cl,dthresh)

subcl = [];

for i = 1:length(cl)
    
    [xyz, XYZmm, Z, class] = cluster_local_maxima(cl(i),dthresh,0);

    if all(class == 0)  % no peak maxima; just use the existing cluster
        this_subcl = cl;
    else
        this_subcl = cluster2subclusters(cl(i),class);
    end
    
    % keep track of which larger cluster this came from; for cluster_table
    for j = 1:length(this_subcl)
        this_subcl(j).from_cluster = i;
    end

    subcl = [subcl this_subcl];
    
end


return

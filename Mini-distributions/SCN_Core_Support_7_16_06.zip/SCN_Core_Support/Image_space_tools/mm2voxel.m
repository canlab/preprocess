function XYZout = mm2voxel(XYZ,VOL,varargin)
% function XYZout = mm2voxel(XYZ,VOL,[opt] suppress unique)
%
% VOL must contain M or mat field, which is mat file matrix in SPM
% XYZ can be either 3 rows or 3 columns
% by transforming to x y z in ROWS, coords in COLUMNS
% so if you have 3 coordinates, you'd better put the 3 coords
% in different COLS, with ROWS coding x, y, z!
% 
% If a 3rd argument is entered, enter either:
%   1  does not choose unique voxels; allows repeats
%   2  fast unique voxel sort, which RE-ORDERS the voxels
% 
% If unique (no argument)...
% The old version changed the order of voxels in the index,
% but this preserves it.
%
% Tor Wager, 1/14/02, last edit 7/28/02
%
% Refactored to be much, much faster. Instead of calculating
% voxel-by-voxel, it now uses matrix division to compute all voxels at
% once.
%
% Matthew Davidson, 6/1/06
%
% Tor Wager added a line to use .mat instead of .M if missing, 6/30/06

if ~isfield(VOL,'M') && isfield(VOL,'mat'), VOL.M = VOL.mat; end

if isempty(XYZ), XYZout = [];, return, end
    
% transpose XYZ so that x y z are in rows and coords are in cols
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
if size(XYZ,1) ~= 3
	XYZ = XYZ';
end

% This loop is too slow... perform it all at once with division
% for i = 1:size(XYZ,2), 
% 	XYZo(i,:) = tal2vox(XYZ(:,i),VOL);, 
% end
XYZo = [XYZ; ones(1,size(XYZ,2))];
XYZo = (VOL.M\XYZo)';
XYZo(:,4) = [];
    
% make sure voxel coords are integers, and there are no repetitions
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
% XYZout = unique(round(XYZout),'rows');

% long method: do not sort (unique.m sorts rows)
XYZo = round(XYZo);

if nargin < 3
    
    i = 1;
    while i < size(XYZo,1)
        whch = find(ismember(XYZo,XYZo(i,:),'rows'));
        if length(whch > 1)
            whch = whch(2:end);     % first instance only
            XYZo(whch,:) = [];
        end
        i = i+1;
    end

else
    
    if varargin{1} == 2
        XYZo = unique(round(XYZo),'rows');
    elseif varargin{1} == 1
        % do nothing
    else
        warning('mm2voxel: Enter 1 or 2 for optional argument!')
    end
end

XYZout = XYZo;

XYZout(round(XYZout) == 0) = 1;


return

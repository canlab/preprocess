function x = scale(x,varargin)
% x = scale(x,[just center])
%
% centers and scales column vectors
% to mean 0 and st. deviation 1

x = x - repmat(mean(x),size(x,1),1);

if length(varargin) == 0
    x = x ./ repmat(std(x),size(x,1),1);
end

return
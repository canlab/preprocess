function [shiftedy] = shift_signal(y,by)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% function [shiftedy] = shift_signal(y,by)
%
% Shifts signal contained in y back 'by' steps
% 
% Note the variable by should be positive.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


N = length(y);

sn = sign(by);
by = abs(by);
dec = mod(by,1);
in = by - dec;

yy = y(in+1:end); % Shifts integer number of steps


% Shifts decimal number of steps
if (dec ~= 0),

    M = length(yy);
    [a,num] = max((((1:100)*1/dec) - round((1:100)*1/dec) == 0));
    den = round(num/dec);
    iyy = interp(yy,den);
    t = den*(1:M) + num - den + 1;

    shiftedy = iyy(t);

else,

    shiftedy = yy;
end;


return;
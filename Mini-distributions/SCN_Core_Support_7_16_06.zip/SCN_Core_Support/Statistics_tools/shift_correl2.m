function [sval,myc,bestval,bestcor,xout,yout] = shift_correl2(x,y,varargin)
% function [sval,myc,bestval,bestcor,xout,yout] = shift_correl(x,y,[shiftbymax],[by],[robustflag],[betaflag],[doplot])
%
% shifts x backwards and forwards by shiftbymax elements (default 12)
% in each direction, computing the correlation 
% between x and y at each shift value
%
% Thus, negative values mean x happens AFTER y
% Positive values means y happens later
%
% truncates the tails of x and y where necessary
% to ensure they're the same length.
%
% INPUTS:
% x,y           two vectors to correlate
% shiftbymax    max elements to shift
% by            size of incremental shifts
% robustflag    robust regression, IRLS (default 0)
% betaflag      return betas rather than corr coeffs (default 0)
%
% by tor wager
%
% example:
%
% % first extract data for a subject into clusters:
% clusters = roi_probe(spm_get(Inf),'snpm0002_varsm_cov_clusters.mat');
%
% % OR
%
% clusters = mask2clusters('SnPMt_filtered.img',spm_get(Inf));
%
% % Then do the shifting:
%
% for i = 1:length(clusters),
% 	[sval,myc]=shift_correl(xX.X(:,1),clusters(i).timeseries);
%	title(['CLuster' num2str(i)]); 
%	disp(['Cluster ' num2str(i) ' estimate shift by ' num2str(1.5*sval(myc==max(myc)))]),end
% end
%
% To add smoothing to the corr function: 
%xc = [1 .5 .3 .1];
%xc = xc ./ sum(xc);
%V = getV('make',xc,length(myc));
%myc2 = V * myc';

doplot = 0;

robustflag = 0;
betaflag = 0;

sval = []; myc = [];
sby = 12;
if length(varargin) > 0, sby = varargin{1};,end
if length(varargin) > 1, by = varargin{2};,end

if length(varargin) > 2, robustflag = varargin{3};,end
if length(varargin) > 3, betaflag = varargin{4};,end
if length(varargin) > 4, doplot = varargin{5};,end

wh = find(isnan(x) | isnan(y)); x(wh) = []; y(wh) = [];

% add 1 to shiftby, so that it shifts +/- the value you put in
sby = sby + 1;

% shifting backwards, including 0  (sby of 1)

for i = sby:-by:1

% 	tmpx = x(i:end);
% 	tmpy = y(1:length(tmpx));

	tmpx = shift_signal(x,i);
	tmpy = y(1:length(tmpx));

	sval(end+1) = -i + 1;
    
    tmpx2 = tmpx(sby-i+1:end-sby+i);    % avoid using ends
    tmpy2 = tmpy(sby-i+1:end-sby+i);
    
	if robustflag & betaflag
         tmp = robustfit(tmpx2,tmpy2);
         myc(end+1) = tmp(2);
         
    elseif robustflag
        [tmp,stats] =  robustfit(tmpx2,tmpy2,'bisquare');
        r = weighted_corrcoef([tmpx2 tmpy2],stats.w);   % adjust corr coef for 
        myc(end+1) = r(1,2);
        
    elseif betaflag
         tmp = glmfit(tmpx2,tmpy2);
         myc(end+1) = tmp(2);
    else
        tmp = corrcoef(tmpx2,tmpy2);
        myc(end+1) = tmp(1,2);
    end
    
	

end


% shifting forwards 

for i = 2:by:sby

	tmpy = shift_signal(y,i);
	tmpx = x(1:length(tmpy));

	sval(end+1) = i - 1;
	%tmp = corrcoef(tmpx(sby-i+1:end-sby+i),tmpy(sby-i+1:end-sby+i));
	%myc(end+1) = tmp(1,2);

    tmpx2 = tmpx(sby-i+1:end-sby+i);
    tmpy2 = tmpy(sby-i+1:end-sby+i);
    
    if all(tmpx2-mean(tmpx2) < eps) | all(tmpy2-mean(tmpy2) < eps)
        % no variance in x or y
        myc(end+1) = NaN;
        %disp('Warning! No variance in either x or y (shifted.)')
        
    elseif robustflag & betaflag
         tmp = robustfit(tmpx2,tmpy2);
         myc(end+1) = tmp(2);
         
    elseif robustflag
        [tmp,stats] =  robustfit(tmpx2,tmpy2,'bisquare');
        r = weighted_corrcoef([tmpx2 tmpy2],stats.w);   % adjust corr coef for 
        myc(end+1) = r(1,2);
        
    elseif betaflag
         tmp = glmfit(tmpx2,tmpy2);
         myc(end+1) = tmp(2);
    else
        tmp = corrcoef(tmpx2,tmpy2);
        myc(end+1) = tmp(1,2);
    end
    
end

if max(abs(myc)) - max(myc) <= eps
    bestval = sval(myc == max(myc));
    bestcor = max(myc);
else
    bestval = sval(myc == min(myc));
    bestcor = min(myc);
end

i = abs(bestval) + 1;
    if bestval < 0
        tmpx = x(i:end);
        tmpy = y(1:length(tmpx));
    elseif bestval > 0
        tmpy = y(i:end);
        tmpx = x(1:length(tmpy));
    else
        tmpy = y; tmpx = x;
    end
    
    xout = tmpx(sby-i+1:end-sby+i);
    yout = tmpy(sby-i+1:end-sby+i); 

    
    
if doplot
    figure('Color','w'); subplot(1,2,1)
    plot(sval,myc,'ko-','LineWidth',2); hold on; plot(bestval,bestcor,'rx','MarkerSize',16,'LineWidth',2)
    xlabel('Shift (in elements)'), ylabel('Correlation')
    subplot(1,2,2)
    
    plot_correlation_samefig(xout,yout,[],'k.',0,robustflag);
    xlabel('X'); ylabel('Y');
end
    

return

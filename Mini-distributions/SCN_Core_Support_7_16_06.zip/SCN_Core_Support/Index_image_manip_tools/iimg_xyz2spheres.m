function indx = iimg_xyz2spheres(xyz,xyzlist,r)
% indx = iimg_xyz2spheres(xyz,xyzlist,r)
%
%
% xyzlist is a list of voxel coords of all in-mask voxels
% xyz is a list of voxels to be convolved with spheres
% r is sphere radius (voxels)

n = size(xyzlist,1);
indx = zeros(n,1);

if isempty(xyz), return, end

whorig = (1:n)';        % original voxel index


% eliminate xyz points that are not even close (outside box)
cmax = max(xyz,[],1);
cmin = min(xyz,[],1);
d = [xyzlist - repmat(cmax,n,1)    repmat(cmin,n,1) - xyzlist];   
wh = any(d > r,2);

xyzlist(wh,:) = [];
whorig(wh) = [];

r2 = r.^2;

% for each voxel, find xyzlist coords within r
% add ones to indx
for i = 1:size(xyz,1)
    
    myx = xyz(i,:);
    xyz_candidates = xyzlist;
    wh_candidates = whorig;
    
    % find list xyz in box around coord
    wh = abs(xyz_candidates(:,1) - myx(1)) > r;
    xyz_candidates(wh,:) = []; wh_candidates(wh) = [];

    wh = abs(xyz_candidates(:,2) - myx(2)) > r;
    xyz_candidates(wh,:) = []; wh_candidates(wh) = [];
    
    wh = abs(xyz_candidates(:,3) - myx(3)) > r;
    xyz_candidates(wh,:) = []; wh_candidates(wh) = [];
    
    n = size(xyz_candidates,1);
    d = sum(   ( repmat(myx,n,1) - xyz_candidates ).^2 ,2   );
    
    wh = wh_candidates( d <= r2 );

    indx(wh) = 1;
    
end




return



% [volInfo, dat] = iimg_read_img(inputimgs, extended_output_flag);
%
% Example:
% imname = 'rob_tmap_0001_filt_t_3-05_k5_pos.img';
% volInfo = iimg_get_inmask(imname);
%
% Extended output flag:
% 1 Also return xyz list and list of which voxels nonzero & non-nan in mask
% 2 Also return clusters from spm_clusters

function [volInfo, dat] = iimg_read_img(inputimgs, extended_output_flag)

    % --------------------------------------
    % * Set up arguments
    % --------------------------------------
    if ~exist('inputimgs', 'var') || isempty(inputimgs)
        inputimgs = spm_get(Inf);
    end
    if ~exist('extended_output_flag', 'var') || isempty(extended_output_flag)
        extended_output_flag = 0;
    end

    imgtype = get_img_type(inputimgs);

    volInfo = [];
    num_imgs = size(inputimgs,1);

    switch imgtype
        case 'name'
            % --------------------------------------
            % * String matrix of filenames
            % --------------------------------------

            %% load first image
            [volInfo, dat] = iimg_read_from_file(inputimgs(1,:),extended_output_flag);

            if(num_imgs > 1)
                %% load other images; check to make sure they're in same dims as first
                dat = [dat zeros(volInfo.nvox, num_imgs-1)];

                for i = 2:num_imgs
                    indx = iimg_read_from_file(inputimgs(i,:), 0);

                    if length(indx) ~= volInfo.nvox, error('Image dims do not match.'); end

                    dat(:,i) = indx;
                end
            end

        case '3dvols'
            % --------------------------------------
            % * 4-D matrix of 3-D image data volumes
            % --------------------------------------

            [x,y,z,n] = size(inputimgs);
            nvox = prod(x,y,z);
            dat = zeros(nvox,n);

            for i = 1:num_imgs
                tmp = inputimgs(:,:,:,i);
                dat(:,i) = tmp(:);
            end

            dat(isnan(dat)) = 0;

        case 'indx'
            % --------------------------------------
            % * Already in index -- target format
            % --------------------------------------
            % it's an index vector
            % do nothing
            dat = inputimgs;
    end

end





function imgtype = get_img_type(inputimgs)
    if ischar(inputimgs)
        imgtype = 'name';

        return
    end

    [x,y,z,n] = size(inputimgs);

    if z > 1
        % 3-D image(s)
        imgtype = '3dvols';
    elseif x > 1
        % voxels x images 2-D index matrix
        imgtype = 'indx';
    else
        error('I don''t recognize the data format of inputimgs.');
    end
end




function [volInfo, dat] = iimg_read_from_file(imname, extended_output_flag)
    % make sure it ex ists
    if ~exist(imname, 'file')
        imname = which(imname); % try to find on path
        if ~exist(imname, 'file')
            disp(imname); error('Image does not exist or cannot be found on path!');
        end
    end

    volInfo = spm_vol(imname);
    volInfo.nvox = prod(volInfo.dim(1:3));

    dat = spm_read_vols(volInfo);
    dat = dat(:);

    volInfo.image_indx = abs(dat(:)) > 0;            % locate all voxels in-mask

    if extended_output_flag
        volInfo.wh_inmask = find(volInfo.image_indx);    % indices of all voxels in mask

        volInfo.n_inmask = size(volInfo.wh_inmask,1);

        [i,j,k] = ind2sub(volInfo.dim(1:3), volInfo.wh_inmask);
        volInfo.xyzlist = [i j k];

        if extended_output_flag > 1
            if volInfo.n_inmask < 50000
                volInfo.cluster = spm_clusters(volInfo.xyzlist')';
            else
                volInfo.cluster = ones(volInfo.n_inmask,1);
            end
        end
    end

    dat(isnan(dat)) = 0;
end








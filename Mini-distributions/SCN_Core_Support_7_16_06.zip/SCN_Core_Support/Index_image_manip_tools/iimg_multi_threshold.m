function [cl,dat] = iimg_multi_threshold(inname,varargin)
% [cl,dat] = iimg_multi_threshold(inname,varargin)
%
% Multi-threshold application and orthview display of blobs
%
% inname: Either the name of an image file or a data vector
% if data, enter volInfo structure separately as below.
%
% Command strings:
% 'prune' : consider only contiguous blobs for which at least 1 voxel meets
% the most stringent threshold
% 'pruneseed' : followed by a vectorized thresholded activation image
%       Only those blobs overlapping with at least one 'seed' data voxel
%       are saved
% 'add' : add new blobs to existing orthviews
% 'p' : if image is a p-value image (and thresholds are p-values)
%
% 'thresh' : followed by a vector of n thresholds, most to least stringent
% 'size' : followed by a vector of size thresholds
% 'volInfo': followed by volInfo struct; needed if inname is data rather
% than filenames
% 'overlay' : followed by overlay image (anatomical) filename
%
% Now: raw image threshold only; can be easily expanded to specify t,
% p-value threshold types
% Needs (development): Legend, nice handling of colors, input
% colors, color maps specified with command words (like 'red')
%
% tor wager, July 1, 2006
%
% Examples:
% inname = 'Activation_proportion.img';
% [cl,dat] = iimg_multi_threshold(inname,'prune','thresh',[.1 .5 .3],'size',[1 5 10]);
%
% cl2 = iimg_multi_threshold(Pimg(1,:),'thresh',[.001 .01 .05],'size',[3 5 10],'p');
% cl2 = iimg_multi_threshold(Pimg(1,:),'thresh',[.001 .01 .05],'size',[3 3 3],'p','prune');
%
% from act + corr results (see robust_results_act_plus_corr)
% First prepare 'seed' regions that overlap with correlated regions, then
% use multi_threshold to see full extent of clusters
% [dattype,seeddat] = iimg_check_indx(res.act.overlapdat,res.volInfo,'full');
% [cl,dat] = iimg_multi_threshold('rob_p_0001.img','p','thresh',[.001 .01
% .05],'size',[1 1 1],'pruneseed',seeddat)
%
% Display an F-map from robust regression on a customized mean anatomical,
% with pruning.
% cl = iimg_multi_threshold('rob_pmap_full.img','thresh',[.001 .01 .05],'size',[1 1 1],'p','prune','overlay',EXPT.overlay);

% --------------------------------------
% Setup and defaults
% --------------------------------------

overlay = which('scalped_single_subj_T1.img');  % default overlay
thresh = [.10 .05 .04];
szthresh = [1 10 10];
colors = [1 1 0; 1 .5 0; 1 .3 .3; 0 1 0; 0 0 1];

add2existing = 0;
dopruneclusters = 0;
ispimg = 0;

n = length(thresh);

for i = 1:length(varargin)
    if isstr(varargin{i})
        switch varargin{i}
            % reserved keywords
            case 'prune', dopruneclusters = 1;
            case 'add', add2existing = 1;
            case 'p', ispimg = 1;

                % functional commands
            case 'pruneseed', dopruneclusters = 1; pruneseed = varargin{i+1};
            case 'thresh', thresh = varargin{i+1};
            case 'size', szthresh = varargin{i+1};
            case 'volInfo', volInfo = varargin{i+1};
            case 'overlay', overlay = varargin{i+1};
                
            otherwise, warning(['Unknown input string option:' varargin{i}]);
        end
    end
end

% --------------------------------------
% Threshold images
% --------------------------------------
if ispimg
    current_thresh = [0 thresh(1)];
else current_thresh = [thresh(1) Inf];
end

if exist('volInfo','var')
    % use input volInfo if entered; this is so you can input an indexed image
    % instead of a filename and get extended output (cluster sizes)
    dat = iimg_threshold(inname,'thr',current_thresh,'k',szthresh(1),'volInfo',volInfo);
else
    % This option if inputs are filenames
    [dat,volInfo] = iimg_threshold(inname,'thr',current_thresh,'k',szthresh(1));
end

dat = [dat zeros(size(dat,1),length(thresh)-1)];

if exist('pruneseed','var')
    % save only blobs that show some activation in seed input image
    % --------------------------------------
    dat(:,1) = iimg_cluster_prune(dat(:,1),pruneseed,volInfo);
end
            
for i = 2:n

    if ispimg
        current_thresh = [0 thresh(i)];
    else current_thresh = [thresh(i) Inf];
    end

    if thresh(i) >= 0
        dat(:,i) = iimg_threshold(inname,'thr',current_thresh,'k',szthresh(i),'volInfo',volInfo);
    else
        % negative threshold; invalid for p-maps
        dat(:,i) = iimg_threshold(inname,'thr',[-Inf thresh(i)],'k',szthresh(i),'volInfo',volInfo);
    end

    if dopruneclusters
        % --------------------------------------
        % save only blobs that show some activation at highest threshold or
        % in seed input image
        % --------------------------------------
        if exist('pruneseed','var')
            dat(:,i) = iimg_cluster_prune(dat(:,i),pruneseed,volInfo);
        else
            dat(:,i) = iimg_cluster_prune(dat(:,i),dat(:,1),volInfo);
        end
    end
end
% --------------------------------------
% Report significant voxels
% --------------------------------------

% Get rid of voxels that appear in earlier ("higher") maps
mysum = cumsum(dat,2);
mysum(:,end) = [];
mysum = [zeros(size(mysum,1),1) mysum];
mysum = mysum > 0;
dat(mysum) = 0;

% --------------------------------------
% Report significant voxels
% --------------------------------------
sigvox = sum(dat>0);

% make clusters
cl = cell(1,n);
for i = 1:n

    %voldata = iimg_reconstruct_3dvol(dat(:,i),volInfo);
    %cl{i} = mask2clusters(voldata,volInfo.mat);

    cl{i} = iimg_indx2clusters(dat(:,i),volInfo);

end


% --------------------------------------
% define colors
% --------------------------------------
%colors = [linspace(1,0,3)' linspace(1,.3,3)' linspace(0,.3,3)'];


% --------------------------------------
% image clusters on brain (orthviews)
% --------------------------------------
for i = 1:n
    if i == 1 && ~add2existing
        cluster_orthviews(cl{i},{colors(i,:)},'overlay',overlay);
    else
        cluster_orthviews(cl{i},{colors(i,:)},'add','overlay',overlay);
    end

    % repeat to intensify color
    %cluster_orthviews(cl{i},{colors(i,:)},'add');
end

return
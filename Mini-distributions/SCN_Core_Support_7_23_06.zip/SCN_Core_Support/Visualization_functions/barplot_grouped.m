function han = barplot_grouped(dat,X,xnames,seriesnames,varargin);
% han = barplot_grouped(dat,X,xnames,seriesnames,[withinerror]);
%
% dat = n x 4 data matrix (2 x 2 grouping only for now, but easy to expand
% later)
% X = covariates, no intercept; will be centered by this function
% xnames = x-axis labels
% seriesnames = series labels
% 
% First two bars are group, and last two bars are group
% 
% Optional input: within-error flag.  1 = errors based on subject x
% condition interaction

if length(varargin) > 0, dowithin = varargin{1};, else, dowithin = 0;, end


X = scale(X,1); X = [ones(size(X,1),1) X];    % design matrix
b = pinv(X) * dat;  % b(1,:) are means, removing centered covariates
resid = dat - X*b; sigma = std(resid);

Xerr = sqrt(diag(inv(X'*X)));
sterr = Xerr * sigma; % rows are predictors, cols are data columns

m = b(1,:); se = sterr(1,:);    % for intercept; other rows are for covariates

if dowithin, 
    se = std(resid(:)) ./ sqrt(size(X,1));, 
    se = repmat(se,1,4);
end

%tor_fig;
m = reshape(m,2,2)';    % rows are groups; plot bars in same order as original means
han = bar(m,'grouped');
set(han(1),'FaceColor',[.2 .2 .2]);
set(han(2),'FaceColor',[.8 .8 .8]);
set(gca,'XTick',1:2,'XTickLabel',xnames);
legend(seriesnames);

tor_bar_steplot(b(1,:),se,{'k'},.35,.5,.2);

% set y-axis limits
mx = max(b(1,:)+se); mi = min(b(1,:)-se);
sc = .05 * (mx-mi);
yl = [mi-sc mx+sc];
set(gca,'YLim',yl);


return

function enlarge_axes(fh)
% function enlarge_axes(figure handle)

figure(fh)

h = get(gcf,'Children');
for i = 1:length(h)
    %axes(h(i))
    pp = get(h(i),'Position');
    set(h(i),'Position',[pp(1) pp(2) pp(3)*1.35 pp(4)*1.35])
   
    % change axis color and text
    %set(h(i),'Color','w')
    %hh = get(h(i),'Children');
    %for j = 1:length(hh)
    %    try
    %       get(hh(j),'FontSize');
    %       set(hh(j),'Color','k')
    %    catch
    %    end
    %end
   
end

return

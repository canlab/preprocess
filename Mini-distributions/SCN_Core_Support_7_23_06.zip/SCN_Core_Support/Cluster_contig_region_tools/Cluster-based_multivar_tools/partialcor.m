function [x,y,r,p,se,meany,stats] = partialcor(X,y,i,doprint,dorobust)
% function [x,y,r,p,se,meany,stats] = partialcor(X,y,i,[doprint],[dorobust])
%
% partial correlation between column i of X and y
% X is n x k matrix of predictors (you can include an intercept; will be added if missing)
% y is n x 1 data vector
%
% x, y are adjusted predictor and data
% r, p are Pearson's correlation and p-value
% ***** Default option: use robust IRLS. ******
%
% Warning: p-values are not adjusted for use of degrees of freedom in
% partial correlation computation w/o robust option!  OK for robust
%
% Modified by Tor Wager, July 2006
% :mean of y retained in case we're interested in the intercept
% :if X of interest is intercept, returns robust mean, controlling for
% other columns of X
% if robust outputs are requested, y is created from robust stats

if nargin < 5, dorobust = 1; end
if nargin < 4, doprint = 0; end

fullX = X;

% add intercept if not already in model
no_intercept = ~any(all(diff(fullX) < eps));
if no_intercept, fullX(:,end+1) = 1; end

wh_intercept = find(all(diff(fullX) < eps));

% center predictors (except intercept)
fullX = scale(fullX,1);
fullX(:,wh_intercept) = 1;

redX = fullX;
redX(:,i) = [];     % reduced model without param(s) of interest

x = X(:,i);

if ~dorobust
    % OLS
    rstr = 'OLS ';
    [b,dev,stats] = glmfit(fullX,y,'normal','constant','off');
    stats.w = ones(size(y,1),1);
    stats.b = b;
    
    [br,dev,statsr] = glmfit(redX,y,'normal','constant','off');
    statsr.w = ones(size(y,1),1);

else
    % robust IRLS
    rstr = 'Robust ';

    [b,stats]=robustfit(fullX,y,'bisquare',[],'off');
    stats.b = b;
    [br,statsr]=robustfit(redX,y,'bisquare',[],'off');

end

[r,r2] = partial_r(stats,statsr,y,wh_intercept,sign(stats.b(i)));

% this is the mean estimate because predictors are centered
meany = stats.b(wh_intercept);

y = stats.resid + x * b(i);     % adjusted y
t = stats.t(i);
p = stats.p(i);
se = stats.se(i);


if all(x - mean(x) < eps)
    % x is an intercept; weighted mean
    %r = stats.w' * y ./ sum(stats.w);
    pstr = 'intercept sqrt(Rsquare)';
else
    % weighted correlation
    %r = weighted_corrcoef([x y],stats.w);
    %r = r(1,2);
    pstr = 'partial r';
end

if doprint
    fprintf(1,'%s %s: %3.2f, b = %3.2f, se = %3.2f, t(%3.0f) = %3.2f, p = %3.4f\n',rstr,pstr,r,b(i),se,stats.dfe,stats.t(i),p);
end



return


function [r_reduced,r2_reduced] = partial_r(stats,statsr,y,wh_intercept,mysign)

y = y - stats.b(wh_intercept);  %mean(y);    % deviations; only OK of covariates are centered!

W = diag(stats.w);
W = W' * W;         % squared weights

SSt = y' * W * y;   % total variability in data

e = stats.resid;
er = statsr.resid;

SSf = e' * W * e;   % full model sum sq. error

SSr = er' * W * er;  % reduced model sse

r2_reduced = (SSr - SSf) ./ SSt;    % R2 accounted for by predictor of interest

r_reduced = sqrt(r2_reduced);       % partial correlation (absolute value)

r_reduced = r_reduced * mysign;

%r2_full = (SSt - SSf) ./ SSt;       % full model r-square

%r_full = sqrt(r2_full);              % multiple R for full regression

return



% if ~dorobust
%     % X is no interest; x is of interest
%     X(:,i) = [];
%
%     W = X * pinv(X);
%
%     x = x - W * x;
%
%     % leave mean of y in in case we're interested in the intercept
%     y = y - W * y + mean(y);



function outcl = merge_clusters(c2m,subcl)
%subclusters = merge_clusters(clusters_to_match,subclusters_to_change)

if isempty(subcl), outcl = c2m;, return, end

if ~iscell(subcl), s{1} = subcl; subcl = s;,end
outcl = c2m;

for i = 1:length(subcl)
    
    for j = 1:length(subcl{i})
        
            % make all field names match.

            newcl{i}(j) = c2m(1);
            N = fieldnames(newcl{i}(j));
            for NN = 1:length(N)
                eval(['newcl{i}(j).' N{NN} ' = [];'])
            end
            
            %N = fieldnames(clusters(i));
            for NN = 1:length(N)
                str = ['newcl{i}(j).' N{NN} ' = subcl{i}(j).' N{NN} ';'];
                try
                    eval(str)
                catch
                    disp(['Making ' N{NN}])
                    str = ['newcl{i}(j).' N{NN} ' = [];'];
                    eval(str)
                end
            end
            
    end
    
    outcl = ([outcl,newcl{i}]);
    
end
    
    return
    
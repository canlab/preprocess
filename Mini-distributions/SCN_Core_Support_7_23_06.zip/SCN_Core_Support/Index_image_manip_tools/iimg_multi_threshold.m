function [cl,dat] = iimg_multi_threshold(inname,varargin)
% [cl,dat] = iimg_multi_threshold(inname,varargin)
%
% Multi-threshold application and orthview display of blobs
%
% inname: Either the name of an image file or a data vector
% if data, enter volInfo structure separately as below.
%
% Command strings:
% 'prune' : consider only contiguous blobs for which at least 1 voxel meets
% the most stringent threshold
% 'pruneseed' : followed by a vectorized thresholded activation image
%       Only those blobs overlapping with at least one 'seed' data voxel
%       are saved
%       Also: the first color (highest threshold) in the output images is assigned to the seed
% 'add' : add new blobs to existing orthviews
% 'p' : if image is a p-value image (and thresholds are p-values)
%
% 'thresh' : followed by a vector of n thresholds, most to least stringent
% 'size' : followed by a vector of size thresholds
% 'volInfo': followed by volInfo struct; needed if inname is data rather
% than filenames
% 'overlay' : followed by overlay image (anatomical) filename
%
% Now: raw image threshold only; can be easily expanded to specify t,
% p-value threshold types
% Needs (development): Legend, nice handling of colors, input
% colors, color maps specified with command words (like 'red')
%
% tor wager, July 1, 2006
%
% Examples:
% inname = 'Activation_proportion.img';
% [cl,dat] = iimg_multi_threshold(inname,'prune','thresh',[.1 .5 .3],'size',[1 5 10]);
%
% cl2 = iimg_multi_threshold(Pimg(1,:),'thresh',[.001 .01 .05],'size',[3 5 10],'p');
% cl2 = iimg_multi_threshold(Pimg(1,:),'thresh',[.001 .01 .05],'size',[3 3 3],'p','prune');
%
% from act + corr results (see robust_results_act_plus_corr)
% First prepare 'seed' regions that overlap with correlated regions, then
% use multi_threshold to see full extent of clusters
% [dattype,seeddat] = iimg_check_indx(res.act.overlapdat,res.volInfo,'full');
% [cl,dat] = iimg_multi_threshold('rob_p_0001.img','p','thresh',[.001 .01
% .05],'size',[1 1 1],'pruneseed',seeddat)
%
% Display an F-map from robust regression on a customized mean anatomical,
% with pruning.
% cl = iimg_multi_threshold('rob_pmap_full.img','thresh',[.001 .01 .05],'size',[1 1 1],'p','prune','overlay',EXPT.overlay);
%
% Display regions at 3 thresholds with an input data 'seed' vector
% [cl,dat] = iimg_multi_threshold(pvals,'p','thresh',[.001 .01 .05],'size',[1 1 1],'pruneseed',p_sig','volInfo',R.volInfo);

% --------------------------------------
% Setup and defaults
% --------------------------------------

overlay = which('scalped_single_subj_T1.img');  % default overlay
thresh = [.10 .05 .04];
szthresh = [1 10 10];
colors = [1 1 0; 1 .5 0; 1 .3 .3; 0 1 0; 0 0 1];

add2existing = 0;
dopruneclusters = 0;
ispimg = 0;

for i = 1:length(varargin)
    if isstr(varargin{i})
        switch varargin{i}
            % reserved keywords
            case 'prune', dopruneclusters = 1;
            case 'add', add2existing = 1;
            case 'p', ispimg = 1;

                % functional commands
            case 'pruneseed', dopruneclusters = 1; pruneseed = varargin{i+1};
            case 'thresh', thresh = varargin{i+1};
            case 'size', szthresh = varargin{i+1};
            case 'volInfo', volInfo = varargin{i+1};
            case 'overlay', overlay = varargin{i+1};
                
            otherwise, warning(['Unknown input string option:' varargin{i}]);
        end
    end
end

n = length(thresh);




% --------------------------------------
% Threshold images
% --------------------------------------
if ispimg
    current_thresh = [0 thresh(1)];
    disp('Warning: p-values in cl.Z will not give valid spm_max subclusters.')
    disp('log(1/p) saved in output cl.Z field.');
    
    lowest_thresh = [0 thresh(end)];    % for pruning based on extent
else current_thresh = [thresh(1) Inf];
    lowest_thresh = [thresh(end) Inf];
end

if exist('volInfo','var')
    % use input volInfo if entered; this is so you can input an indexed image
    % instead of a filename and get extended output (cluster sizes)
    dat = iimg_threshold(inname,'thr',current_thresh,'k',szthresh(1),'volInfo',volInfo);
else
    % This option if inputs are filenames
    [dat,volInfo] = iimg_threshold(inname,'thr',current_thresh,'k',szthresh(1));
end

if dopruneclusters
    if exist('pruneseed','var')
        % find vox at Lowest threshold that are contiguous with seed
        % this defines 'extent'.  Then, later, get any voxels that are
        % contiguous with the voxels in the extent region at higher thresholds.
        % this way, voxels at an intermediate thresh that are contiguous with
        % the extent region but not with the actual seed are included.
        % --------------------------------------

        dat_extent = get_extent_regions(inname,pruneseed,lowest_thresh,szthresh(end),volInfo);

    else
        % use highest threshold as seed
        dat_extent = get_extent_regions(inname,dat(:,1),lowest_thresh,szthresh(end),volInfo);
    end
end


dat = [dat zeros(size(dat,1),length(thresh)-1)];

if exist('pruneseed','var')
    % save only blobs that show some activation in extent region (lowest thresh) around seed input image
    % --------------------------------------
    %dat(:,1) = iimg_cluster_prune(dat(:,1),pruneseed,volInfo);
    dat(:,1) = iimg_cluster_prune(dat(:,1),dat_extent,volInfo);
end
            
for i = 2:n

    if ispimg
        current_thresh = [0 thresh(i)];
    else current_thresh = [thresh(i) Inf];
    end

    if thresh(i) >= 0
        dat(:,i) = iimg_threshold(inname,'thr',current_thresh,'k',szthresh(i),'volInfo',volInfo);
    else
        % negative threshold; invalid for p-maps
        dat(:,i) = iimg_threshold(inname,'thr',[-Inf thresh(i)],'k',szthresh(i),'volInfo',volInfo);
    end

    if dopruneclusters
        % --------------------------------------
        % save only blobs that show some activation at highest threshold or
        % in seed input image
        % --------------------------------------
        if exist('pruneseed','var')
            %dat(:,i) = iimg_cluster_prune(dat(:,i),pruneseed,volInfo);
            dat(:,i) = iimg_cluster_prune(dat(:,i),dat_extent,volInfo);
        else
            %dat(:,i) = iimg_cluster_prune(dat(:,i),dat(:,1),volInfo);
            dat(:,i) = iimg_cluster_prune(dat(:,i),dat_extent,volInfo);
        end
    end
end

% --------------------------------------
% Append 'seed', if entered, as "highest threshold" image vector
% So it gets shown and assigned the first color
% --------------------------------------
if exist('pruneseed','var')
    dat = [pruneseed dat];
    n = n+1;
end

% --------------------------------------
% Report significant voxels
% --------------------------------------

% Get rid of voxels that appear in earlier ("higher") maps
mysum = cumsum(dat,2);
mysum(:,end) = [];
mysum = [zeros(size(mysum,1),1) mysum];
mysum = mysum > 0;
dat(mysum) = 0;

% --------------------------------------
% Report significant voxels
% --------------------------------------
sigvox = sum(dat>0);

% make clusters
cl = cell(1,n);
for i = 1:n

    %voldata = iimg_reconstruct_3dvol(dat(:,i),volInfo);
    %cl{i} = mask2clusters(voldata,volInfo.mat);

    cl{i} = iimg_indx2clusters(dat(:,i),volInfo);

end


% --------------------------------------
% define colors
% --------------------------------------
%colors = [linspace(1,0,3)' linspace(1,.3,3)' linspace(0,.3,3)'];


% --------------------------------------
% image clusters on brain (orthviews)
% --------------------------------------
for i = 1:n
    if i == 1 && ~add2existing
        cluster_orthviews(cl{i},{colors(i,:)},'overlay',overlay,'solid');
    else
        cluster_orthviews(cl{i},{colors(i,:)},'add','overlay',overlay,'solid');
    end

    if ispimg
        % replace p-values with log(1/p) in Z field.  Higher is thus more
        % sig.  for compatibility with spm_max
        for j = 1:length(cl{i})
            cl{i}(j).Z = log(1./cl{i}(j).Z);
        end
    end
end

return




function dat_extent = get_extent_regions(inname,pruneseed,lowest_thresh,szthresh,volInfo)

if lowest_thresh >= 0
    dat = iimg_threshold(inname,'thr',lowest_thresh,'k',szthresh,'volInfo',volInfo);
else
    % negative threshold; invalid for p-maps
    dat = iimg_threshold(inname,'thr',[-Inf lowest_thresh(1)],'k',szthresh,'volInfo',volInfo);
end

dat_extent = iimg_cluster_prune(dat,pruneseed,volInfo);
return

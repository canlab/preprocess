% voldata = iimg_reconstruct_3dvol(dat,maskInfo,[optional args])
% Reconstruct a 3-D volume from a dat index list
%
%
%
% Optional inputs: if entered, will write .img file to disk
% 'outname', followed by output name
% 'descrip', followed by description for img file

function voldata = iimg_reconstruct_3dvol(dat,maskInfo,varargin)

    % --------------------------------------
    % * Make sure dat matches maskInfo info
    % --------------------------------------
    ndat = length(dat);

    if ~isfield(maskInfo,'nvox')
        error('maskInfo.nvox and other fields not found.  Use iimg_read_image.m to prepare maskInfo.');
    end


    if ndat ~= maskInfo.nvox % if data is in original image vector list; do nothing
        % assume data is only in-mask, and reconstruct

        if ~isfield(maskInfo,'n_inmask') || ~isfield(maskInfo,'nvox')
            error('maskInfo.n_inmask and other fields not found.  Use iimg_read_image.m with extended output flag to prepare maskInfo.');
        end

        if ndat == maskInfo.n_inmask
            dat2 = double(maskInfo.image_indx);
            dat2(maskInfo.wh_inmask) = dat;
            dat = dat2;
        else
            error('volume info in struct does not seem to match number of voxels in index image.');
        end
    end

    % --------------------------------------
    % * Reshape to 3D
    % --------------------------------------

    voldata = reshape(dat, maskInfo.dim(1:3));



    % --------------------------------------
    % Optional output for writing image file to disk:
    % --------------------------------------

    if length(varargin) > 0
        descrip = 'Created by iimg_reconstruct_3dvol';

        for i = 1:length(varargin)
            arg = varargin{i};
            if ischar(arg)
                switch lower(arg)
                    case 'outname', outname = varargin{i+1};
                    case 'descrip', descrip = varargin{i+1};
                end
            end
        end

        maskInfo.fname = make_img_filename(outname);
        maskInfo.descrip = descrip;

        warning off  % empty images return many warnings
        spm_write_vol(maskInfo, voldata);
        warning on
    end
end

function name = make_img_filename(name)
    [d, name] = fileparts(name);
    name = fullfile(d, [name '.img']);
end

function [V,dat] = iimg_read_image(imname,extended_output_flag);
% [V,dat] = iimg_read_image(imname,extended_output_flag);
%
% Example:
% imname = 'rob_tmap_0001_filt_t_3-05_k5_pos.img';
% V = iimg_get_inmask(imname);
%
% clu = spm_clusters(V.xyzlist');
%
% % OLD---DO NOT USE THIS ONE

if nargin == 0
    imname = spm_get(1);
elseif nargin == 1
    extended_output_flag = 0;
end

V = spm_vol(imname);
V.nvox = prod(V.dim(1:3));

dat = spm_read_vols(V);

V.indx = dat(:) > 0;            % locate all voxels in-mask

if extended_output_flag
    V.wh_inmask = find(V.indx);    % indices of all voxels in mask

    [i,j,k] = ind2sub(V.dim(1:3), V.wh_inmask);
    V.xyzlist = [i j k];
    
    V.cluster = spm_clusters(V.xyzlist')';
end


return

    






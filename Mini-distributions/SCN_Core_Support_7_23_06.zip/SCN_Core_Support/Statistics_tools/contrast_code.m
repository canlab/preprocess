function vec = contrast_code(vec)
% vec = contrast_code(vec)
%
% Changes values to 1, -1, or 0 for contrast coding

if ~isempty(vec)
    wh = find(vec > 0);

    vec(wh) = 1;

    wh = find(vec < 0);

    vec(wh) = -1;

end

return


function [name,perc,number,totalnum,str] = Carmack_get_label(XYZ,Labs,xyz)
% [name,perc,number,totalnum,str] = Carmack_get_label(XYZ,Labs,xyz)
% 
% Purpose: Takes a set of voxels XYZ and finds the percentage of voxels in
% each label, Labs.  
%
% Usage: 
% load talairach_info L5 xyz
% [name,perc,number,totalnum,str] = Carmack_get_label(XYZ,L5,xyz);
%
% I/O:
% XYZ is mm coords to find (i.e., in a contiguous cluster), in 3 x n matrix
%   e.g., XYZ = cl(1).XYZmm; from output of talairach_clusters
%
% Labs is text labels to search over
% xyz is all talairach coords, matching Labs
%       xyz should be whole integers for fastest performance!
%       xyz is an n x 3 matrix!
%
% str is a useful summary.
%
% tor wager



% exclude out of range points
maxx = [min(XYZ(1,:)) max(XYZ(1,:))];
maxy = [min(XYZ(2,:)) max(XYZ(2,:))];
maxz = [min(XYZ(3,:)) max(XYZ(3,:))];

wh = find(xyz(:,1) < maxx(1) | xyz(:,1) > maxx(2));
xyz(wh,:) = []; Labs(wh) = [];

wh = find(xyz(:,2) < maxy(1) | xyz(:,2) > maxy(2));
xyz(wh,:) = []; Labs(wh) = [];

wh = find(xyz(:,3) < maxz(1) | xyz(:,3) > maxz(2));
xyz(wh,:) = []; Labs(wh) = [];

if isempty(xyz)
    name = 'NO LABELS.';
    perc = 100; number = 1; totalnum = 0; str = name;
return
end
    

% get labels for each point in set

totalnum = size(XYZ,2);

clear L
for i = 1:size(XYZ,2)
    % exact match
    wh = find(XYZ(1,i) == xyz(:,1) & XYZ(2,i) == xyz(:,2) & XYZ(3,i) == xyz(:,3));

    % approx match
    if isempty(wh)
        d = distance(XYZ(:,i)',xyz);
        wh = find(d == min(d));
    end

    L(i) = Labs(wh(1));
end
    

[a,b,c]=unique(L);
name = a;

for i = 1:length(a)
    perc(i) = round(100*sum(c == i)./size(XYZ,2));
    number(i) = sum(c == i);
end

% sort in descending order
[perc,i] = sort(perc,'descend');
name = name(i);
number = number(i);


% top 1 area + anything over 20%
i = find(perc == max(perc) | perc > 15);
name2 = name(i);
perc2 = perc(i);

str = [];
for i = 1:length(name2)
    if iscell(name2)
        str = [str name2{i} ': ' num2str(perc2(i)) '%, '];
    else
        str = [str name ': ' num2str(perc2(i)) '%, '];
    end
end
       
return
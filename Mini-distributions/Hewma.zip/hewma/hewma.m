% shell to start SCNlab BrainTools

global EXPT
global cl

% for timeseries viewer
global VOL
global f
global f2

        
hewma_gui;

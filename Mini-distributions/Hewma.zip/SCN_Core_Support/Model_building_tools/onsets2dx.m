function [DX,delta] = onsets2dx(onsets,TR,scansperrun)
% function [DX,delta] = onsets2dx(onsets,TR,scansperrun)
%
% onsets should be a cell array whose length is num runs * num conditions,
% e.g., {run 1 ant onsets, run 1 stim onsets, run 2 ant onsets, run 2 stim
% onsets}
%
% E.g.:
% TR = 2;
% scansperrun = [192 196 196 184 190 192];
% [DX,delta] = onsets2dx(onsets,TR,scansperrun)
% EXPT.FIR.model{subjectnumber} = DX;

evtsperrun = length(onsets) ./ length(scansperrun);

delta = {};

for i = 1:length(scansperrun)
    % onsets for this run
    st = (i - 1) .* evtsperrun + 1;
    wh = st:(st + evtsperrun - 1);
    
    % delta for this run
    [x,d] = onsets2delta(onsets(wh),TR,scansperrun(i)*TR - 1);
    
    delta = [delta; d];
end


DX = tor_make_deconv_mtx3(cell2mat(delta),round(44./TR),1,0,1,0,scansperrun);

return

function p = addbrain(varargin)
% handle = addbrain([method],enter 2nd arg to suppress lighting changes)
% quick function to add transparent brain surface to figure
%
% han = addbrain('branstem');
% han = addbrain;
% han =

meth = 'transparent_surface';

if length(varargin) > 0,
    meth = varargin{1};
end

switch meth

    case 'transparent_surface'

        pname = 'surf_single_subj_T1_gray.mat';

        Ps = which(pname); %'c:\tor_scripts\3DheadUtility\surf_single_subj_T1_gray.mat';
        if isempty(Ps), disp(['I need the file: ' pname]); return; end

        %Ps = which('surf_single_subj_grayR.mat');
        %Ps = which('surf_brain_render_T1_preCarmack.mat');
        load(Ps)
        p = patch('Faces',faces,'Vertices',vertices,'FaceColor',[.5 .5 .5], ...
            'EdgeColor','none','SpecularStrength',.2,'FaceAlpha',1,'SpecularExponent',200);

        set(p,'FaceAlpha',.3)

    case 'brainstem'

        pname = 'carmack_thal_bstem.mat';
        Ps = which(pname);

        if isempty(Ps), disp(['I need the file: ' pname]); return; end

        load(Ps);

        p = imageCluster('cluster',cl,'color',[.3 .3 .3],'alpha',.1);
        set(p,'FaceAlpha',.3)
        %load carmack_thal_bstem hy medulla midbrain pons thal

        %p(1) = imageCluster('cluster',thal,'color',[.4 .4 .4],'alpha',.1);
        %p(2) = imageCluster('cluster',midbrain,'color',[.5 .5 .5],'alpha',.1);
        %p(3) = imageCluster('cluster',pons,'color',[.6 .6 .6],'alpha',.1);
        %p(4) = imageCluster('cluster',medulla,'color',[.7 .7 .7],'alpha',.1);


    case 'brainbottom'
        [D,Ds,hdr,p,bestCoords] = tor_3d('whichcuts','z','coords',[0 0 -20],'filename','scalped_single_subj_T1');
        set(p(1),'FaceColor',[.6 .4 .3]); colormap copper;material dull;axis off
        h = findobj('Type','Light'); delete(h); [az,el]=view;lightangle(az,el); lightangle(az-180,el-60);
        set(p,'FaceAlpha',1)
        
    case 'amygdala'
        P = which('Tal_Amy.img');
        [p,outP,FV, cl, myLight] = mask2surface(P,0,[0 0 .5]);
        if findstr(P,'Tal_Amy.img'), str(49:58) = '[.4 .4 .6]'; , end

    case 'thalamus'
        P = which('carmack_thal_bstem.mat'); load(P)
        p = imageCluster('cluster',thal,'color',[0 .8 .3],'alpha',.5);

    case 'hippocampus'
        P = which('Tal_Hip.img');
        [p,outP,FV, cl, myLight] = mask2surface(P,0,[.5 .5 0]);
        if findstr(P,'Tal_Hip.img'), str(49:58) = '[.5 .6 .6]';, end

    case 'midbrain'
        P = which('carmack_thal_bstem.mat');
        load(P)
        p = imageCluster('cluster',midbrain,'color',[.7 .3 0],'alpha',.5);

    case 'caudate'
        %P = which('Tal_Cau.img'); %which('ICBM_caudate.img');   %('Tal_Cau.img'); %
        %[p,outP,FV, cl, myLight] = mask2surface(P,0,[0 0 .5]);
        %if findstr(P,'Tal_Cau.img'), str(49:58) = '[.5 .6 .6]'; delete(p(1)); p = p(2);,eval(str),end
        P = which('carmack_more_clusters.mat'); load(P)
        p = imageCluster('cluster',cau,'color',[.5 .6 .6],'alpha',.5);

    case 'globus pallidus'
        P = which('Tal_Glo.img');
        [p,outP,FV, cl, myLight] = mask2surface(P,0,[.5 .6 .5]);
        if findstr(P,'Tal_Glo.img'), str(49:58) = '[.5 .6 .5]'; , end

    case 'putamen'
        %P = which('Tal_Put.img');
        %[p,outP,FV, cl, myLight] = mask2surface(P,0,[.9 .4 0]);
        %if findstr(P,'Tal_Put.img'), str(49:58) = '[.5 .5 .6]'; , end
        P = which('carmack_more_clusters.mat'); load(P)
        p = imageCluster('cluster',put,'color',[.5 .5 .6],'alpha',.5);
        
    case 'nucleus accumbens'
        P = which('NucAccumb_clusters.mat');
        load(P)
        p(1) = imageCluster('cluster',cl(3),'color',[0 .5 0],'alpha',.5);
        p(2) = imageCluster('cluster',cl(4),'color',[0 .5 0],'alpha',.5); ,

    case 'hypothalamus'
        %P = which('Tal_Put.img');
        %[p,outP,FV, cl, myLight] = mask2surface(P,0,[.9 .4 0]);
        %if findstr(P,'Tal_Put.img'), str(49:58) = '[.5 .5 .6]'; , end
        P = which('carmack_more_clusters.mat'); load(P)
        p = imageCluster('cluster',hy,'color',[1 1 0],'alpha',.5);
        
    
        
    otherwise
        error('Unknown method.');
end








% suppress lighting if 2nd arg, otherwise, do it.

if length(varargin) > 1
    lighting gouraud;camlight right
    axis image; myLight = camlight(0,0);set(myLight,'Tag','myLight');
    set(gcf, 'WindowButtonUpFcn', 'lightFollowView');lightFollowView
end


drawnow
axis vis3d
%view(135,30)


return
function [dmt,clusters,dm,mask,CLU] = density(XYZ,u,varargin)
% function [dmt,clusters,dm,mask,CLU] = density(XYZ,u,[radius_mm],[output_filename],[zscores])
% 
% XYZ is 3-column vector of coordinates
%
% Tor Wager 2/18/02

P = ['brain_avg152T1.img'];     % 2 mm voxels
P = 'scalped_avg152T1_graymatter_smoothed.img';

if length(varargin) > 0, radius_mm = varargin{1}; 
else, radius_mm = 10;
end
disp(['Radius is ' num2str(radius_mm) ' mm.'])

if length(varargin) > 1, fname = varargin{2}; 
else, fname = input('Enter file name for the output image ','s');
end

if length(varargin) > 2,
    zscores = varargin{3};
    if length(zscores) ~= size(XYZ,1), error('Length of z-scores does not match number of points');,end
else
    zscores = 1;
end

if(length(fname) <= 4), error('Enter longer file name or type filename.img'),end
if ~strcmp(fname(end-4:end), '.img'), [d fname] = fileparts(fname);, fname = [fname '.img'], end

mask_file = P;
t1 = clock;

% -----------------------------------------------------
% * load standard brain
% -----------------------------------------------------
P = which(P);
V = spm_vol(P);
mask = zeros(V.dim(1:3));

voxsize = diag(V(1).mat)';
voxsize = voxsize(1:3);
radius = radius_mm ./ mean(voxsize);
sphere_vol = 4 * pi * radius_mm ^ 3 / 3;
XYZ = mm2vox(XYZ,V.mat);

% -----------------------------------------------------
% * make a mask out of XYZ, in space of P
% * deal with repeated coordinates by adding
% -----------------------------------------------------

ind = sub2ind(size(mask),XYZ(:,1),XYZ(:,2),XYZ(:,3));
mask(ind) = zscores;        % = 1 if no zscores entered, otherwise vector

ind = sort(ind);
repeats = ind(find(~diff(ind)));            % index values that are repeated
if length(zscores) > 1
    repeatz = zscores(find(~diff(ind)));            % z=scores of index values that are repeated
else
    repeatz = 1;
end
mask(repeats) = mask(repeats) + repeatz;

% -----------------------------------------------------
% * convert to density mask
% * write density mask before thresholding
% -----------------------------------------------------
dm = mask2density(mask,radius,[],sphere_vol);
%dm2 = mask2density(mask,radius);

%figure; subplot 211; imagesc(mask(:,:,33)); subplot 212; imagesc(dm(:,:,33))
%figure; subplot 211; imagesc(mask(:,:,33)); subplot 212; imagesc(dm(:,:,33).*sphere_vol)

V.fname = ['dens_' fname];
spm_write_vol(V,dm);

figure; hist(dm(dm>0),50)
if ~isempty(u),hold on; plot([u u],get(gca,'YLim'),'r','LineWidth',2),end

% -----------------------------------------------------
% * make and write filtered density mask
% -----------------------------------------------------
dmt = maskImg(dm,u,Inf);   
[d,fname,ext] = fileparts(fname);
V.fname = ['dens_' fname '_filtered' ext];
spm_write_vol(V,dmt);

% -----------------------------------------------------
% * get clusters from density mask for imaging
% -----------------------------------------------------
CLU = mask2struct(V.fname,u,0);
clusters = tor_extract_rois([],CLU,CLU);
eval(['save ' fname '_clusters CLU clusters'])

return



% -----------------------------------------------------
% * sub-functions
% -----------------------------------------------------

function XYZout = mm2vox(XYZ,M)
% converts a list of coordinates
% XYZ should be 3-column vector [x y z]
% calls tal2vox

XYZ = XYZ';
for i = 1:size(XYZ,2), 
	XYZout(i,:) = tal2vox(XYZ(:,i),M); 
end

XYZout = round(XYZout);

return

% -----------------------------------------------------
function vox=tal2vox(tal,M)
% converts from talairach coordinate to voxel coordinate
% based on variables from SPM.M (passed here for 
% faster operation)
% e.g., foo=tal2vox([-30 28 -30], VOL)
% from Russ Poldrack's spm ROI utility 

vox=[0 0 0];
vox(1)=(tal(1)-M(1,4))/M(1,1);
vox(2)=(tal(2)-M(2,4))/M(2,2);
vox(3)=(tal(3)-M(3,4))/M(3,3);

return




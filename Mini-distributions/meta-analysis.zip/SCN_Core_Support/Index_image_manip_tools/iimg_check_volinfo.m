function [anybad,wh] = iimg_check_volinfo(maskInfo,imgInfo)
% anybad = iimg_check_volinfo(maskInfo,imgInfo)
%
% Checks a series of image .mat files and dims against a reference
% (maskInfo)
%
% maskInfo and volInfo are spm-style volume info structures
% see spm_vol.m
% 

n = length(imgInfo);
notok = zeros(1,n);

for i=1:n,
    chk = maskInfo.mat - imgInfo(i).mat; 
    chk = chk(:);
    chk = chk(1:end-1);             % eliminate SPM scale factor
    chk1 = any(chk);
    
    chk2 = any(maskInfo.dim(1:3) - imgInfo(i).dim(1:3));
    
    notok(i) = chk1 | chk2;
end

anybad = any(notok);

if anybad
    wh = find(notok);

    disp('The following images'' mat files differend from the first:')
    disp(num2str(wh));

    disp('First mat:');
    disp(maskInfo.mat);
    
    disp('Bad mats:');
    for i = wh
        disp(imgInfo(i).fname);
        disp(imgInfo(i).mat);
    end
end

return

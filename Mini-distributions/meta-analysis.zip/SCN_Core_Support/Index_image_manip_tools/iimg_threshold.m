function [dat,volInfo,cl] = iimg_threshold(image_names,varargin)
%
% Thresholds images to be at least thr(1) and at most thr(2)
%
% Input types for image names:
% 1) String matrix of filenames
% 2) 4-D array of 3-D data volumes
% 3) voxels x images 2-D index array
%
% Outputs:
% dat, index vector of thresholded data
% volInfo, structure of info about volume
% cl, optional (slower) clusters structure from dat
%
% Command strings:
% 'imgtype', followed by 't','p',or 'data' (default)
%       specify type of values in image
% 'threshtype', followed by 't' or 'p'
% 'df', followed by degrees of freedom, for p- and t-image threshold calc
% 'k', followed by extent threshold in voxels (slower)
% 'intersect':  Create intersection of images; uses abs, so + and - values
% count as yesses for intersection
%
%
%
% Examples:
% Threshold an image set (p) to be at least zero
% -----------------------------------------------------------
% p =
%/Users/tor/Documents/Tor_Documents/CurrentExperiments/Lab/Pre-appraisal/Results/rscalped_avg152T1_graymatter_smoothed.img
%/Users/tor/Documents/Tor_Documents/CurrentExperiments/Lab/Pre-appraisal/Results/t_intercept.img
%
% [dat,volInfo] = iimg_threshold(p,'thr',0);
%
% Do the same, but take the intersection and write an output image
% -----------------------------------------------------------
% [dat,volInfo] = iimg_threshold(p,'thr',3,'outnames','intersct','masked_t.img');
%
%
% Threshold a t-image based on a p-value and a df
% -----------------------------------------------------------
% p
% =/Users/tor/Documents/Tor_Documents/CurrentExperiments/Lab/Pre-appraisal/Results/t_intercept.img
% [dat,volInfo] = iimg_threshold(p,'thr',.005,'imgtype','t','threshtype','p','df',28,'outnames','thresh_t.img');
%
% cl = mask2clusters('masked_t.img'); cluster_orthviews(cl);
%
% The same, but threshold based on absolute value (+ and - values)
% [dat,volInfo] = iimg_threshold(p,'thr',.005,'abs','imgtype','t','threshtype','p','df',28,'outnames','thresh_t.img');
%
% % Threshold a p-value image directly
% -----------------------------------------------------------
% [dat,volInfo] = iimg_threshold('X-M-Y_pvals.img','thr',[0 .05],'outnames','X-M-Y_pvals_thresh.img');
% [dat,volInfo,cl] = iimg_threshold(inname,'thr',[0 .05],'outnames',outname);
%
% Threshold a p-value image, with cluster sizes
% [dat,volInfo,cl] = iimg_threshold(inname,'thr',[0 .05],'k',10);

%% --------------------------------------
% * Set up arguments
% --------------------------------------

% defaults
% maskname = deblank(image_names(1,:));
df = [];
thr = [0 Inf];                  % must be > 0, < Inf
imgtype = 'data';               % could be data, t, p, or F
threshtype = 'none';
k = 1;
dointersect = 0;
con = [];
outnames = [];
doabs = 0;                      % absolute value thresholding
extended_output_flag = 2;    %*(nargout > 2); % yes if we've requested clusters to be created needed for extent also

% inputs
for i = 1:length(varargin)
    arg = varargin{i};
    if ischar(arg)
        switch lower(arg)
            %case 'mask', maskname = varargin{i+1};
            case 'imgtype', imgtype = varargin{i+1};
            case 'threshtype', threshtype = varargin{i+1};
            case 'df', df = varargin{i+1};
            case 'thr', thr = varargin{i+1};
                case 'k', k = varargin{i+1};
            case 'intersect', dointersect = varargin{i+1};
            case 'contrast', con = varargin{i+1};
            case 'outnames', outnames = varargin{i+1};
            case 'abs', doabs = varargin{i+1};
        end
    end
end

% Make upper threshold infinity if not entered
if length(thr) < 2, thr = [thr Inf];     end

%% --------------------------------------
% * Read image data
% --------------------------------------
[volInfo,dat] = iimg_read_img(image_names,extended_output_flag);


%% --------------------------------------
% * Convert and apply threshold
% --------------------------------------
thr = convert_threshold(imgtype,threshtype,thr,df);

if doabs
    % absolute value
    whzero = abs(dat) < thr(1) | abs(dat) > thr(2);
else
    whzero = dat < thr(1) | dat > thr(2);
end
dat(whzero) = 0;

%% --------------------------------------
% * Apply size threshold
% --------------------------------------
[dat,nvox] = iimg_cluster_extent(dat,volInfo,k);



%% --------------------------------------
% special operations
% --------------------------------------
if ~isempty(con)
    % Apply contrast(s) across images
    dat = apply_contrast(dat,con);
end

if dointersect
    % Create intersection
    dat = all(abs(dat),2);      % use any for union
end

%% --------------------------------------
% * Write out image names, if asked
% --------------------------------------
if ~isempty(outnames)

    iimg_write_images(dat,volInfo,outnames);

end

%% --------------------------------------
% * clusters output
% --------------------------------------
if extended_output_flag
    
    % could enter k here, but don't need to because it's already
    % thresholded
    %cl = iimg_indx2clusters(dat,volInfo,thr,k);
    cl = iimg_indx2clusters(dat,volInfo,thr);
end

return




function thr = convert_threshold(imgtype,threshtype,thr,df)

switch imgtype

    case 'data'
        % do nothing
    case 't'
        switch threshtype
            case 't', % do nothing
            case 'p',
                % convert p-value to t-value
                if nargin < 4 || isempty(df)
                    error('You must enter df to use p-value based thresholding.');
                end
                thr = tinv(1-thr,df);
            otherwise
                error('Threshold type must be t or p values for t-images')
        end

    case 'p'
        switch threshtype
            case 't',
                if nargin < 4 || isempty(df)
                    error('You must enter df to use t-value based thresholding.');
                end
                thr = 1 - tcdf(thr,df);
            case 'p', % do nothing
            otherwise
                error('Threshold type must be t or p values for p-images')
        end

end





%% Sub-functions

%% Contrast
function condat = apply_contrast(dat,con)

if size(con,2) ~= size(dat,2)
    error('Contrast matrix must have as many columns as images.');
end

condat(:,i) = dat * con';

return




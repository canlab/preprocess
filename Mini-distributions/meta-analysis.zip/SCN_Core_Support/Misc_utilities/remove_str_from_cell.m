function cellarray = remove_str_from_cell(cellarray,str)

wh = strfind(cellarray,str); for i=1:length(wh),if isempty(wh{i}),wh{i}=0;,end,end
wh = cell2mat(wh); wh = wh>0;
cellarray(find(wh)) = [];

return


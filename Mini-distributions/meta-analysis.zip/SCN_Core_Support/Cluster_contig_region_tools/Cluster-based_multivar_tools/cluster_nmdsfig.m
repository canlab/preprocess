function [c,cl] = cluster_nmdsfig(cl,fldname,colm,varargin)
% function [c,cl] = cluster_nmdsfig(cl,fldname,colm,[behavior],[ancova var],[covs of no interest])
%
% Makes a multidim scaling figure from clusters
% Plus some other plots
%
% Example:
% c = cluster_nmdsfig(cl,'BARPLOT.data',2);
%
% c is a structure with lots of info
% cl has names appended, if not entered previously
%
% behavioral input is of three types:
% btwn_scores       covariate of interest (1 only)
% ancova_var        categorical ANCOVA coding var (2-levels, one only);
%                   generally not of interest
%                   IF ancova_var is entered, "PPI" of group x brain
%                   covariance interaction will be computed
% covs of no int    of no interest; will be removed from brain and behavior
%                   before performing ANCOVA (for simplicity); 1 or more OK
%
% Tor Wager
%
% Examples:
%
% Use average data from cl.timeseries and correlate with EXPT.behavior. 
% Covary out effects of order before running models; no ANCOVA
% [c,cl] = cluster_nmdsfig(cl,'timeseries',1,EXPT.behavior',[],EXPT.order2);
%

diary cluster_nmdsfig_output.txt

if length(varargin) > 0, c.btwn_scores = varargin{1};, else, c.btwn_scores = [];,end
if length(varargin) > 1, c.ancova_codes = varargin{2};, else, c.ancova_codes = [];,end
if length(varargin) > 2, c.covs_nointerest = varargin{3};, else, c.covs_nointerest = [];,end
  
cl(1).btwn_scores = c.btwn_scores; cl(1).ancova_codes = c.ancova_codes; cl(1).covs_nointerest=c.covs_nointerest;

c.X = [c.btwn_scores, c.covs_nointerest];

% -----------------------------------------------------------------------
% get data from selected field
% -----------------------------------------------------------------------

dat = [];
for i = 1:length(cl), 
    str = ['dat1 = cl(i).' fldname '(:,' num2str(colm) ');'];
    eval(str)
    dat=[dat dat1];,
end

%if length(varargin) > 0,dat = [c.btwn_scores dat];,end

c.dat = dat;

% -----------------------------------------------------------------------
% get names
% -----------------------------------------------------------------------

if ~isfield(cl,'shorttitle')
    for i = 1:length(cl),
        tor_fig;
        montage_clusters_maxslice([],cl(i),{'r'});, 
        cl(i).shorttitle = input('Enter name: ','s');,close,
    end
end

if isfield(cl(1),'shorttitle'), 
    for i = 1:length(cl), names{i}=cl(i).shorttitle;,end
else, 
    for i = 1:length(cl), names{i}=['Region ' num2str(i)];,,end
end

%names = [{'Behav'} names];
c.names = names;  
 

% -----------------------------------------------------------------------
% remove covariates of no interest, if any
% -----------------------------------------------------------------------
if isempty(c.covs_nointerest)
    % do nothing
else
    disp('Found covariate(s) of no interest; Removing them from behavior and brain data.')
    if ~isempty(c.btwn_scores)
        % partialcorr gets adjusted x, y, and correls; here just use it to
        % get adjusted x
        c.btwn_scores  = partialcor([c.btwn_scores c.covs_nointerest],ones(size(c.btwn_scores,1),1),1);
    end
    
    for i = 1:size(dat,2)
        dat(:,i) = partialcor([dat(:,i) c.covs_nointerest],ones(size(dat,1),1),1);
    end
end

% -----------------------------------------------------------------------
% get correlations, significance, and number of dimensions
% -----------------------------------------------------------------------

if isempty(c.ancova_codes)
    doancova = 0;
    % no between covariates, just use correlations
    [r,p]=corrcoef(dat); r(r>.9999) = 1; sig = sign(r) .* (p < .05);
else
    %doancova = input('Use covariate scores as covariate in ANCOVA? (inter-region correls then done w/i group): 1/0: ');
    doancova = 1;
end

if doancova
        
    disp('Using ANCOVA to model between-subjects effects')
    disp('Inter-region correlations within groups; interaction tests group x brain covariance interaction')
    % main effect of grp in this case is hi vs lo behavior on region Y (brain act.) after
    % controlling for region X -- a bit hard to interpret
    
    if length(unique(c.ancova_codes) > 2),
        disp('Binarizing ANCOVA code regressor into two groups.');
        c.ancova_codes = mediansplit(c.ancova_codes);
    end
    
    [b,t,p] = ancova(c.ancova_codes,[],dat); % first cell is grp (diff), 2nd is r, 3rd is r diff x group
    pall = p;   % save all slopes
    
    r = b{2};   % overall slope
    r = r + eye(size(r));   % add 1 to diagonal
    p = pall{2};  
    sig = sign(r) .* (p < .05);
    
    ri = b{3};  % behavior x covariance interaction
    %ri = ri + eye(size(ri));   % add 1 to diagonal
    pi = pall{3};  
    sigi = sign(ri) .* (pi < .05);
    
    c.STATS.siginteract = sigi;
    c.STATS.b = b; c.STATS.t = t; c.STATS.p = pall;
    c.STATS.btp_descrip = 'first cell is grp (diff), 2nd is r, 3rd is r diff x group.  betas, t-vals, p-vals';
    
end
    
c.r = r;
c.STATS.sigmat = sig;



% MDS decomposition and plotting
% -----------------------------------------------------------------------
% get number of dimensions that carry most of the variance.
% This is to simplify the space and make it less sparse --
% expected to give better clustering results.
% -----------------------------------------------------------------------

% -----------------------------------------------------------------------
% Reduce to distances in ndims space, check this against actual distances
% -----------------------------------------------------------------------

c.ndims = 3; 
% scale correlations (or beta weights) so that they are a similarity matrix between 0 and 1.
c.D = (1 - c.r) ./ 2;
    
c.D=distosim(c.D);  %mmOUT.xc is SIM - so convert to DIS


% graphic check on number of dimensions
[pc,obs,imp] = shepardplot(c.D,c.ndims); drawnow

try
    [c.GroupSpace c.eigenvalues]= cmdscale(c.D);
catch
    [c.GroupSpace c.eigenvalues]= cmdscale_t(c.D);
end

GroupSpace = c.GroupSpace(:,1:c.ndims);       % reduce dimensions
nclust = 2:(size(c.GroupSpace,1) ./ 2)+1;     % choose number of clusters to test

    try, saveas(gcf,'cluster_nmdsfig_shepardplot','tif');,
        saveas(gcf,'cluster_nmdsfig_shepardplot','fig');
    catch disp('cannot save figure');,
    end


% -----------------------------------------------------------------------
% testcluster: 
% 
% Permute objects in space, get null hypothesis cluster quality, and test
% observed cluster solution against this.
% -----------------------------------------------------------------------

% pval is p-values for each number of clusters tested
% classes = class ("network") assignments for best clustering solution
[c.ClusterSolution.pvals,c.ClusterSolution.classes, c.ClusterSolution.classnames ...
    c.ClusterSolution.X,c.ClusterSolution.include,c.ClusterSolution.names]= ...
    testclustnew(GroupSpace,nclust,c.ndims,200,c.names,'keep','average');

%[bestpval,bestXc,bestnames,bestX,where,clustnames]=testcluster(X,clust,[r],[nperm],[names],[remove],[linkagetype]);

    try, saveas(gcf,'cluster_nmdsfig_testcluster','tif');,
        saveas(gcf,'cluster_nmdsfig_testcluster','fig');
    catch disp('cannot save figure');,
    end
    
    
% plot figures of this
scnsize = get(0,'ScreenSize');
figure('position',[50 50 700 600],'color','white')
% for side plots
%subplot('position',[0.3 0.3 0.5 0.6]);

if ~isempty(c.btwn_scores)  % plot interactions between beh and regional covariance
    if exist('sigi') == 1
        % we have a group x cov interaction in ANCOVA
        nmdsfig(GroupSpace,c.ClusterSolution.classes,c.names,c.STATS.sigmat,1,{'Pos' 'Neg' 'Pos x Beh' 'Neg x Beh'},sigi);
        figname = 'cluster_nmdsfig_ancova_interact';
    else
        nmdsfig(GroupSpace,c.ClusterSolution.classes,c.names,c.STATS.sigmat,1,{'Pos' 'Neg'});
        figname = 'cluster_nmdsfig_mdsfig';
    end
else
    nmdsfig(GroupSpace,c.ClusterSolution.classes,c.names,c.STATS.sigmat); 
    figname = 'cluster_nmdsfig_mdsfig';
end


    

% -----------------------------------------------------------------------
% factor scores with reduced dimensions
% -----------------------------------------------------------------------
r = c.r;
sqL = sqrt(diag(c.eigenvalues(1:c.ndims)));
B = inv(r) * pc(:,1:c.ndims) * sqL;   % inv(r) * factor loading matrix A = VsqrtL
c.factor_scores = dat * B;
fs = c.factor_scores;       

% -----------------------------------------------------------------------
% Stepwise regression of dimensions on behavior
% -----------------------------------------------------------------------

if ~isempty(c.btwn_scores)
    fprintf(1,'\n');
    fprintf(1,['Prediction of behavior with component scores\n']);

    DATA.INDSCAL.STEPWISE = stepwise_tor(fs,c.btwn_scores); 
    fprintf(1,'\n');
end


% -----------------------------------------------------------------------
% MDSfig plot
% -----------------------------------------------------------------------

dosideplots = 0;

if dosideplots
    
% X-axis subplot: Component 1
subplot('position',[0.25 0.1 0.6 0.1]);     hold on;
set(gca,'FontSize',16);
fact = c.factor_scores(:,1); 
if ~isempty(c.btwn_scores),
    fact=[fact c.btwn_scores]; fact=sortrows(fact,2);
    xlab='Activation score for each participant: Component 1';
    
    lo = find(fact(:,2)<median(fact(:,2)));
    hi = find(fact(:,2)>median(fact(:,2)));
    
    plot(lo,fact(lo,1),'ko','LineWidth',2);
    plot(hi,fact(hi,1),'k^','LineWidth',2);
    set(gca,'XTick',[1 max(lo)+.5 size(fact,1)],'XTickLabel',{'Lowest' 'Median' 'Highest'})
    title(xlab)
    xlabel('Behavior');
    ylabel('Score')
else
    xlab='Scores on Component 1';
    plot(fact(:,1),'ko','LineWidth',2);
    title(xlab); xlabel('Index'); ylabel('Score');
end

% Y-axis subplot: Component 2
subplot('position',[0.1 0.3 0.1 0.6]);   hold on;
set(gca,'FontSize',16);
fact = c.factor_scores(:,2); 
if ~isempty(c.btwn_scores),
    fact=[fact c.btwn_scores]; fact=sortrows(fact,2);
    xlab='Component 2';
    
    lo = find(fact(:,2)<median(fact(:,2)));
    hi = find(fact(:,2)>median(fact(:,2)));
    
    plot(fact(lo,1),lo,'ko','LineWidth',2);
    plot(fact(hi,1),hi,'k^','LineWidth',2);
    set(gca,'YTick',[1 max(lo)+.5 size(fact,1)],'YTickLabel',{'Lowest' 'Median' 'Highest'})
    title(xlab)
    ylabel('Behavior');
    xlabel('Score')
else
    xlab='Scores on Component 1';
    plot(fact(:,1),'ko','LineWidth',2);
    title(xlab); ylabel('Index'); xlabel('Scores: Comp. 2')
end

end % if dosideplots



drawnow

    try, saveas(gcf,figname,'tif');,
        saveas(gcf,figname,'fig');
    catch disp('cannot save figure');,
    end
    
    
% -----------------------------------------------------------------------
% separate plots of high/low behavior 
% -----------------------------------------------------------------------
if ~isempty(c.btwn_scores)  % plot interactions between beh and regional covariance
    tor_fig(1,2); subplot(1,2,1);
    [r,p]=corrcoef(dat(c.btwn_scores>median(c.btwn_scores),:)); r(r>.9999) = 1; sig = sign(r) .* (p < .05);
    nmdsfig(GroupSpace,c.ClusterSolution.classes,c.names,sig);
    title('High behavior')
    
    subplot(1,2,2)
    [r,p]=corrcoef(dat(c.btwn_scores<=median(c.btwn_scores),:)); r(r>.9999) = 1; sig = sign(r) .* (p < .05);
    nmdsfig(GroupSpace,c.ClusterSolution.classes,c.names,sig);    
    title('Low behavior')
    drawnow
end

if ~isempty(c.ancova_codes)  % plot interactions between beh and regional covariance
    tor_fig(1,3); subplot(1,3,1);
    [r,p]=corrcoef(dat(c.ancova_codes>median(c.ancova_codes),:)); r(r>.9999) = 1; sig = sign(r) .* (p < .05);
    nmdsfig(GroupSpace,c.ClusterSolution.classes,c.names,sig);
    title('High ANCOVA group')
    
    subplot(1,3,2)
    [r,p]=corrcoef(dat(c.ancova_codes<median(c.ancova_codes),:)); r(r>.9999) = 1; sig = sign(r) .* (p < .05);
    nmdsfig(GroupSpace,c.ClusterSolution.classes,c.names,sig);    
    title('Low ANCOVA group')
    drawnow
    
    subplot(1,3,3)
    [r,p]=corrcoef(dat(c.ancova_codes<median(c.ancova_codes),:)); r(r>.9999) = 1; sig = sign(r) .* (p < .05);
    nmdsfig(GroupSpace,c.ClusterSolution.classes,c.names,sigi);    
    title('Interactions')
    
    
end


% -----------------------------------------------------------------------
% Optional plots of interactions and correlations
% -----------------------------------------------------------------------
 c.doancova = 'No';
if doancova,
    c.doancova = 'Yes';
if ~isempty(c.ancova_codes),
    [i,j] = find(triu(c.STATS.siginteract));
    if ~isempty(i),
        go = input([num2str(length(i)) ' significant behavior x covariance interactions.  Plot? ']);
        if go
            for ind = 1:length(i)
                cluster_orthviews(cl(i(ind)),{[1 0 0]});
                cluster_orthviews(cl(j(ind)),{[0 0 1]},'add');
                h = axes('Position',[.55 .05 .42 .42]);
                [b,t,p] = ancova(c.ancova_codes,dat(:,i(ind)),dat(:,j(ind)),1);
                xlabel(cl(i(ind)).shorttitle); ylabel(cl(j(ind)).shorttitle);
                title([]);
                input('Save and press a key for the next one')
            end
        end
    end
end
    
end     % if doancova

if ~any(c.ClusterSolution.pvals < .05)
    go  = input('No significant clustering.  Proceed with analyses anyway?');
    if ~go, return, end
end





% -----------------------------------------------------------------------
% Get average correlations within and between clusters
% -----------------------------------------------------------------------

% name 'networks'
for i = 1:max(c.ClusterSolution.classes)
    disp(['Network ' num2str(i)])
    tmp = find(c.ClusterSolution.classes == i);
    for j = 1:length(tmp)
        fprintf(1,'%s . ',c.names{tmp(j)});
        if j > 4, fprintf(1,'\n'),end
    end
    fprintf(1,'\n')
    classnames{i} = input('Name this network: ','s');
end

% average correlations within and between networks, and test
cla = c.ClusterSolution.classes;

% if we have a between-subjects covariate, enter it, otherwise empty
if ~isfield(c,'btwn_scores'), c.btwn_scores = [];, end


% now run for the average across task conditions
out = apply_cluster_solution(cla,...
    c.r,...
    'names',classnames,'bcov',c.btwn_scores);

out.names = classnames;
c.APPLY_CLUSTER = out;


%DATA.APPLY_CLUSTER.group = apply_cluster_solution(DATA.CLUSTER.classes,DATA.DATA.xc,'state',[], ...
%    'contrast',grpweights,'names',DATA.APPLY_CLUSTER.names,'bcov',DATA.SPEC.beh);


% -----------------------------------------------------------------------
% Apply this clustering solution to the clusters
% Get individual 'network' scores and use them as predictors of behavior
% in multiple regression
% -----------------------------------------------------------------------

% standardize variables?  No, let's let low variance vars contribute less
% to avgs

class_avg_dat = [];
for i = 1:max(cla)
    wh = find(c.ClusterSolution.classes == i);
    if length(wh)>1
        class_avg_dat = [class_avg_dat nanmean(dat(:,wh)')'];
    else
         class_avg_dat = [class_avg_dat dat(:,wh)];
    end
end
c.class_avg_dat = class_avg_dat;


if ~isempty(c.btwn_scores)
    
    % Add logistic regression for categorical 1/0 DVs!
    % see also stepwise_tor.m which does this stuff.
    disp(' ')
    disp('------------------------------------------')
    disp('Using networks to predict behavior'), 
    disp('------------------------------------------')
    c.ClusterSolution.class_avg_dat = class_avg_dat;
    disp(' ')
    str = correlation_to_text([c.btwn_scores class_avg_dat],[],[{'Behav'} classnames]);
    
    %[c.ClusterSolution.STEPWISE.b,c.ClusterSolution.STEPWISE.se,c.ClusterSolution.STEPWISE.pval, ...
    %c.ClusterSolution.STEPWISE.inmodel,stats] = ...
    %stepwisefit(class_avg_dat,c.btwn_scores);
    disp(' ')
    c.class_STEPWISE = stepwise_tor(class_avg_dat,c.btwn_scores,classnames);
    

    %N = stats.dfe+stats.df0;
    %r2 = (stats.SStotal-stats.SSresid) ./ stats.SStotal;
    %adjr2 = 1 - (1-r2)*((N - 1) ./ (N - stats.df0 - 1));
    %fprintf(1,'Omnibus F(%3.0f,%3.0f) = %3.2f, RMSE = %3.2f, p = %3.4f, Adj R^2 = %3.2f\n', ...
    %stats.df0,stats.dfe,stats.fstat, ...
    %stats.rmse,stats.pval,adjr2);
    %stats.adjr2 = adjr2;
    %c.ClusterSolution.STEPWISE.stats = stats;
    
    disp(' ')
    disp('------------------------------------------')
    disp('Using individual regions to predict behavior'), 
    disp('------------------------------------------')
    disp(' ')
    str = correlation_to_text([c.btwn_scores dat],[],[{'Behav'} names],1);
    disp(' ')
    c.indiv_STEPWISE = stepwise_tor(dat,c.btwn_scores,names);
   
end


% -----------------------------------------------------------------------
% get class (network) average stimulus locations (group space) and plot
% -----------------------------------------------------------------------

Gs = c.GroupSpace(:,1:c.ndims);
cla = c.ClusterSolution.classes;
for i = 1:max(cla)
    wh = find(cla == i);
    if length(wh)>1;
        classGs(i,:) = mean(Gs(wh,:));
    else
        classGs(i,:) = Gs(wh,:);
    end
end
c.APPLY_CLUSTER.Gs = classGs;
c.APPLY_CLUSTER.classes = 1:max(cla);

% Figures
scnsize = get(0,'ScreenSize');
figure('position',[50 50 scnsize(3)-100 scnsize(4)/2],'color','white')
if doancova, subplot(1,2,1);,end
set(gca,'FontSize',14)
mdsfig(classGs(:,1:2),classnames,c.APPLY_CLUSTER.classes,c.APPLY_CLUSTER.group_stats.sigu); 
title(['Correlations among groups'])

if doancova, subplot(1,2,2);, 
    set(gca,'FontSize',14)
    mdsfig(classGs(:,1:2),classnames,cla,sigi); 
    title(['Group by cov interaction: ANCOVA'])
end

try, saveas(gcf,'cluster_nmdsfig_class_lines_uncor','tif');, saveas(gcf,'cluster_nmdsfig_class_lines_uncor','fig');,     catch, disp('Error saving figure.'), end


diary off

return

function [realchi2,chi2p,sig,df,tab,yp] = nonparam_chi2(y,condf,iter,varargin)
% [realchi2,chi2p,sig,df,tab,yp] = nonparam_chi2(y,condf,iter,[w])
%
% weights should be mean = 1

if length(varargin) > 0, w=varargin{1};, else, w=ones(size(y));, end


[realchi2,df,tmp,tmp,warn,tab,e] = chi2test([y condf],'obs',w); 

%iter = 5000;
n = length(y);

% weights
y = y .* w;

% initialize output
chi2 = zeros(iter,1);
yp = zeros(size(y,1),iter);

for i = 1:iter
    yp(:,i) = y(randperm(n));
    
    [chi2(i)] = chi2test([yp(:,i) condf],'obs');
end

chi2p = sum(chi2>=realchi2) ./ iter;
    
sig = chi2p <= .05;


return

